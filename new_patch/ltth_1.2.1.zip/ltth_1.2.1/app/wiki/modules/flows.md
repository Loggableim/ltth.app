# Automation Flows System

## Overview

The Flows system allows you to create powerful "if-then" automations without writing any code.

## What are Flows?

Flows are event-driven automations with triggers, conditions, and actions.

Navigate to the **Flows** section in the sidebar to create and manage your automation flows.

---

*For full documentation, see the Flows section in the dashboard.*
