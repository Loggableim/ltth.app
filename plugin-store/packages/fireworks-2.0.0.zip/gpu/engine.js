/**
 * Advanced Fireworks Engine - WebGL2 SOA Particle System
 * 
 * High-Performance GPU-Accelerated Fireworks with Struct-of-Arrays (SOA) architecture
 * 
 * Features:
 * - WebGL2 instanced rendering with batched draw calls
 * - SOA particle system with TypedArrays for cache-friendly memory layout
 * - Custom explosion shapes with mathematical precision
 * - Realistic physics simulation (gravity, drag, rotation)
 * - Advanced color palettes with HSL color space
 * - Audio synchronization with callback-based explosion sounds
 * - Socket.io integration for remote control and FPS monitoring
 * 
 * Architecture:
 * - ParticleSystemSOA: High-performance particle storage with TypedArrays
 * - WebGLParticleEngine: GPU-accelerated instanced rendering
 * - Firework: Rocket launch and explosion state management
 * - FireworksEngine: Main engine coordinating physics and rendering
 * - AudioManager: Audio playback with tier-based sound selection
 * 
 * Requirements:
 * - WebGL2 support (mandatory, no fallback)
 * - particle-system-soa.js
 * - webgl-particle-engine.js
 */

// ============================================================================
// CONFIGURATION
// ============================================================================

// Debug flag - set to true to enable console.log statements
const DEBUG = false;

const CONFIG = {
    maxFireworks: 100,
    maxParticlesPerExplosion: 200,
    targetFps: 60,
    minFps: 24, // Adaptive performance threshold - user configurable down to 24 FPS
    gravity: 0.08,
    airResistance: 0.99,
    rocketSpeed: -12,
    rocketAcceleration: -0.08,
    trailLength: 20,
    baseTrailLength: 20,
    trailFadeAlpha: 10,
    trailFadeSpeed: 0.02,
    sparkleChance: 0.15,
    secondaryExplosionChance: 0.1,
    baseSecondaryExplosionChance: 0.1,
    backgroundColor: 'rgba(0, 0, 0, 0)',
    resolution: 1.0, // Legacy - Canvas resolution multiplier (0.5 = half res, 1.0 = full res)
    resolutionPreset: '1080p', // Resolution preset: 360p, 540p, 720p, 1080p, 1440p, 4k
    orientation: 'landscape', // 'landscape' or 'portrait'
    adaptiveRenderScaleEnabled: true,
    minRenderScale: 0.75,
    renderScaleStep: 0.15,
    renderScaleRecoveryFpsMargin: 6,
    giftPopupPosition: 'bottom', // 'top', 'middle', 'bottom', 'none', or {x, y} coordinates
    giftPopupEnabled: true, // Whether to show gift popup at all
    despawnFadeDuration: 1.5, // Duration in seconds for rocket despawn fade effect (when rockets are removed due to overload)
    defaultColors: ['#ff0000', '#ff8800', '#ffff00', '#00ff00', '#0088ff', '#ff00ff'],
    colorPalettes: {
        classic: ['#ff0000', '#ff8800', '#ffff00', '#00ff00', '#0088ff', '#ff00ff'],
        neon: ['#ff006e', '#fb5607', '#ffbe0b', '#8338ec', '#3a86ff'],
        pastel: ['#ffc2d1', '#ffb3ba', '#ffdfba', '#ffffba', '#baffc9', '#bae1ff'],
        fire: ['#ff0000', '#ff4500', '#ff8c00', '#ffd700', '#ffff00'],
        ice: ['#00ffff', '#00ccff', '#0099ff', '#0066ff', '#0033ff'],
        rainbow: ['#ff0000', '#ff7f00', '#ffff00', '#00ff00', '#0000ff', '#9400d3']
    },
    // Combo throttling to prevent extreme lag
    comboThrottleMinInterval: 100, // Minimum ms between combo triggers
    comboSkipRocketsThreshold: 5, // Skip rockets when combo >= this value
    comboInstantExplodeThreshold: 8, // Instant explosions (no rockets) when combo >= this
    // Performance constants
    IDEAL_FRAME_TIME: 16.67, // Ideal frame time for 60 FPS (1000ms / 60fps)
    FPS_TIMING_TOLERANCE: 1, // Tolerance in ms for FPS throttling timing jitter
    ALPHA_CULL_THRESHOLD: 0.05 // Alpha threshold below which particles are not rendered (Optimization #11)
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function hslToRgb(h, s, l) {
    h /= 360;
    s /= 100;
    l /= 100;
    let r, g, b;
    
    if (s === 0) {
        r = g = b = l;
    } else {
        const hue2rgb = (p, q, t) => {
            if (t < 0) t += 1;
            if (t > 1) t -= 1;
            if (t < 1/6) return p + (q - p) * 6 * t;
            if (t < 1/2) return q;
            if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
            return p;
        };
        
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        r = hue2rgb(p, q, h + 1/3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1/3);
    }
    
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}

function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : { r: 255, g: 255, b: 255 };
}

// ============================================================================
// OBJECT POOLING - High-performance particle reuse system
// ============================================================================

class ParticlePool {
    constructor(initialSize = 1000) {  // Optimization #5: Reduced from 5000
        this.pool = [];
        this.active = new Set();  // Bug #1 Fix: Changed from Array to Set for O(1) operations
        this.maxPoolSize = 10000;  // Optimization #5: Hard limit
        this.growthRate = 500;     // Optimization #5: Grow by this amount when needed
        this.lastGrowthTime = 0;
        this.growthCooldown = 100; // ms between growth operations
        
        // Pre-allocate initial particles
        for (let i = 0; i < initialSize; i++) {
            this.pool.push(new Particle());
        }
        
        if (DEBUG) console.log(`[ParticlePool] Initialized with ${initialSize} particles (max: ${this.maxPoolSize})`);
    }
    
    acquire(args) {
        let particle;
        
        // Optimization #5: Check if pool needs to grow
        if (this.pool.length === 0) {
            const now = performance.now();
            const totalParticles = this.active.size;
            
            if (totalParticles < this.maxPoolSize && now - this.lastGrowthTime > this.growthCooldown) {
                // Grow the pool
                const growAmount = Math.min(this.growthRate, this.maxPoolSize - totalParticles);
                for (let i = 0; i < growAmount; i++) {
                    this.pool.push(new Particle());
                }
                this.lastGrowthTime = now;
                if (DEBUG) console.log(`[ParticlePool] Grew by ${growAmount}, total capacity: ${totalParticles + growAmount}`);
            }
        }
        
        if (this.pool.length > 0) {
            particle = this.pool.pop();
            particle.reset(args);
        } else {
            // Pool exhausted and at max capacity, create temporary particle
            particle = new Particle(args);
            if (DEBUG) console.log('[ParticlePool] Pool exhausted, created temporary particle');
        }
        
        this.active.add(particle);  // Bug #1 Fix: O(1) operation with Set
        return particle;
    }
    
    release(particle) {
        if (this.active.has(particle)) {  // Bug #1 Fix: O(1) lookup with Set
            this.active.delete(particle);  // Bug #1 Fix: O(1) deletion with Set
            particle.reset();
            
            // Optimization #5: Only return to pool if under max size
            if (this.pool.length + this.active.size < this.maxPoolSize) {
                this.pool.push(particle);
            }
            // Otherwise let it be garbage collected
        }
    }
    
    releaseAll(particles) {
        for (const particle of particles) {
            if (this.active.has(particle)) {  // Bug #1 Fix: O(1) check
                this.active.delete(particle);  // Bug #1 Fix: O(1) deletion
                particle.reset();
                
                // Optimization #5: Only return to pool if under max size
                if (this.pool.length + this.active.size < this.maxPoolSize) {
                    this.pool.push(particle);
                }
            }
        }
    }
    
    getStats() {
        return {
            pooled: this.pool.length,
            active: this.active.size,  // Bug #1 Fix: Changed from .length to .size
            total: this.pool.length + this.active.size,
            maxSize: this.maxPoolSize
        };
    }
    
    // Optimization #5: New method - Shrink pool if it's much larger than needed
    compact() {
        const targetSize = Math.max(1000, this.active.size * 2);
        if (this.pool.length > targetSize) {
            const removeCount = this.pool.length - targetSize;
            this.pool.splice(0, removeCount);
            if (DEBUG) console.log(`[ParticlePool] Compacted, removed ${removeCount} unused particles`);
        }
    }
}

// Global particle pool instance
let globalParticlePool = null;

// ============================================================================
// PARTICLE CLASS - Advanced physics-based particle
// ============================================================================

class Particle {
    constructor(args = {}) {
        const defaults = {
            x: 0,
            y: 0,
            vx: 0,
            vy: -10,
            ax: 0,
            ay: 0,
            mass: 1,
            drag: CONFIG.airResistance,
            gravity: CONFIG.gravity,
            size: 3,
            hue: 360,
            saturation: 100,
            brightness: 100,
            alpha: 1.0,
            lifespan: 1.0,
            decay: 0.01,
            isSeed: true,
            isSparkle: false,
            color: '#ffffff',
            image: null,
            type: 'circle',
            rotation: 0,
            rotationSpeed: 0,
            isDespawning: false, // Flag for despawn fade effect
            despawnStartTime: 0, // When despawn started
            // Secondary explosion properties
            willBurst: false,      // Will create mini-burst (for burst shape)
            burstDelay: 0,         // Delay before mini-burst
            burstTime: 0,          // Time when particle was created
            hasBurst: false,       // Already triggered burst
            willSpiral: false,     // Will create spiral burst (for spiral shape)
            spiralDelay: 0,        // Delay before spiral burst
            hasSpiraled: false,    // Already triggered spiral
            // Texture Atlas: 0=circle(procedural), 1=heart, 2=paw, 3+=atlas slot
            textureIndex: 0
        };
        
        Object.assign(this, defaults, args);
        this.maxLifespan = this.lifespan;
        this.trail = [];
        this.age = 0;
        this._cachedColor = null;
        
        // Record creation time for secondary explosions
        if (this.willBurst || this.willSpiral) {
            this.burstTime = performance.now();
        }
    }
    
    applyForce(fx, fy) {
        this.ax += fx / this.mass;
        this.ay += fy / this.mass;
    }
    
    applyGravity() {
        this.ay += this.gravity;
    }
    
    update(deltaTime = 1.0) {
        // Handle despawn fade effect
        if (this.isDespawning) {
            const despawnDuration = CONFIG.despawnFadeDuration * 1000; // Convert to ms
            const elapsed = performance.now() - this.despawnStartTime;
            const fadeProgress = Math.min(elapsed / despawnDuration, 1.0);
            
            // Fade out alpha smoothly
            this.alpha = Math.max(0, 1.0 - fadeProgress);
            
            // If fade is complete, mark as done
            if (fadeProgress >= 1.0) {
                this.lifespan = 0;
            }
        }
        
        // Optimization #11: Early exit for nearly invisible particles
        if (this.alpha < CONFIG.ALPHA_CULL_THRESHOLD && !this.isSeed) {
            this.lifespan = 0;  // Mark as done
            return;
        }
        
        // Apply air resistance (frame-independent)
        const dragFactor = Math.pow(this.drag, deltaTime);
        this.vx *= dragFactor;
        this.vy *= dragFactor;
        
        // Update velocity with deltaTime
        this.vx += this.ax * deltaTime;
        this.vy += this.ay * deltaTime;
        
        // Update position with deltaTime
        this.x += this.vx * deltaTime;
        this.y += this.vy * deltaTime;
        
        // Clear acceleration
        this.ax = 0;
        this.ay = 0;
        
        // Update rotation with deltaTime
        this.rotation += this.rotationSpeed * deltaTime;
        
        // Update lifespan for explosion particles with deltaTime
        if (!this.isSeed && !this.isDespawning) {
            this.lifespan -= this.decay * deltaTime;
            this.alpha = Math.max(0, this.lifespan / this.maxLifespan);
            
            // Add sparkle flicker effect
            if (this.isSparkle && Math.random() < 0.3) {
                this.brightness = 80 + Math.random() * 20;
            }
        }
        
        // Store trail with fading based on age
        if (this.trail.length > CONFIG.trailLength) {
            this.trail.shift();
        }
        
        // Fade trail points based on their age (frame-independent)
        const trailFadeFactor = 1 - (CONFIG.trailFadeSpeed * deltaTime);
        for (let i = 0; i < this.trail.length; i++) {
            if (this.trail[i].alpha) {
                this.trail[i].alpha *= trailFadeFactor;
            }
        }
        
        this.trail.push({ 
            x: this.x, 
            y: this.y, 
            alpha: this.alpha * 0.6,
            size: this.size * 0.7
        });
        
        this.age += deltaTime;
    }
    
    isDone() {
        return this.lifespan <= 0 || this.y > window.innerHeight + 100;
    }
    
    /**
     * Start despawn fade effect
     * Called when particle needs to be removed due to performance
     */
    startDespawn() {
        if (!this.isDespawning) {
            this.isDespawning = true;
            this.despawnStartTime = performance.now();
        }
    }
    
    /**
     * Reset particle to default state for object pooling
     * Can optionally reinitialize with new args
     */
    reset(args = null) {
        if (args) {
            // Reinitialize with new values
            const defaults = {
                x: 0,
                y: 0,
                vx: 0,
                vy: -10,
                ax: 0,
                ay: 0,
                mass: 1,
                drag: CONFIG.airResistance,
                gravity: CONFIG.gravity,
                size: 3,
                hue: 360,
                saturation: 100,
                brightness: 100,
                alpha: 1.0,
                lifespan: 1.0,
                decay: 0.01,
                isSeed: true,
                isSparkle: false,
                color: '#ffffff',
                image: null,
                type: 'circle',
                rotation: 0,
                rotationSpeed: 0,
                isDespawning: false,
                despawnStartTime: 0,
                willBurst: false,
                burstDelay: 0,
                burstTime: 0,
                hasBurst: false,
                willSpiral: false,
                spiralDelay: 0,
                hasSpiraled: false,
                // Texture Atlas: 0=circle(procedural), 1=heart, 2=paw, 3+=atlas slot
                textureIndex: 0
            };
            Object.assign(this, defaults, args);
            this.maxLifespan = this.lifespan;
            this.trail.length = 0; // Clear trail array without reallocating
            this.age = 0;
            this._cachedColor = null;
            
            if (this.willBurst || this.willSpiral) {
                this.burstTime = performance.now();
            }
        } else {
            // Just clear to defaults
            this.x = 0;
            this.y = 0;
            this.vx = 0;
            this.vy = -10;
            this.ax = 0;
            this.ay = 0;
            this.mass = 1;
            this.drag = CONFIG.airResistance;
            this.gravity = CONFIG.gravity;
            this.size = 3;
            this.hue = 360;
            this.saturation = 100;
            this.brightness = 100;
            this.alpha = 1.0;
            this.lifespan = 1.0;
            this.maxLifespan = 1.0;
            this.decay = 0.01;
            this.isSeed = true;
            this.isSparkle = false;
            this.color = '#ffffff';
            this.image = null;
            this.type = 'circle';
            this.rotation = 0;
            this.rotationSpeed = 0;
            this.isDespawning = false;
            this.despawnStartTime = 0;
            this.willBurst = false;
            this.burstDelay = 0;
            this.burstTime = 0;
            this.hasBurst = false;
            this.willSpiral = false;
            this.spiralDelay = 0;
            this.hasSpiraled = false;
            this.trail.length = 0;
            this.age = 0;
            this._cachedColor = null;
        }
    }
}

// ============================================================================
// FIREWORK CLASS - Advanced multi-stage firework system
// ============================================================================

class Firework {
    constructor(args = {}) {
        const defaults = {
            x: Math.random() * window.innerWidth,
            y: window.innerHeight,
            targetY: 100 + Math.random() * 300,
            shape: 'burst',
            colors: CONFIG.colorPalettes.classic,
            intensity: 1.0,
            adaptiveParticleSizeScale: 1.0,
            giftImage: null,
            userAvatar: null,
            avatarParticleChance: 0.3,
            useImages: false,
            tier: 'medium',
            combo: 1,
            skipRocket: false, // Skip rocket animation for high combos
            instantExplode: false, // Explode immediately without delay
            engineFps: 60, // Current engine FPS for performance-based decisions
            giftTextureIndex: 0 // Texture Atlas slot for gift/avatar image
        };
        
        Object.assign(this, defaults, args);
        this.adaptiveParticleSizeScale = Math.max(0.6, Math.min(1.0, this.adaptiveParticleSizeScale || 1.0));
        
        // State management
        this.particles = [];
        this.secondaryExplosions = [];
        
        // If instant explode, skip rocket creation entirely
        if (this.instantExplode) {
            this.rocket = null;
            this.exploded = false; // Will be set to true in update() when explode() is called
            this.shouldExplodeImmediately = true;
        } else if (this.skipRocket) {
            // Create a dummy rocket at target position, will explode immediately
            this.exploded = false;
            this.rocket = new Particle({
                x: this.x,
                y: this.y, // Already at target from handleTrigger
                vx: 0,
                vy: 0,
                size: 1,
                hue: 0,
                saturation: 0,
                brightness: 0,
                color: '#000000',
                isSeed: true,
                gravity: 0,
                drag: 1,
                type: 'circle',
                image: null,
                lifespan: 0.01 // Very short lifespan
            });
        } else {
            // Normal mode: Create rocket particle
            this.exploded = false;
            // If user avatar is available, use it as the rocket head
            const rocketType = this.userAvatar ? 'image' : 'circle';
            const rocketImage = this.userAvatar;
            const rocketSize = (this.userAvatar ? 8 + this.intensity : 3 + this.intensity) * this.adaptiveParticleSizeScale;
            
            this.rocket = new Particle({
                x: this.x,
                y: this.y,
                vx: (Math.random() - 0.5) * 1.5,
                vy: CONFIG.rocketSpeed + (Math.random() - 0.5) * 2,
                size: rocketSize,
                hue: Math.random() * 360,
                saturation: 80,
                brightness: 100,
                color: this.colors[Math.floor(Math.random() * this.colors.length)],
                isSeed: true,
                gravity: CONFIG.rocketAcceleration,
                drag: 0.995,
                type: rocketType,
                image: rocketImage
            });
        }
        
        // Color palette for explosion
        this.baseHue = Math.random() * 360;
        this.hueRange = 60 + Math.random() * 60;
    }
    
    /**
     * Calculate approximate flight time for a rocket based on physics
     * Used to synchronize combined audio files
     * @param {number} startY - Starting Y position (usually canvas height)
     * @param {number} targetY - Target Y position
     * @param {number} initialVy - Initial vertical velocity (negative = upward)
     * @param {number} acceleration - Acceleration (positive = deceleration for upward movement)
     * @returns {number} Estimated flight time in seconds
     */
    calculateRocketFlightTime(startY, targetY, initialVy = CONFIG.rocketSpeed, acceleration = -CONFIG.rocketAcceleration) {
        // Physics: Using kinematic equations
        // v^2 = v0^2 + 2a(y - y0)
        // For upward motion with deceleration
        const distance = Math.abs(targetY - startY);
        
        // Time to reach target height (may hit target before reaching peak)
        // y = y0 + v0*t + 0.5*a*t^2
        // Rearrange: 0.5*a*t^2 + v0*t + (y0 - y) = 0
        // Solve quadratic equation
        const a = 0.5 * acceleration;
        const b = initialVy;
        const c = distance;
        
        if (Math.abs(a) < 0.001) {
            // No acceleration, constant velocity
            return distance / Math.abs(initialVy);
        }
        
        const discriminant = b*b - 4*a*c;
        if (discriminant < 0) {
            // Target unreachable, will reach peak first
            // Time to reach peak: v = v0 + at, when v=0: t = -v0/a
            return Math.abs(initialVy / acceleration);
        }
        
        // Take the positive root
        const t1 = (-b + Math.sqrt(discriminant)) / (2*a);
        const t2 = (-b - Math.sqrt(discriminant)) / (2*a);
        const t = Math.max(t1, t2);
        
        // Convert from frames to seconds (assuming 60 FPS)
        return t / 60;
    }

    shouldExplode() {
        // Instant explode mode
        if (this.shouldExplodeImmediately) {
            return true;
        }
        // Skip rocket mode - explode immediately
        if (this.skipRocket) {
            return true;
        }
        // Normal mode - explode when rocket velocity becomes downward OR reaches target height
        if (this.rocket) {
            return (this.rocket.vy >= 0 || this.rocket.y <= this.targetY) && !this.exploded;
        }
        return false;
    }
    
    explode() {
        this.exploded = true;
        
        // Play explosion sound if callback is set
        if (this.onExplodeSound) {
            if (DEBUG) console.log('[Fireworks] Explosion callback triggered - playing explosion sound');
            this.onExplodeSound(this.intensity);
        } else {
            if (DEBUG) console.log('[Fireworks] Explosion occurred but no audio callback set');
        }
        
        // For instant explode, use the position from constructor
        const explosionX = this.rocket ? this.rocket.x : this.x;
        const explosionY = this.rocket ? this.rocket.y : this.y;
        
        // Calculate particle count based on intensity and tier
        const tierMultipliers = {
            small: 0.5,
            medium: 1.0,
            big: 1.5,
            massive: 2.0
        };
        const tierMult = tierMultipliers[this.tier] || 1.0;
        const comboMult = 1 + (this.combo - 1) * 0.2;
        
        // Reduce particles for high combos to improve performance
        // Aggressive combo reduction for better FPS
        let baseParticles = 40 + Math.random() * 60;
        if (this.combo >= 20) {
            baseParticles *= 0.2; // 80% reduction for combo >= 20
        } else if (this.combo >= 10) {
            baseParticles *= 0.5; // 50% particles for combo >= 10
        } else if (this.combo >= 5) {
            baseParticles *= 0.7; // 70% particles for combo >= 5
        }
        
        // Additional FPS-based reduction - reduce particles when FPS is low
        if (this.engineFps < 30) {
            baseParticles *= 0.5; // 50% reduction when FPS < 30
        } else if (this.engineFps < 45) {
            baseParticles *= 0.75; // 25% reduction when FPS < 45
        }
        
        const particleCount = Math.floor(baseParticles * this.intensity * tierMult * comboMult);
        
        // Get velocities from shape generator
        const generator = ShapeGenerators[this.shape] || ShapeGenerators.burst;
        const velocities = generator(particleCount, this.intensity);
        
        // Create explosion particles
        for (let i = 0; i < velocities.length; i++) {
            const vel = velocities[i];
            const hue = this.baseHue + (Math.random() * this.hueRange);
            const isSparkle = Math.random() < CONFIG.sparkleChance;
            
            // Determine particle appearance
            // Priority: shape-specific particle types > gift images > standard circles
            let particleType = vel.particleType || 'circle'; // Use shape-specific type if provided
            let particleImage = null;
            
            // Override with gift/avatar images for non-shape-specific particles
            if (particleType === 'circle' && !isSparkle && this.giftImage) {
                // Use gift image for explosion particles (70% chance when available)
                if (Math.random() < 0.7) {
                    particleType = 'image';
                    particleImage = this.giftImage;
                }
            } else if (particleType === 'circle' && !isSparkle && this.userAvatar && Math.random() < 0.3) {
                // Use avatar occasionally if no gift image (30% chance)
                particleType = 'image';
                particleImage = this.userAvatar;
            }
            
            const particle = globalParticlePool ? globalParticlePool.acquire({
                x: explosionX,
                y: explosionY,
                vx: vel.vx,
                vy: vel.vy,
                size: (isSparkle ? 2 + Math.random() * 2 : (particleType === 'image' ? 4 + Math.random() * 4 : 3 + Math.random() * 4)) * this.adaptiveParticleSizeScale,
                hue: hue,
                saturation: isSparkle ? 100 : 90,
                brightness: isSparkle ? 100 : 95,
                lifespan: isSparkle ? 0.6 + Math.random() * 0.4 : 0.8 + Math.random() * 0.6,
                decay: isSparkle ? 0.015 : 0.008,
                isSeed: false,
                isSparkle: isSparkle,
                type: particleType,
                image: particleImage,
                // Texture Atlas index: 0=circle, 1=heart, 2=paw, 3+=gift/avatar
                textureIndex: particleType === 'heart' ? 1 :
                             particleType === 'paw' ? 2 :
                             (particleType === 'image' && particleImage) ? (this.giftTextureIndex || 3) :
                             0,
                mass: isSparkle ? 0.5 : 1,
                drag: isSparkle ? 0.97 : 0.98,
                gravity: isSparkle ? CONFIG.gravity * 0.8 : CONFIG.gravity,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.1,
                // Pass through secondary explosion properties from velocity data
                willBurst: vel.willBurst || false,
                burstDelay: vel.burstDelay || 0,
                willSpiral: vel.willSpiral || false,
                spiralDelay: vel.spiralDelay || 0
            }) : new Particle({
                x: explosionX,
                y: explosionY,
                vx: vel.vx,
                vy: vel.vy,
                size: (isSparkle ? 2 + Math.random() * 2 : (particleType === 'image' ? 4 + Math.random() * 4 : 3 + Math.random() * 4)) * this.adaptiveParticleSizeScale,
                hue: hue,
                saturation: isSparkle ? 100 : 90,
                brightness: isSparkle ? 100 : 95,
                lifespan: isSparkle ? 0.6 + Math.random() * 0.4 : 0.8 + Math.random() * 0.6,
                decay: isSparkle ? 0.015 : 0.008,
                isSeed: false,
                isSparkle: isSparkle,
                type: particleType,
                image: particleImage,
                // Texture Atlas index: 0=circle, 1=heart, 2=paw, 3+=gift/avatar
                textureIndex: particleType === 'heart' ? 1 :
                             particleType === 'paw' ? 2 :
                             (particleType === 'image' && particleImage) ? (this.giftTextureIndex || 3) :
                             0,
                mass: isSparkle ? 0.5 : 1,
                drag: isSparkle ? 0.97 : 0.98,
                gravity: isSparkle ? CONFIG.gravity * 0.8 : CONFIG.gravity,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.1,
                // Pass through secondary explosion properties from velocity data
                willBurst: vel.willBurst || false,
                burstDelay: vel.burstDelay || 0,
                willSpiral: vel.willSpiral || false,
                spiralDelay: vel.spiralDelay || 0
            });
            
            this.particles.push(particle);
            
            // Chance for secondary explosion (only for non-image particles to avoid lag)
            // Disable for high combos or low FPS to improve performance
            // Only allow secondary explosions when combo < 5 AND fps > 40
            if (this.combo < 5 && this.engineFps > 40 && Math.random() < CONFIG.secondaryExplosionChance && !isSparkle && particleType === 'circle') {
                particle.willExplode = true;
                particle.explosionDelay = 20 + Math.floor(Math.random() * 30);
            }
        }
    }
    
    update(deltaTime = 1.0) {
        // Handle instant explode mode
        if (this.shouldExplodeImmediately && !this.exploded) {
            this.explode();
            this.shouldExplodeImmediately = false;
            return;
        }
        
        // Update rocket (if exists and not exploded)
        if (!this.exploded && this.rocket) {
            this.rocket.applyGravity();
            this.rocket.update(deltaTime);
            
            if (this.shouldExplode()) {
                this.explode();
            }
        }
        
        // Update explosion particles
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.applyGravity();
            p.update(deltaTime);
            
            // Check for secondary mini-burst (burst shape)
            if (p.willBurst && !p.hasBurst && performance.now() - p.burstTime >= p.burstDelay) {
                p.hasBurst = true;
                this.createMiniBurst(p);
                // Trigger crackling sound callback
                if (this.onSecondaryExplosionSound && !this.secondaryAudioPlayed) {
                    this.secondaryAudioPlayed = true;
                    this.onSecondaryExplosionSound();
                }
            }
            
            // Check for secondary spiral burst (spiral shape)
            if (p.willSpiral && !p.hasSpiraled && performance.now() - p.burstTime >= p.spiralDelay) {
                p.hasSpiraled = true;
                this.createSpiralBurst(p);
                // Trigger crackling sound callback
                if (this.onSecondaryExplosionSound && !this.secondaryAudioPlayed) {
                    this.secondaryAudioPlayed = true;
                    this.onSecondaryExplosionSound();
                }
            }
            
            // Check for secondary explosions
            if (p.willExplode && p.age >= p.explosionDelay && !p.exploded) {
                p.exploded = true;
                this.createSecondaryExplosion(p);
            }
            
            // Remove dead particles
            if (p.isDone()) {
                if (globalParticlePool) {
                    globalParticlePool.release(p);
                }
                this.particles[i] = this.particles[this.particles.length - 1];
                this.particles.pop();
            }
        }
        
        // Update secondary explosions
        for (let i = this.secondaryExplosions.length - 1; i >= 0; i--) {
            const p = this.secondaryExplosions[i];
            p.applyGravity();
            p.update(deltaTime);
            
            if (p.isDone()) {
                if (globalParticlePool) {
                    globalParticlePool.release(p);
                }
                this.secondaryExplosions[i] = this.secondaryExplosions[this.secondaryExplosions.length - 1];
                this.secondaryExplosions.pop();
            }
        }
    }
    
    createSecondaryExplosion(sourceParticle) {
        const count = 8 + Math.floor(Math.random() * 12);
        
        for (let i = 0; i < count; i++) {
            const angle = (Math.PI * 2 * i) / count;
            const speed = 1 + Math.random() * 2;
            
            const particle = globalParticlePool ? globalParticlePool.acquire({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 1 + Math.random() * 2,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 30,
                saturation: 100,
                brightness: 100,
                lifespan: 0.4 + Math.random() * 0.3,
                decay: 0.02,
                isSeed: false,
                isSparkle: true,
                mass: 0.3,
                drag: 0.96,
                gravity: CONFIG.gravity * 0.6
            }) : new Particle({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 1 + Math.random() * 2,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 30,
                saturation: 100,
                brightness: 100,
                lifespan: 0.4 + Math.random() * 0.3,
                decay: 0.02,
                isSeed: false,
                isSparkle: true,
                mass: 0.3,
                drag: 0.96,
                gravity: CONFIG.gravity * 0.6
            });
            
            this.secondaryExplosions.push(particle);
        }
    }
    
    createMiniBurst(sourceParticle) {
        // Mini-burst: particle bursts into smaller dots
        const count = 4 + Math.floor(Math.random() * 5); // 4-8 mini particles
        
        for (let i = 0; i < count; i++) {
            const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
            const speed = 0.8 + Math.random() * 1.2;
            
            const particle = globalParticlePool ? globalParticlePool.acquire({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: sourceParticle.vx * 0.3 + Math.cos(angle) * speed,
                vy: sourceParticle.vy * 0.3 + Math.sin(angle) * speed,
                size: 1 + Math.random() * 1.5,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 20,
                saturation: 90,
                brightness: 95,
                lifespan: 0.3 + Math.random() * 0.2,
                decay: 0.025,
                isSeed: false,
                isSparkle: true,
                mass: 0.2,
                drag: 0.95,
                gravity: CONFIG.gravity * 0.5
            }) : new Particle({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: sourceParticle.vx * 0.3 + Math.cos(angle) * speed,
                vy: sourceParticle.vy * 0.3 + Math.sin(angle) * speed,
                size: 1 + Math.random() * 1.5,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 20,
                saturation: 90,
                brightness: 95,
                lifespan: 0.3 + Math.random() * 0.2,
                decay: 0.025,
                isSeed: false,
                isSparkle: true,
                mass: 0.2,
                drag: 0.95,
                gravity: CONFIG.gravity * 0.5
            });
            
            this.secondaryExplosions.push(particle);
        }
    }
    
    createSpiralBurst(sourceParticle) {
        // Spiral burst: particle emits spiral mini-burst
        const count = 3 + Math.floor(Math.random() * 4); // 3-6 spiral particles
        const spiralTurns = 1.5;
        
        for (let i = 0; i < count; i++) {
            const t = (i / count) * spiralTurns * Math.PI * 2;
            const radius = 0.5 + (i / count) * 0.8;
            const speed = 1.0 + Math.random() * 0.8;
            
            const particle = globalParticlePool ? globalParticlePool.acquire({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: sourceParticle.vx * 0.2 + Math.cos(t) * radius * speed,
                vy: sourceParticle.vy * 0.2 + Math.sin(t) * radius * speed,
                size: 1.2 + Math.random() * 1.5,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 25,
                saturation: 85,
                brightness: 90,
                lifespan: 0.35 + Math.random() * 0.25,
                decay: 0.022,
                isSeed: false,
                isSparkle: true,
                mass: 0.25,
                drag: 0.94,
                gravity: CONFIG.gravity * 0.4,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.15
            }) : new Particle({
                x: sourceParticle.x,
                y: sourceParticle.y,
                vx: sourceParticle.vx * 0.2 + Math.cos(t) * radius * speed,
                vy: sourceParticle.vy * 0.2 + Math.sin(t) * radius * speed,
                size: 1.2 + Math.random() * 1.5,
                hue: sourceParticle.hue + (Math.random() - 0.5) * 25,
                saturation: 85,
                brightness: 90,
                lifespan: 0.35 + Math.random() * 0.25,
                decay: 0.022,
                isSeed: false,
                isSparkle: true,
                mass: 0.25,
                drag: 0.94,
                gravity: CONFIG.gravity * 0.4,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 0.15
            });
            
            this.secondaryExplosions.push(particle);
        }
    }
    
    isDone() {
        return this.exploded && 
               this.particles.length === 0 && 
               this.secondaryExplosions.length === 0;
    }
}

// ============================================================================
// SHAPE GENERATORS - Mathematical patterns for explosions
// ============================================================================

const ShapeGenerators = {
    burst: (count, intensity) => {
        const particles = [];
        const rings = 2 + Math.floor(intensity);
        const particlesPerRing = Math.floor(count / rings);
        
        for (let ring = 0; ring < rings; ring++) {
            const ringSpeed = (2 + Math.random() * 2) * (1 + ring * 0.3) * intensity;
            for (let i = 0; i < particlesPerRing; i++) {
                const angle = (Math.PI * 2 * i) / particlesPerRing + (Math.random() - 0.5) * 0.2;
                particles.push({
                    vx: Math.cos(angle) * ringSpeed,
                    vy: Math.sin(angle) * ringSpeed,
                    willBurst: true, // Mark for secondary mini-burst
                    burstDelay: 500 + Math.random() * 300 // 0.5-0.8s delay
                });
            }
        }
        return particles;
    },

    heart: (count, intensity) => {
        const particles = [];
        const layers = 4; // More layers for denser, more recognizable heart
        const particlesPerLayer = Math.floor(count / layers);
        
        for (let layer = 0; layer < layers; layer++) {
            const layerScale = 0.5 + (layer * 0.15); // Tighter sizing for better shape
            for (let i = 0; i < particlesPerLayer; i++) {
                const t = (i / particlesPerLayer) * Math.PI * 2;
                // Enhanced parametric heart equation for better recognition
                const x = 16 * Math.pow(Math.sin(t), 3);
                const y = -(13 * Math.cos(t) - 5 * Math.cos(2*t) - 2 * Math.cos(3*t) - Math.cos(4*t));
                
                const mag = Math.max(Math.sqrt(x*x + y*y), 1);
                const speed = (0.15 + Math.random() * 0.05) * intensity * layerScale; // Tighter speed for clustering
                particles.push({
                    vx: (x / mag) * speed * 8, // Reduced multiplier for tighter clustering
                    vy: (y / mag) * speed * 8,
                    particleType: 'heart' // Mark as heart-shaped particles
                });
            }
        }
        return particles;
    },

    star: (count, intensity) => {
        const particles = [];
        const points = 5; // 5-pointed star
        const layers = 2; // Inner and outer layers for better definition
        const particlesPerPoint = Math.floor(count / (points * 2)); // Particles per point tip
        
        for (let point = 0; point < points; point++) {
            // Outer point angle
            const outerAngle = (Math.PI * 2 * point) / points - Math.PI / 2;
            // Inner valley angle (between two points)
            const innerAngle = outerAngle + (Math.PI / points);
            
            // Outer point (star tip)
            for (let i = 0; i < particlesPerPoint; i++) {
                const t = i / particlesPerPoint;
                const spread = (Math.random() - 0.5) * 0.15; // Slight spread
                const angle = outerAngle + spread;
                const radiusMix = 0.8 + t * 0.4; // Gradient from center to tip
                const speed = (2 + Math.random() * 1) * intensity * radiusMix;
                particles.push({
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed
                });
            }
            
            // Inner valley (between points)
            for (let i = 0; i < particlesPerPoint / 2; i++) {
                const t = i / (particlesPerPoint / 2);
                const spread = (Math.random() - 0.5) * 0.1;
                const angle = innerAngle + spread;
                const radiusMix = 0.3 + t * 0.3; // Shorter for valley
                const speed = (1.5 + Math.random() * 0.8) * intensity * radiusMix;
                particles.push({
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed
                });
            }
        }
        return particles;
    },

    spiral: (count, intensity) => {
        const particles = [];
        const turns = 4;
        const arms = 3;
        
        for (let i = 0; i < count; i++) {
            const t = (i / count) * turns * Math.PI * 2;
            const armOffset = (Math.floor(i * arms / count) * Math.PI * 2) / arms;
            const radius = (i / count) * intensity * 0.8;
            const speed = 1.5 + Math.random() * 1.5;
            particles.push({
                vx: Math.cos(t + armOffset) * radius * speed,
                vy: Math.sin(t + armOffset) * radius * speed,
                willSpiral: true, // Mark for secondary spiral burst
                spiralDelay: 600 + Math.random() * 400 // 0.6-1.0s delay
            });
        }
        return particles;
    },
    
    paws: (count, intensity) => {
        const particles = [];
        // Paw print layout: 1 large center pad + 4 toe pads
        const centerPadParticles = Math.floor(count * 0.4); // 40% for center
        const toeParticles = Math.floor((count - centerPadParticles) / 4); // Split rest among 4 toes
        
        // Center pad (large, bottom-center)
        for (let i = 0; i < centerPadParticles; i++) {
            const angle = (Math.PI * 2 * i) / centerPadParticles + Math.random() * 0.3;
            const radius = 0.3 + Math.random() * 0.2;
            const speed = (0.8 + Math.random() * 0.4) * intensity;
            const offsetY = 0.6; // Position lower for center pad
            particles.push({
                vx: Math.cos(angle) * radius * speed,
                vy: (Math.sin(angle) * radius * speed) + (offsetY * intensity),
                particleType: 'paw' // Paw emoji particles
            });
        }
        
        // 4 toe pads (smaller, arranged around top in arc)
        const toePositions = [
            { angle: -2.4, distance: 1.2 }, // Top-left
            { angle: -1.8, distance: 1.4 }, // Mid-left
            { angle: -1.3, distance: 1.4 }, // Mid-right
            { angle: -0.7, distance: 1.2 }  // Top-right
        ];
        
        for (let toe = 0; toe < 4; toe++) {
            const toePos = toePositions[toe];
            for (let i = 0; i < toeParticles; i++) {
                const localAngle = (Math.PI * 2 * i) / toeParticles;
                const radius = 0.15 + Math.random() * 0.1;
                const speed = (0.6 + Math.random() * 0.3) * intensity;
                
                // Calculate toe pad position
                const basex = Math.cos(toePos.angle) * toePos.distance;
                const basey = Math.sin(toePos.angle) * toePos.distance;
                
                particles.push({
                    vx: (basex + Math.cos(localAngle) * radius) * speed,
                    vy: (basey + Math.sin(localAngle) * radius) * speed,
                    particleType: 'paw' // Paw emoji particles
                });
            }
        }
        
        return particles;
    },

    ring: (count, intensity) => {
        const particles = [];
        const rings = 2 + Math.floor(intensity * 0.5);
        
        for (let ring = 0; ring < rings; ring++) {
            const ringParticles = Math.floor(count / rings);
            const ringRadius = (ring + 1) / rings;
            
            for (let i = 0; i < ringParticles; i++) {
                const angle = (Math.PI * 2 * i) / ringParticles;
                const speed = (3 + Math.random()) * intensity * ringRadius;
                particles.push({
                    vx: Math.cos(angle) * speed,
                    vy: Math.sin(angle) * speed
                });
            }
        }
        return particles;
    },

    fountain: (count, intensity) => {
        const particles = [];
        for (let i = 0; i < count; i++) {
            const angle = -Math.PI/2 + (Math.random() - 0.5) * Math.PI * 0.6;
            const speed = (2 + Math.random() * 3) * intensity;
            particles.push({
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed
            });
        }
        return particles;
    },

    willow: (count, intensity) => {
        const particles = [];
        for (let i = 0; i < count; i++) {
            const angle = (Math.PI * 2 * i) / count;
            const speedVariation = 0.7 + Math.random() * 0.6;
            const speed = 2 * intensity * speedVariation;
            particles.push({
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 1 // Downward bias for willow effect
            });
        }
        return particles;
    }
};

// ============================================================================
// AUDIO MANAGER
// ============================================================================

class AudioManager {
    constructor() {
        this.sounds = new Map();
        this.audioContext = null;
        this.volume = 0.7;
        this.enabled = true;
        this.initialized = false;
        this.pendingSounds = new Map();
        
        // Audio selection constants for performance
        this.TINY_BANG_SOUNDS = ['combined-whistle-tiny1', 'combined-whistle-tiny2', 'combined-whistle-tiny3', 'combined-whistle-tiny4'];
        this.SMALL_SOUNDS = ['combined-whistle-tiny1', 'combined-whistle-tiny2', 'combined-whistle-tiny3'];
        
        // Launch sound variations for more variety
        this.BASIC_LAUNCH_SOUNDS = ['launch-basic', 'launch-basic2', 'rocket-basic'];
        this.SMOOTH_LAUNCH_SOUNDS = ['launch-smooth', 'launch-smooth2'];
        this.ALL_LAUNCH_SOUNDS = ['launch-basic', 'launch-basic2', 'rocket-basic', 'launch-whistle', 'launch-smooth', 'launch-smooth2'];
        
        // Explosion sounds organized by tier for better matching with firework size
        this.EXPLOSION_SMALL = ['explosion-basic', 'explosion-small', 'explosion-alt1']; // Short, quick explosions
        this.EXPLOSION_MEDIUM = ['explosion-medium', 'explosion-alt2', 'explosion-pop']; // Medium explosions
        this.EXPLOSION_BIG = ['explosion-big', 'explosion-huge']; // Big, powerful explosions
        this.EXPLOSION_ALL = ['explosion-basic', 'explosion-small', 'explosion-medium', 'explosion-alt1', 'explosion-alt2', 'explosion-big', 'explosion-huge', 'explosion-pop'];
        
        // Crackling sounds for atmospheric effects (can be layered with explosions)
        this.CRACKLING_SOUNDS = ['crackling-medium', 'crackling-long'];
        
        // Volume constants for consistent audio levels (updated for better balance)
        this.COMBINED_AUDIO_VOLUME = 0.65;       // Volume for combined (launch+explosion) audio
        this.LAUNCH_AUDIO_VOLUME = 0.45;         // Volume for separate launch sounds
        this.NORMAL_EXPLOSION_VOLUME = 0.7;      // Volume for normal explosions
        this.INSTANT_EXPLODE_VOLUME = 0.25;      // Volume for instant explosions (high combos)
        this.CRACKLING_VOLUME = 0.35;            // Volume for crackling effects (layered, so quieter)
        
        // Per-file volume multipliers for balancing inherent loudness differences
        // Analyzed based on file size and perceived loudness
        this.AUDIO_VOLUME_MULTIPLIERS = {
            // Loud explosions - reduce volume
            'explosion-huge': 0.7,      // Very loud, long explosion
            'explosion-big': 0.8,       // Loud explosion
            'explosion-pop': 0.75,      // Sharp, loud pop
            
            // Quiet sounds - boost volume
            'explosion-basic': 1.3,     // Very short, quiet pop
            'explosion-alt1': 1.1,      // Slightly quiet
            'rocket-basic': 1.2,        // Short launch sound
            
            // Crackling - reduce for layering
            'crackling-long': 0.6,      // Very long, loud atmospheric
            'crackling-medium': 0.7,    // Medium atmospheric
            
            // Launch sounds - slight boost for presence
            'launch-basic': 1.1,
            'launch-basic2': 1.1,
            'launch-whistle': 1.0,
            'launch-smooth': 1.0,
            'launch-smooth2': 1.0,
            
            // Combined audio - standard
            'combined-crackling-bang': 1.0,
            'combined-whistle-normal': 1.0,
            'combined-whistle-tiny1': 1.0,
            'combined-whistle-tiny2': 1.0,
            'combined-whistle-tiny3': 1.0,
            'combined-whistle-tiny4': 0.9,  // Longer file (3.42s vs 1.15s), slightly reduced volume
            
            // Medium explosions - standard to slight boost
            'explosion-medium': 1.0,
            'explosion-small': 1.0,
            'explosion-alt2': 1.0
        };
    }

    async init() {
        this.initialized = true;
        if (DEBUG) console.log('[Fireworks Audio] Audio manager ready');
    }

    async ensureAudioContext() {
        if (!this.audioContext && this.initialized) {
            try {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                if (this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
                
                for (const [name, url] of this.pendingSounds.entries()) {
                    await this.preload(url, name);
                }
                this.pendingSounds.clear();
                
                if (DEBUG) console.log('[Fireworks Audio] AudioContext created');
            } catch (e) {
                console.warn('[Fireworks Audio] AudioContext not available:', e.message);
            }
        }
    }

    async preload(url, name) {
        if (!this.audioContext) {
            this.pendingSounds.set(name, url);
            return;
        }
        
        if (this.sounds.has(name)) return;
        
        try {
            const response = await fetch(url);
            if (!response.ok) {
                console.info(`[Fireworks Audio] Audio file not found: ${url} (this is normal if not yet added)`);
                return;
            }
            
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);
            this.sounds.set(name, audioBuffer);
            if (DEBUG) console.log(`[Fireworks Audio] Loaded: ${name}`);
        } catch (e) {
            console.info(`[Fireworks Audio] Could not load ${url}:`, e.message, '(add audio files to enable sounds)');
        }
    }

    async play(name, volume = 1.0) {
        if (!this.enabled) return;
        
        await this.ensureAudioContext();
        
        if (!this.audioContext || !this.sounds.has(name)) return;
        
        try {
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            const source = this.audioContext.createBufferSource();
            const gainNode = this.audioContext.createGain();
            
            source.buffer = this.sounds.get(name);
            
            // Apply per-file volume multiplier if exists
            const volumeMultiplier = this.AUDIO_VOLUME_MULTIPLIERS[name] || 1.0;
            gainNode.gain.value = this.volume * volume * volumeMultiplier;
            
            source.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            source.start(0);
        } catch (e) {
            console.warn('[Fireworks Audio] Playback error:', e.message);
        }
    }

    /**
     * Play a sound with automatic fade-out after a specified duration.
     * Perfect for crackling sounds that should fade out when visual effects end.
     * 
     * @param {string} name - The name of the sound to play (must be preloaded)
     * @param {number} volume - Volume multiplier (0.0 to 1.0), will be multiplied by global volume
     * @param {number} duration - Total duration in seconds before fade starts
     * @param {number} fadeOutDuration - Duration of the fade-out in seconds (default: 0.5s)
     * 
     * @example
     * // Play crackling for 2 seconds, then fade out over 0.5 seconds
     * await audioManager.playWithFadeOut('crackling-long', 0.35, 2.0, 0.5);
     */
    async playWithFadeOut(name, volume = 1.0, duration = 2.0, fadeOutDuration = 0.5) {
        if (!this.enabled) return;
        
        await this.ensureAudioContext();
        
        if (!this.audioContext || !this.sounds.has(name)) return;
        
        try {
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            const source = this.audioContext.createBufferSource();
            const gainNode = this.audioContext.createGain();
            
            source.buffer = this.sounds.get(name);
            
            // Apply per-file volume multiplier if exists
            const volumeMultiplier = this.AUDIO_VOLUME_MULTIPLIERS[name] || 1.0;
            const finalVolume = this.volume * volume * volumeMultiplier;
            
            // Set initial volume
            gainNode.gain.value = finalVolume;
            
            source.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            // Start playback
            const startTime = this.audioContext.currentTime;
            source.start(0);
            
            // Schedule fade-out
            const fadeStartTime = startTime + duration;
            const fadeEndTime = fadeStartTime + fadeOutDuration;
            
            // Exponential fade-out for more natural sound
            gainNode.gain.setValueAtTime(finalVolume, fadeStartTime);
            gainNode.gain.exponentialRampToValueAtTime(0.00001, fadeEndTime); // Very small value to avoid audio artifacts
            gainNode.gain.setValueAtTime(0, fadeEndTime); // Ensure complete silence
            
            // Stop the source after fade completes
            source.stop(fadeEndTime + 0.1);
            
            if (CONFIG.debugMode) {
                if (DEBUG) console.log(`[Fireworks Audio] Playing ${name} with fade-out: duration=${duration}s, fade=${fadeOutDuration}s`);
            }
        } catch (e) {
            console.warn('[Fireworks Audio] Fade-out playback error:', e.message);
        }
    }

    setVolume(volume) {
        this.volume = Math.max(0, Math.min(1, volume));
    }

    setEnabled(enabled) {
        this.enabled = enabled;
    }

    /**
     * Play a sound after a specified delay (in seconds).
     * Useful for synchronizing explosion sounds with visual explosions when using separate audio files.
     * 
     * @param {string} name - The name of the sound to play (must be preloaded)
     * @param {number} delay - Delay in seconds before playing the sound
     * @param {number} [volume=1.0] - Volume multiplier (0.0 to 1.0), will be multiplied by global volume
     * 
     * @example
     * // Play explosion sound after 2 seconds
     * await audioManager.playDelayed('explosion-basic', 2.0, 0.8);
     */
    async playDelayed(name, delay, volume = 1.0) {
        if (!this.enabled) return;
        
        await this.ensureAudioContext();
        
        if (!this.audioContext || !this.sounds.has(name)) return;
        
        try {
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            const source = this.audioContext.createBufferSource();
            const gainNode = this.audioContext.createGain();
            
            source.buffer = this.sounds.get(name);
            gainNode.gain.value = this.volume * volume;
            
            source.connect(gainNode);
            gainNode.connect(this.audioContext.destination);
            
            // Schedule playback after delay
            const startTime = this.audioContext.currentTime + delay;
            source.start(startTime);
        } catch (e) {
            console.warn('[Fireworks Audio] Delayed playback error:', e.message);
        }
    }

    /**
     * Select appropriate audio based on firework tier and combo.
     * Returns an object with audio configuration for synchronized playback.
     * 
     * SYNCHRONIZATION STRATEGY (FINAL FIX - 100% CALLBACK-BASED):
     * - Launch sound plays immediately when rocket fires
     * - Explosion sound triggers via onExplodeSound callback EXACTLY when visual explodes
     * - **Perfect synchronization guaranteed** regardless of rocket flight time variations
     * 
     * WHY CALLBACK-ONLY:
     * - Combined audio files have FIXED explosion timing (1.0s, 3.3s, 4.8s)
     * - Rocket flight times VARY (0.8s to 5.5s) based on physics and target position
     * - Using combined audio caused delays when flight time didn't match audio timing
     * - Callback ensures explosion sound always matches visual explosion perfectly
     * 
     * @param {string} tier - Firework tier: 'small', 'medium', 'big', or 'massive'
     * @param {number} combo - Current combo count (affects audio selection)
     * @param {boolean} [instantExplode=false] - Whether firework explodes instantly (no rocket animation)
     * @returns {Object} Audio configuration with sound names (always callback-based)
     */
    selectAudio(tier, combo, instantExplode = false) {
        // For instant explosions (high combo), use appropriate explosion based on tier
        if (instantExplode) {
            return {
                useCombinedAudio: false,
                launchSound: null,
                explosionSound: tier === 'massive' ? 'explosion-huge' :
                               tier === 'big' ? 'explosion-big' :
                               tier === 'medium' ? 'explosion-medium' :
                               'explosion-basic',
                cracklingSound: null
            };
        }

        // For high combos (5-7), use quick sounds for rapid bursts
        if (combo >= 5 && combo < 8) {
            return {
                useCombinedAudio: false,
                launchSound: this.BASIC_LAUNCH_SOUNDS[Math.floor(Math.random() * this.BASIC_LAUNCH_SOUNDS.length)],
                explosionSound: this.EXPLOSION_SMALL[Math.floor(Math.random() * this.EXPLOSION_SMALL.length)],
                cracklingSound: null
            };
        }

        // Random value for variety
        const rand = Math.random();

        switch (tier) {
            case 'small':
                // Small rockets: varied launch sounds + small explosions
                const smallLaunch = rand < 0.7
                    ? this.BASIC_LAUNCH_SOUNDS[Math.floor(Math.random() * this.BASIC_LAUNCH_SOUNDS.length)]
                    : 'launch-whistle';
                
                return {
                    useCombinedAudio: false,
                    launchSound: smallLaunch,
                    explosionSound: this.EXPLOSION_SMALL[Math.floor(Math.random() * this.EXPLOSION_SMALL.length)],
                    cracklingSound: null
                };

            case 'medium':
                // Medium rockets: smooth/whistle launches + medium explosions
                const mediumLaunch = rand < 0.6
                    ? this.SMOOTH_LAUNCH_SOUNDS[Math.floor(Math.random() * this.SMOOTH_LAUNCH_SOUNDS.length)]
                    : 'launch-whistle';
                
                return {
                    useCombinedAudio: false,
                    launchSound: mediumLaunch,
                    explosionSound: this.EXPLOSION_MEDIUM[Math.floor(Math.random() * this.EXPLOSION_MEDIUM.length)],
                    cracklingSound: null
                };

            case 'big':
                // Big rockets: whistle launches + big explosions + crackling (40%)
                return {
                    useCombinedAudio: false,
                    launchSound: 'launch-whistle',
                    explosionSound: this.EXPLOSION_BIG[Math.floor(Math.random() * this.EXPLOSION_BIG.length)],
                    cracklingSound: Math.random() < 0.4 ? this.CRACKLING_SOUNDS[Math.floor(Math.random() * this.CRACKLING_SOUNDS.length)] : null
                };

            case 'massive':
                // Massive rockets: whistle launches + huge explosions + crackling (70%)
                return {
                    useCombinedAudio: false,
                    launchSound: 'launch-whistle',
                    explosionSound: 'explosion-huge',
                    cracklingSound: Math.random() < 0.7 ? this.CRACKLING_SOUNDS[Math.floor(Math.random() * this.CRACKLING_SOUNDS.length)] : null
                };

            default:
                // Fallback to small if tier is unknown
                return {
                    useCombinedAudio: false,
                    launchSound: this.BASIC_LAUNCH_SOUNDS[0],
                    explosionSound: this.EXPLOSION_SMALL[0],
                    cracklingSound: null
                };
        }
    }
}

// ============================================================================
// FIREWORKS ENGINE - Main rendering and orchestration
// ============================================================================

class FireworksEngine {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        
        // WebGL rendering engine (initialized in init() if available)
        this.webglEngine = null;
        this.useWebGL = false;
        this.rendererMode = 'canvas'; // 'webgl' or 'canvas'
        
        // Optimization #6: Layer splitting for performance
        this.trailCanvas = null;
        this.trailCtx = null;
        this.useLayerSplitting = true;  // Can be disabled
        this.trailUpdateInterval = 2;   // Update trails every N frames
        this.trailFrameCounter = 0;
        
        this.fireworks = [];
        this.audioManager = new AudioManager();
        
        // Initialize particle pool for high performance
        if (!globalParticlePool) {
            globalParticlePool = new ParticlePool(1000);  // Optimization #5: Reduced from 5000
        }
        this.particlePool = globalParticlePool;
        
        this.lastTime = performance.now();
        this.lastRenderTime = performance.now(); // Track last actual render time for FPS limiting
        this.frameCount = 0;
        this.fps = 0;
        this.fpsUpdateTime = performance.now();
        this.fpsHistory = []; // Track FPS history for adaptive performance
        this.performanceMode = 'normal'; // 'normal', 'reduced', 'minimal'
        
        // Optimization #10: Frame-skip for critical load
        this.skippedFrames = 0;
        
        // Freeze detection and failsafe
        this.freezeDetectionEnabled = true; // Can be disabled for debugging
        this.frozenFrameCount = 0; // Count consecutive frames with 0 FPS
        this.maxFrozenFrames = 3; // Reload after 3 consecutive seconds of 0 FPS
        this.freezeWarningShown = false;
        
        // Combo throttling to prevent extreme lag
        this.lastComboTriggerTime = 0;
        this.comboTriggerQueue = [];
        
        // NEW: Adaptive Frame Skip
        this.adaptivePerformance = true; // Will be updated from config
        this.minTargetFps = 30; // Will be updated from config
        this.frameSkipEnabled = true; // Will be updated from config
        this.frameSkip = 0;
        this.adaptiveFpsHistory = []; // Separate FPS history for adaptive frame skip (30 frames)
        
        // BUG FIX #3: Particle count cache (updated once per frame)
        this.cachedParticleCount = 0;
        this.lastParticleCountUpdate = 0;
        
        this.config = { 
            ...CONFIG,
            renderer: 'webgl', // 'webgl', 'canvas', 'auto' - will be set from main.js config
            toasterMode: false,
            audioEnabled: true,
            audioVolume: 0.7,
            trailsEnabled: true,
            glowEnabled: true,
            resolution: CONFIG.resolution,
            resolutionPreset: CONFIG.resolutionPreset,
            orientation: CONFIG.orientation,
            adaptiveRenderScaleEnabled: CONFIG.adaptiveRenderScaleEnabled,
            minRenderScale: CONFIG.minRenderScale,
            targetFps: CONFIG.targetFps,
            minFps: CONFIG.minFps,
            giftPopupPosition: CONFIG.giftPopupPosition
        };
        this.workerModeRequested = typeof window !== 'undefined' && Boolean(window.FIREWORKS_USE_WORKER);
        
        // Performance limits from config (set via fireworks:config-update)
        this.MAX_FIREWORKS = 5; // Will be updated from config
        this.MAX_PARTICLES = 800; // Will be updated from config
        this.EMERGENCY_CLEANUP_THRESHOLD = 1000; // Will be updated from config
        
        // BUG FIX #2: Make engine globally accessible for synchronous access from main.js
        // This allows main.js to get firework count synchronously instead of via async socket
        // which has 10-50ms latency causing race conditions with limits
        if (typeof global !== 'undefined') {
            global.fireworksEngineInstance = this;
        }
        if (typeof window !== 'undefined') {
            window.fireworksEngineInstance = this;
            window.FIREWORKS_CONFIG = this.config;
        }
        
        this.running = false;
        this.socket = null;
        this.imageCache = new Map();
        this.debugMode = false;
        
        this.width = 0;
        this.height = 0;
        this.baseWidth = 0;
        this.baseHeight = 0;
        this.renderScale = 1.0;
        this.targetRenderScale = 1.0;
        this.qualityScale = 1.0;
        this.lastRenderScaleChange = 0;
        this.isBenchmarkMode = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('benchmark') === 'true';
    }

    async init() {
        if (this.workerModeRequested) {
            console.warn('[Fireworks Engine] Worker mode requested; using main-thread renderer fallback.');
        }

        // Setup canvas
        this.resize();
        
        // Try to initialize WebGL renderer (unless toasterMode is enabled)
        this.initRenderer();
        
        // Optimization #6: Initialize layer splitting
        this.initLayerSplitting();
        
        window.addEventListener('resize', () => this.resize());

        // Initialize audio
        await this.audioManager.init();

        // Connect to Socket.io
        this.connectSocket();

        // Start render loop
        this.running = true;
        this.render();

        const rendererName = this.useWebGL ? 'WebGL2' : 'Canvas 2D';
        if (DEBUG) console.log(`[Fireworks Engine] Initialized with ${rendererName}`);
    }
    
    initRenderer() {
        // Force Canvas 2D if toaster mode is enabled
        if (this.config.toasterMode) {
            this.useWebGL = false;
            this.rendererMode = 'canvas';
            if (DEBUG) console.log('[Fireworks] Toaster mode enabled, using Canvas 2D');
            return;
        }
        
        const rendererConfig = this.config.renderer || 'webgl';
        
        // Try WebGL if renderer is 'webgl' or 'auto'
        if (rendererConfig === 'webgl' || rendererConfig === 'auto') {
            try {
                // Load WebGL engine (defined in webgl-particle-engine.js)
                if (typeof WebGLParticleEngine === 'undefined') {
                    console.warn('[Fireworks] WebGLParticleEngine not loaded, falling back to Canvas 2D');
                    this.useWebGL = false;
                    this.rendererMode = 'canvas';
                    return;
                }
                
                this.webglEngine = new WebGLParticleEngine(this.canvas);
                this.webglEngine.preserveDrawingBuffer = this.config.preserveDrawingBuffer ?? true;
                this.webglEngine.desynchronized = this.config.desynchronized ?? true;
                const success = this.webglEngine.init();
                
                if (success) {
                    this.useWebGL = true;
                    this.rendererMode = 'webgl';
                    console.log('[Fireworks] WebGL2 renderer initialized successfully');
                } else {
                    this.useWebGL = false;
                    this.rendererMode = 'canvas';
                    console.log('[Fireworks] WebGL initialization failed, using Canvas 2D fallback');
                }
            } catch (error) {
                console.error('[Fireworks] WebGL initialization error:', error);
                this.useWebGL = false;
                this.rendererMode = 'canvas';
                console.log('[Fireworks] Using Canvas 2D fallback due to error');
            }
        } else {
            // Force Canvas 2D
            this.useWebGL = false;
            this.rendererMode = 'canvas';
            if (DEBUG) console.log('[Fireworks] Canvas 2D renderer configured');
        }
    }

    resize() {
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.getBoundingClientRect();
        
        // Get resolution from preset
        const resolutionPreset = this.config.resolutionPreset || '1080p';
        const orientation = this.config.orientation || 'landscape';
        const targetResolution = this.getResolutionFromPreset(resolutionPreset, orientation);
        
        this.baseWidth = targetResolution.width;
        this.baseHeight = targetResolution.height;
        this.applyRenderScale();
    }

    applyRenderScale() {
        const scale = this.config.adaptiveRenderScaleEnabled === false ? 1.0 : this.renderScale;
        const width = Math.max(320, Math.round(this.baseWidth * scale));
        const height = Math.max(180, Math.round(this.baseHeight * scale));

        this.canvas.width = width;
        this.canvas.height = height;
        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';

        this.width = width;
        this.height = height;
        
        // Resize WebGL engine if active
        if (this.webglEngine && this.useWebGL) {
            this.webglEngine.resize(this.width, this.height);
        }
        
        // Optimization #6: Resize trail canvas too
        if (this.trailCanvas) {
            this.trailCanvas.width = this.width;
            this.trailCanvas.height = this.height;
        }
        
        if (DEBUG) console.log(`[Fireworks] Canvas resolution: ${this.canvas.width}x${this.canvas.height} (base ${this.baseWidth}x${this.baseHeight}, scale ${scale.toFixed(2)})`);
    }
    
    // Optimization #6: Initialize layer splitting for performance
    initLayerSplitting() {
        if (!this.useLayerSplitting) return;
        
        // Create off-screen canvas for trails
        this.trailCanvas = document.createElement('canvas');
        this.trailCanvas.width = this.width;
        this.trailCanvas.height = this.height;
        this.trailCtx = this.trailCanvas.getContext('2d');
        
        if (DEBUG) console.log('[Fireworks] Layer splitting initialized');
    }
    
    getResolutionFromPreset(preset, orientation) {
        const resolutions = {
            '360p': { landscape: { width: 640, height: 360 }, portrait: { width: 360, height: 640 } },
            '540p': { landscape: { width: 960, height: 540 }, portrait: { width: 540, height: 960 } },
            '720p': { landscape: { width: 1280, height: 720 }, portrait: { width: 720, height: 1280 } },
            '1080p': { landscape: { width: 1920, height: 1080 }, portrait: { width: 1080, height: 1920 } },
            '1440p': { landscape: { width: 2560, height: 1440 }, portrait: { width: 1440, height: 2560 } },
            '4k': { landscape: { width: 3840, height: 2160 }, portrait: { width: 2160, height: 3840 } }
        };
        
        const presetData = resolutions[preset] || resolutions['1080p'];
        return orientation === 'portrait' ? presetData.portrait : presetData.landscape;
    }

    connectSocket() {
        try {
            this.socket = io({
                transports: ['websocket', 'polling'],
                reconnection: true,
                reconnectionDelay: 1000
            });

            this.socket.on('connect', () => {
                if (DEBUG) console.log('[Fireworks Engine] Connected to server');
            });

            this.socket.on('fireworks:trigger', (data) => {
                this.handleTrigger(data);
            });

            this.socket.on('fireworks:finale', (data) => {
                this.handleFinale(data);
            });

            this.socket.on('fireworks:follower-animation', (data) => {
                this.showFollowerAnimation(data);
            });
            
            this.socket.on('fireworks:get-active-count', () => {
                this.socket.emit('fireworks:active-count-response', { 
                    count: this.fireworks.length,
                    particles: this.getTotalParticles()
                });
            });

            this.socket.on('fireworks:config-update', (data) => {
                if (data.config) {
                    const oldResolution = this.config.resolution;
                    const oldPreset = this.config.resolutionPreset;
                    const oldOrientation = this.config.orientation;
                    const oldRenderer = this.config.renderer;
                    const oldToasterMode = this.config.toasterMode;
                    
                    Object.assign(this.config, data.config);
                    if (typeof window !== 'undefined') {
                        window.FIREWORKS_CONFIG = this.config;
                    }
                    this.audioManager.setEnabled(this.config.audioEnabled);
                    this.audioManager.setVolume(this.config.audioVolume);
                    
                    // Update CONFIG values for despawn and FPS
                    if (data.config.despawnFadeDuration !== undefined) {
                        CONFIG.despawnFadeDuration = data.config.despawnFadeDuration;
                    }
                    if (data.config.minFps !== undefined) {
                        CONFIG.minFps = data.config.minFps;
                    }
                    if (data.config.targetFps !== undefined) {
                        CONFIG.targetFps = data.config.targetFps;
                    }
                    if (data.config.giftPopupEnabled !== undefined) {
                        CONFIG.giftPopupEnabled = data.config.giftPopupEnabled;
                    }
                    if (data.config.giftPopupPosition !== undefined) {
                        CONFIG.giftPopupPosition = data.config.giftPopupPosition;
                    }
                    
                    // Update performance limits
                    if (data.config.maxConcurrentFireworks !== undefined) {
                        this.MAX_FIREWORKS = data.config.maxConcurrentFireworks;
                    }
                    if (data.config.maxTotalParticles !== undefined) {
                        this.MAX_PARTICLES = data.config.maxTotalParticles;
                    }
                    if (data.config.emergencyCleanupThreshold !== undefined) {
                        this.EMERGENCY_CLEANUP_THRESHOLD = data.config.emergencyCleanupThreshold;
                    }
                    // Adaptive performance settings (handled in render loop)
                    if (data.config.adaptivePerformance !== undefined) {
                        this.adaptivePerformance = data.config.adaptivePerformance;
                    }
                    if (data.config.minTargetFps !== undefined) {
                        this.minTargetFps = data.config.minTargetFps;
                    }
                    if (data.config.frameSkipEnabled !== undefined) {
                        this.frameSkipEnabled = data.config.frameSkipEnabled;
                    }
                    
                    // Re-initialize renderer if renderer or toasterMode changed
                    if (oldRenderer !== this.config.renderer || oldToasterMode !== this.config.toasterMode) {
                        console.log('[Fireworks] Renderer config changed, re-initializing...');
                        this.initRenderer();
                    }
                    
                    // Resize canvas if resolution or orientation changed
                    if (oldResolution !== this.config.resolution || 
                        oldPreset !== this.config.resolutionPreset ||
                        oldOrientation !== this.config.orientation) {
                        this.resize();
                    }
                    
                    if (DEBUG) console.log('[Fireworks] Config updated:', data.config);
                }
            });

            this.socket.on('disconnect', () => {
                if (DEBUG) console.log('[Fireworks Engine] Disconnected from server');
            });
        } catch (e) {
            console.error('[Fireworks Engine] Socket connection error:', e);
        }
    }

    showFollowerAnimation(data) {
        const animationEl = document.getElementById('follower-animation');
        const contentEl = animationEl?.querySelector('.follower-content');
        const usernameEl = document.getElementById('follower-username');
        const avatarEl = document.getElementById('follower-avatar');
        
        if (!animationEl || !contentEl || !usernameEl || !avatarEl) return;
        
        // Remove all previous position, style, size, and entrance classes
        animationEl.className = 'follower-animation';
        contentEl.className = 'follower-content';
        contentEl.style.transform = ''; // Clear inline transform
        
        // Set position class
        const position = data.position || 'center';
        animationEl.classList.add(`pos-${position}`);
        
        // Set size class
        const size = data.size || 'medium';
        animationEl.classList.add(`size-${size}`);
        
        // Apply custom scale if size is 'custom'
        if (size === 'custom') {
            const scale = data.scale || 1.0;
            contentEl.style.transform = `scale(${scale})`;
        }
        
        // Set style class
        const style = data.style || 'gradient-purple';
        contentEl.classList.add(`style-${style}`);
        
        // Set entrance animation class
        const entrance = data.entrance || 'scale';
        animationEl.classList.add(`entrance-${entrance}`);
        
        // Set username
        usernameEl.textContent = data.username || 'Unknown';
        
        // Set thank you text from data if provided
        const thankYouEl = document.getElementById('thank-you-text');
        if (thankYouEl) {
            thankYouEl.textContent = data.thankYouText || 'Thanks for the follow! 💙';
        }
        
        // Set avatar if provided
        if (data.profilePictureUrl) {
            avatarEl.src = data.profilePictureUrl;
            avatarEl.classList.add('show');
        } else {
            avatarEl.classList.remove('show');
        }
        
        // Show animation
        animationEl.classList.add('show');
        
        // Hide after duration
        const duration = data.duration || 3000;
        setTimeout(() => {
            animationEl.classList.remove('show');
            // Clean up after animation completes
            setTimeout(() => {
                animationEl.className = 'follower-animation';
                contentEl.className = 'follower-content';
                contentEl.style.transform = '';
            }, 500); // Wait for exit animation
        }, duration);
    }

    async handleTrigger(data) {
        const {
            position = { x: 0.5, y: 0.5 },
            shape = 'burst',
            colors = this.config.defaultColors,
            intensity = 1.0,
            particleCount = 50,
            giftImage = null,
            userAvatar = null,
            avatarParticleChance = 0.3,
            tier = 'medium',
            username = null,
            coins = 0,
            combo = 1,
            playSound = true,
            // New config values from trigger
            targetFps = null,
            minFps = null,
            despawnFadeDuration = null,
            giftPopupEnabled = null,
            giftPopupPosition = null
        } = data;

        // Update config values if provided
        if (targetFps !== null) {
            this.config.targetFps = targetFps;
            CONFIG.targetFps = targetFps;
        }
        if (minFps !== null) {
            this.config.minFps = minFps;
            CONFIG.minFps = minFps;
        }
        if (despawnFadeDuration !== null) {
            this.config.despawnFadeDuration = despawnFadeDuration;
            CONFIG.despawnFadeDuration = despawnFadeDuration;
        }
        if (giftPopupEnabled !== null) {
            this.config.giftPopupEnabled = giftPopupEnabled;
            CONFIG.giftPopupEnabled = giftPopupEnabled;
        }
        if (giftPopupPosition !== null) {
            this.config.giftPopupPosition = giftPopupPosition;
            CONFIG.giftPopupPosition = giftPopupPosition;
        }

        // Optimization #19: Priority-based queue management
        const MAX_FIREWORKS_NORMAL = 30;
        const MAX_FIREWORKS_HARD = 50;
        
        // NEW: Reject wenn zu viele Fireworks (user-configurable limit)
        if (this.fireworks.length >= this.MAX_FIREWORKS) {
            if (DEBUG) console.warn(`[Fireworks] MAX_FIREWORKS limit reached (${this.fireworks.length}/${this.MAX_FIREWORKS}), skipping`);
            return;
        }

        // BUG FIX #3: Use cached particle count (updated max once per frame = 16ms)
        const now = performance.now();
        if (now - this.lastParticleCountUpdate > CONFIG.IDEAL_FRAME_TIME) {
            this.cachedParticleCount = this.getTotalParticles();
            this.lastParticleCountUpdate = now;
        }

        const currentParticles = this.cachedParticleCount;

        // NEW: Reject wenn zu viele Partikel (80% threshold)
        if (currentParticles > this.MAX_PARTICLES * 0.8) {
            if (DEBUG) console.warn(`[Fireworks] Particle limit approaching (${currentParticles}/${this.MAX_PARTICLES}), skipping`);
            return;
        }

        // NEW: Reduziere Intensity bei Überlast (60% threshold)
        let adjustedIntensity = intensity;
        if (currentParticles > this.MAX_PARTICLES * 0.6) {
            adjustedIntensity = intensity * 0.5;
            if (DEBUG) console.log(`[Fireworks] High load (${currentParticles} particles), reducing intensity by 50%: ${intensity.toFixed(2)} -> ${adjustedIntensity.toFixed(2)}`);
        }
        
        // Tier priority (higher = more important)
        const tierPriority = {
            'small': 1,
            'medium': 2,
            'big': 3,
            'massive': 4
        };
        
        const currentPriority = tierPriority[tier] || 2;
        
        // If queue is getting full, apply priority-based dropping
        if (this.fireworks.length >= MAX_FIREWORKS_NORMAL) {
            // Hard limit - never exceed
            if (this.fireworks.length >= MAX_FIREWORKS_HARD) {
                if (DEBUG) console.log(`[Fireworks] Hard limit reached (${this.fireworks.length}), dropping ${tier} firework`);
                return;
            }
            
            // Soft limit - drop low priority fireworks probabilistically
            if (currentPriority <= 2) {  // small or medium
                const dropChance = (this.fireworks.length - MAX_FIREWORKS_NORMAL) / (MAX_FIREWORKS_HARD - MAX_FIREWORKS_NORMAL);
                if (Math.random() < dropChance) {
                    if (DEBUG) console.log(`[Fireworks] Queue congested, dropping ${tier} firework (${(dropChance * 100).toFixed(0)}% drop chance)`);
                    return;
                }
            }
        }

        // Combo throttling: prevent extreme lag from rapid combos
        const timeSinceLastTrigger = now - this.lastComboTriggerTime;
        const minInterval = CONFIG.comboThrottleMinInterval;
        
        // Skip if triggered too quickly (except for first trigger)
        if (this.lastComboTriggerTime > 0 && timeSinceLastTrigger < minInterval) {
            if (DEBUG) console.log('[Fireworks] Combo throttled (too fast)');
            return;
        }
        
        this.lastComboTriggerTime = now;
        
        // High combo optimization: skip rockets entirely for very high combos
        const skipRockets = combo >= CONFIG.comboSkipRocketsThreshold;
        const instantExplode = combo >= CONFIG.comboInstantExplodeThreshold;
        
        if (instantExplode) {
            if (DEBUG) console.log(`[Fireworks] Instant explosion mode (combo: ${combo})`);
        } else if (skipRockets) {
            if (DEBUG) console.log(`[Fireworks] Skipping rocket animation (combo: ${combo})`);
        }

        // Launch position at bottom, target at specified position
        const startX = position.x * this.width;
        const targetY = position.y * this.height;

        // Load images if provided
        let giftImg = null;
        let avatarImg = null;
        let giftTextureIndex = 0;
        if (giftImage) {
            giftImg = await this.loadImage(giftImage);
            // Upload gift image to texture atlas if WebGL is active
            if (giftImg && this.useWebGL && this.webglEngine) {
                const key = 'gift:' + giftImage;
                const slot = this.webglEngine.queueImageUpload(key, giftImg);
                if (slot >= 0) {
                    giftTextureIndex = slot;
                }
            }
        }
        if (userAvatar) {
            avatarImg = await this.loadImage(userAvatar);
            // Upload avatar image to texture atlas if WebGL is active
            if (avatarImg && this.useWebGL && this.webglEngine) {
                const key = 'avatar:' + userAvatar;
                const slot = this.webglEngine.queueImageUpload(key, avatarImg);
                if (slot >= 0) {
                    // Use avatar texture index if no gift image
                    if (!giftTextureIndex) {
                        giftTextureIndex = slot;
                    }
                }
            }
        }

        // Create firework
        const firework = new Firework({
            x: startX,
            y: skipRockets ? targetY : this.height, // Start at target if skipping rockets
            targetY: targetY,
            shape: shape,
            colors: colors,
            intensity: adjustedIntensity, // Use adjusted intensity for particle count reduction
            giftImage: giftImg,
            userAvatar: avatarImg,
            avatarParticleChance: avatarParticleChance,
            useImages: !!(giftImg || avatarImg),
            tier: tier,
            combo: combo,
            skipRocket: skipRockets, // Pass flag to Firework class
            instantExplode: instantExplode, // Explode immediately without any delay
            engineFps: this.fps, // Pass current FPS for performance-based decisions
            adaptiveParticleSizeScale: this.getAdaptiveParticleSizeScale(),
            giftTextureIndex: giftTextureIndex // Texture Atlas slot for gift/avatar
        });
        
        // Calculate expected rocket flight time for audio synchronization
        let expectedFlightTime = 1.5; // Default
        if (!skipRockets && !instantExplode && firework.rocket) {
            expectedFlightTime = firework.calculateRocketFlightTime(
                firework.y,
                firework.targetY,
                CONFIG.rocketSpeed,
                -CONFIG.rocketAcceleration
            );
            if (DEBUG) console.log(`[Fireworks] Calculated flight time: ${expectedFlightTime.toFixed(2)}s for targetY: ${targetY}`);
        }
        
        // Audio selection and playback with synchronization
        if (playSound && this.audioManager.enabled) {
            const audioConfig = this.audioManager.selectAudio(tier, combo, instantExplode, expectedFlightTime);
            
            if (DEBUG) console.log(`[Fireworks] Audio strategy: ${audioConfig.useCombinedAudio ? 'Combined' : 'Callback'}`);
            
            if (audioConfig.useCombinedAudio) {
                // COMBINED AUDIO PLAYBACK
                // Single file contains both launch and explosion (pre-synchronized)
                if (audioConfig.combinedSound && !skipRockets) {
                    if (DEBUG) console.log(`[Fireworks] Combined audio: ${audioConfig.combinedSound}`);
                    this.audioManager.play(audioConfig.combinedSound, this.audioManager.COMBINED_AUDIO_VOLUME);
                }
                
            } else {
                // CALLBACK AUDIO PLAYBACK
                // Launch plays immediately, explosion/crackling trigger via callback when visual explodes
                if (audioConfig.launchSound && !skipRockets) {
                    if (DEBUG) console.log(`[Fireworks] Launch: ${audioConfig.launchSound}`);
                    this.audioManager.play(audioConfig.launchSound, this.audioManager.LAUNCH_AUDIO_VOLUME);
                }
                
                // Set explosion sound callback to trigger when firework explodes
                const soundVolume = instantExplode 
                    ? this.audioManager.INSTANT_EXPLODE_VOLUME 
                    : this.audioManager.NORMAL_EXPLOSION_VOLUME;
                    
                if (audioConfig.explosionSound) {
                    if (DEBUG) console.log(`[Fireworks] Setting explosion callback: ${audioConfig.explosionSound}`);
                    firework.onExplodeSound = (intensity) => {
                        if (DEBUG) console.log(`[Fireworks] Explosion callback triggered: ${audioConfig.explosionSound}`);
                        this.audioManager.play(audioConfig.explosionSound, intensity * soundVolume);
                        
                        // Add crackling layer with explosion for perfect sync
                        // Use fade-out to match visual particle lifetime (typical: 0.8-1.4s)
                        if (audioConfig.cracklingSound) {
                            if (DEBUG) console.log(`[Fireworks] Crackling with explosion: ${audioConfig.cracklingSound}`);
                            // Duration based on tier: bigger fireworks = longer crackling
                            const cracklingDuration = tier === 'massive' ? 2.0 : 
                                                    tier === 'big' ? 1.5 : 
                                                    1.2;
                            const fadeOutDuration = 0.8; // Smooth fade-out
                            this.audioManager.playWithFadeOut(
                                audioConfig.cracklingSound, 
                                this.audioManager.CRACKLING_VOLUME,
                                cracklingDuration,
                                fadeOutDuration
                            );
                        }
                    };
                    
                    // Set secondary explosion sound callback for burst/spiral secondary effects
                    if (shape === 'burst' || shape === 'spiral') {
                        firework.onSecondaryExplosionSound = () => {
                            // Play crackling sound for secondary burst/spiral with fade-out
                            const cracklingSound = Math.random() < 0.5 ? 'crackling-medium' : 'crackling-long';
                            if (DEBUG) console.log(`[Fireworks] Secondary explosion crackling: ${cracklingSound}`);
                            // Secondary crackling is shorter and quieter
                            this.audioManager.playWithFadeOut(
                                cracklingSound, 
                                this.audioManager.CRACKLING_VOLUME * 0.4,
                                1.0, // Shorter duration for secondary
                                0.5  // Quick fade-out
                            );
                        };
                    }
                } else if (instantExplode) {
                    if (DEBUG) console.log('[Fireworks] Instant explode - no launch sound needed');
                }
            }
        }

        this.fireworks.push(firework);

        // Show gift popup (always show, even for instant explosions)
        if (username && coins > 0) {
            this.showGiftPopup(startX, this.height - 100, username, coins, combo, giftImage);
        }
    }

    handleFinale(data) {
        const {
            intensity = 3.0,
            duration = 5000,
            burstCount = 15,
            burstInterval = 300,
            shapes = ['burst', 'heart', 'star', 'ring', 'spiral', 'paws'],
            colors = this.config.defaultColors
        } = data;

        // Performance optimization: reduce particles and increase interval
        const optimizedBurstCount = Math.min(burstCount, 10); // Max 10 bursts
        const optimizedInterval = Math.max(burstInterval, 500); // At least 500ms between bursts
        const optimizedIntensity = Math.min(intensity, 2.0); // Cap intensity at 2.0

        let bursts = 0;
        const interval = setInterval(() => {
            if (bursts >= optimizedBurstCount) {
                clearInterval(interval);
                return;
            }

            const position = {
                x: 0.2 + Math.random() * 0.6,
                y: 0.2 + Math.random() * 0.4
            };

            const shape = shapes[Math.floor(Math.random() * shapes.length)];

            this.handleTrigger({
                position,
                shape,
                colors,
                intensity: optimizedIntensity * (0.8 + Math.random() * 0.4),
                particleCount: Math.round(50 * optimizedIntensity), // Reduced from 80
                playSound: true // FIXED: Every rocket should have audio
            });

            bursts++;
        }, optimizedInterval);
    }

    async loadImage(url) {
        if (this.imageCache.has(url)) {
            return this.imageCache.get(url);
        }

        // Validate URL to prevent XSS - check for dangerous protocols
        if (!url || typeof url !== 'string') return null;
        const lowerUrl = url.toLowerCase();
        const dangerousProtocols = ['javascript:', 'data:', 'vbscript:', 'file:', 'about:'];
        if (dangerousProtocols.some(protocol => lowerUrl.startsWith(protocol))) {
            console.warn('[Fireworks] Invalid image URL blocked:', url);
            return null;
        }

        return new Promise((resolve) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = async () => {
                // Use async image decoding for better performance
                try {
                    if (img.decode) {
                        await img.decode();
                    }
                } catch (error) {
                    if (DEBUG) console.warn('[Fireworks] Image decode failed, using fallback:', error);
                }
                this.imageCache.set(url, img);
                resolve(img);
            };
            img.onerror = () => resolve(null);
            img.src = url;
        });
    }
    
    /**
     * Preload multiple images for better performance
     * @param {Array<string>} urls - Array of image URLs to preload
     */
    async preloadImages(urls) {
        const promises = urls.map(url => this.loadImage(url));
        await Promise.all(promises);
        if (DEBUG) console.log(`[Fireworks] Preloaded ${urls.length} images`);
    }

    showGiftPopup(x, y, username, coins, combo, giftImage) {
        // Check if popups are disabled
        const popupPosition = this.config.giftPopupPosition;
        const popupEnabled = this.config.giftPopupEnabled !== false; // Default to true
        
        if (popupPosition === 'none' || !popupEnabled) return;
        
        // Calculate position based on configuration
        let finalX = x;
        let finalY = y;
        
        if (typeof popupPosition === 'string') {
            switch (popupPosition) {
                case 'top':
                    finalX = this.width / 2;
                    finalY = 100;
                    break;
                case 'middle':
                    finalX = this.width / 2;
                    finalY = this.height / 2;
                    break;
                case 'bottom':
                    finalX = x; // Keep horizontal position
                    finalY = this.height - 100;
                    break;
                default:
                    // Use provided coordinates
                    break;
            }
        } else if (typeof popupPosition === 'object' && popupPosition.x !== undefined) {
            // Custom coordinates (normalized 0-1 or pixels)
            finalX = popupPosition.x < 2 ? popupPosition.x * this.width : popupPosition.x;
            finalY = popupPosition.y < 2 ? popupPosition.y * this.height : popupPosition.y;
        }
        
        const popup = document.createElement('div');
        popup.className = 'gift-popup';
        popup.style.cssText = `
            position: absolute;
            left: ${finalX}px;
            top: ${finalY}px;
            transform: translateX(-50%);
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: popIn 0.3s ease-out, fadeOut 0.5s ease-in 2s forwards;
            pointer-events: none;
            z-index: 100;
            border: 2px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        `;
        
        if (giftImage) {
            const img = document.createElement('img');
            img.src = giftImage;
            img.style.cssText = 'width: 32px; height: 32px; object-fit: contain;';
            popup.appendChild(img);
        }
        
        const text = document.createElement('span');
        text.textContent = `${username}: ${coins} coins`;
        popup.appendChild(text);
        
        if (combo > 1) {
            const comboSpan = document.createElement('span');
            comboSpan.style.color = '#ffcc00';
            comboSpan.textContent = ` ${combo}x COMBO!`;
            popup.appendChild(comboSpan);
        }
        
        document.getElementById('fireworks-container').appendChild(popup);
        
        setTimeout(() => popup.remove(), 2500);
    }

    render() {
        if (!this.running) return;

        const now = performance.now();
        const frameTime = now - this.lastTime;
        
        // BUG FIX #4: EMERGENCY CLEANUP - More aggressive to prevent freeze loops
        const totalParticles = this.getTotalParticles();
        if (totalParticles > this.EMERGENCY_CLEANUP_THRESHOLD) {
            console.error(`[Fireworks] EMERGENCY: ${totalParticles} particles! Aggressive cleanup...`);
            
            // Remove 100% of exploded fireworks
            const explodedFW = this.fireworks.filter(fw => fw.exploded);
            for (const fw of explodedFW) {
                if (fw.particles && fw.particles.length > 0) {
                    this.particlePool.releaseAll(fw.particles);
                    fw.particles = [];
                }
            }
            
            // Remove 50% of oldest flying fireworks (by age)
            // Note: 'age' field increases over time, so higher age = older firework
            const flyingFW = this.fireworks.filter(fw => !fw.exploded);
            flyingFW.sort((a, b) => (b.age || 0) - (a.age || 0)); // Sort by age descending (oldest/highest age first)
            const toRemoveFlying = Math.ceil(flyingFW.length * 0.5);
            
            for (let i = 0; i < toRemoveFlying; i++) {
                const fw = flyingFW[i];
                if (fw.particles && fw.particles.length > 0) {
                    this.particlePool.releaseAll(fw.particles);
                    fw.particles = [];
                }
            }
            
            // Clean up fireworks array (remove empty fireworks)
            // Keep: Non-exploded fireworks (rockets still flying, even with empty particle arrays)
            // Remove: Exploded fireworks without particles (completed explosions)
            this.fireworks = this.fireworks.filter(fw => {
                const hasParticles = fw.particles && fw.particles.length > 0;
                const isValid = !fw.exploded || hasParticles;
                return isValid;
            });
            
            const newCount = this.getTotalParticles();
            console.log(`[Fireworks] Emergency cleanup: Removed ${explodedFW.length} exploded + ${toRemoveFlying} flying fireworks`);
            console.log(`[Fireworks] Particles: ${totalParticles} -> ${newCount} (${((1 - newCount/totalParticles) * 100).toFixed(1)}% reduction)`);
        }
        
        // Optimization #10: Frame-skip threshold (50ms = 20 FPS)
        const FRAME_SKIP_THRESHOLD = 50;
        
        // If frame took too long, skip rendering but still update physics
        if (frameTime > FRAME_SKIP_THRESHOLD && this.fireworks.length > 0) {
            this.skippedFrames = (this.skippedFrames || 0) + 1;
            
            if (DEBUG) console.log(`[Fireworks] Frame skipped (${frameTime.toFixed(1)}ms), total skipped: ${this.skippedFrames}`);
            
            // Only update physics, no rendering
            const deltaTime = Math.min(frameTime / CONFIG.IDEAL_FRAME_TIME, 3);
            for (let i = this.fireworks.length - 1; i >= 0; i--) {
                this.fireworks[i].update(deltaTime);
                if (this.fireworks[i].isDone()) {
                    this.fireworks.splice(i, 1);
                }
            }
            
            this.lastTime = now;
            
            // Emergency cleanup if too many frames skipped consecutively
            if (this.skippedFrames > 10) {
                if (DEBUG) console.log('[Fireworks] Emergency cleanup triggered');
                // Force minimal mode
                this.performanceMode = 'minimal';
                this.applyPerformanceMode();
                this.skippedFrames = 0;
            }
            
            requestAnimationFrame(() => this.render());
            return;
        }
        
        // Reset skipped frames counter on successful render
        this.skippedFrames = 0;
        
        // FPS Throttling: Calculate target frame time based on targetFps
        const targetFps = this.config.targetFps || CONFIG.targetFps;
        const targetFrameTime = 1000 / targetFps; // ms per frame
        const timeSinceLastRender = now - this.lastRenderTime;
        
        // Skip this frame if we're rendering too fast (with tolerance for timing jitter)
        if (timeSinceLastRender < targetFrameTime - CONFIG.FPS_TIMING_TOLERANCE) {
            requestAnimationFrame(() => this.render());
            return;
        }
        
        // Calculate deltaTime for frame-independent physics (capped at 3x normal for extreme lag)
        const deltaTime = Math.min((now - this.lastTime) / CONFIG.IDEAL_FRAME_TIME, 3);
        
        // BUG FIX #1: Berechne frameDuration VOR dem Update von lastTime
        const frameDuration = now - this.lastTime;

        // NEW: Adaptive Frame Skip bei Low FPS
        if (this.frameSkipEnabled && this.adaptivePerformance) {
            const currentFPS = frameDuration > 0 ? 1000 / frameDuration : 60;
            this.adaptiveFpsHistory.push(currentFPS);
            if (this.adaptiveFpsHistory.length > 30) this.adaptiveFpsHistory.shift();
            
            // Berechne Average FPS (only if we have enough samples)
            if (this.adaptiveFpsHistory.length >= 10) {
                const avgFPS = this.adaptiveFpsHistory.reduce((a, b) => a + b, 0) / this.adaptiveFpsHistory.length;
                
                // Wenn FPS < minTargetFps, aktiviere Frame Skip
                if (avgFPS < this.minTargetFps) {
                    this.frameSkip++;
                    
                    // Jeder zweite Frame wird übersprungen
                    if (this.frameSkip % 2 === 0) {
                        if (DEBUG) console.log(`[Fireworks] Frame skip active (avgFPS: ${avgFPS.toFixed(1)} < ${this.minTargetFps})`);
                        requestAnimationFrame(() => this.render());
                        return;
                    }
                } else {
                    this.frameSkip = 0;
                }
            }
        }

        // DANN erst lastTime updaten
        this.lastTime = now;
        this.lastRenderTime = now;

        // Update all fireworks with deltaTime for frame-independent physics
        for (let i = this.fireworks.length - 1; i >= 0; i--) {
            this.fireworks[i].update(deltaTime);
            
            if (this.fireworks[i].isDone()) {
                this.fireworks[i] = this.fireworks[this.fireworks.length - 1];
                this.fireworks.pop();
            }
        }

        // Render using WebGL or Canvas 2D
        if (this.useWebGL && this.webglEngine) {
            this.renderWebGL();
        } else {
            this.renderCanvas();
        }

        // Update FPS and adaptive performance
        this.frameCount++;
        if (now - this.fpsUpdateTime >= 1000) {
            this.fps = this.frameCount;
            this.frameCount = 0;
            this.fpsUpdateTime = now;
            
            // Track FPS history for adaptive performance
            this.fpsHistory.push(this.fps);
            if (this.fpsHistory.length > 5) {
                this.fpsHistory.shift();
            }
            
            // Freeze detection failsafe
            if (this.freezeDetectionEnabled) {
                if (this.fps === 0) {
                    this.frozenFrameCount++;
                    
                    // Show warning after first frozen frame
                    if (this.frozenFrameCount === 1 && !this.freezeWarningShown) {
                        console.warn('[Fireworks] ⚠️ FPS dropped to 0, monitoring for freeze...');
                        this.freezeWarningShown = true;
                    }
                    
                    // Soft reset after sustained freeze (avoids black frame / OBS source reload)
                    if (this.frozenFrameCount >= this.maxFrozenFrames) {
                        console.error(`[Fireworks] 🔄 FPS frozen for ${this.maxFrozenFrames}s, performing soft reset`);
                        this.showFreezeWarning();
                        this.softReset();
                        // DON'T return — let the render loop continue
                    }
                } else {
                    // FPS recovered, reset freeze counter
                    if (this.frozenFrameCount > 0) {
                        console.log(`[Fireworks] ✅ FPS recovered (was frozen for ${this.frozenFrameCount}s)`);
                    }
                    this.frozenFrameCount = 0;
                    this.freezeWarningShown = false;
                }
            }
            
            // Calculate average FPS over last 5 seconds
            const avgFps = this.fpsHistory.reduce((a, b) => a + b, 0) / this.fpsHistory.length;
            
            // Adaptive Trail-Length based on FPS (Enhanced)
            this.updateAdaptiveRenderScale(avgFps);
            this.updateAdaptiveQuality(avgFps);
            this.adjustSecondaryEffectsForLoad();
            
            // Adaptive performance mode
            // Bug #2 Fix: Removed duplicate targetFps declaration - already declared earlier in this method
            const minFps = this.config.minFps || CONFIG.minFps;
            
            if (avgFps < minFps) {
                // Performance is suffering - enter minimal mode
                if (this.performanceMode !== 'minimal') {
                    this.performanceMode = 'minimal';
                    this.applyPerformanceMode();
                    if (DEBUG) console.log('[Fireworks] Adaptive Performance: MINIMAL mode (FPS:', avgFps.toFixed(1), ')');
                }
            } else if (avgFps < targetFps * 0.8) {
                // Performance is degraded - enter reduced mode
                if (this.performanceMode !== 'reduced') {
                    this.performanceMode = 'reduced';
                    this.applyPerformanceMode();
                    if (DEBUG) console.log('[Fireworks] Adaptive Performance: REDUCED mode (FPS:', avgFps.toFixed(1), ')');
                }
            } else if (avgFps >= targetFps * 0.95) {
                // Performance is good - return to normal mode
                if (this.performanceMode !== 'normal') {
                    this.performanceMode = 'normal';
                    this.applyPerformanceMode();
                    if (DEBUG) console.log('[Fireworks] Adaptive Performance: NORMAL mode (FPS:', avgFps.toFixed(1), ')');
                }
            }
            
            // Optimization #19: Update debug panel to show queue size
            if (this.debugMode) {
                const fpsEl = document.getElementById('fps');
                const particleEl = document.getElementById('particle-count');
                const rendererEl = document.getElementById('renderer-type');
                const modeEl = document.getElementById('performance-mode');
                if (fpsEl) fpsEl.textContent = this.fps;
                if (particleEl) particleEl.textContent = this.getTotalParticles();
                if (rendererEl) rendererEl.textContent = `${this.rendererMode.toUpperCase()} | ${this.performanceMode} | Q:${this.fireworks.length}`;
                if (modeEl) modeEl.textContent = this.performanceMode.toUpperCase();
            }

            // Emit FPS to server for benchmark tracking
            if (this.socket && this.socket.connected) {
                this.socket.emit('fireworks:fps-update', { fps: this.fps, timestamp: now });
            }
        }

        requestAnimationFrame(() => this.render());
    }
    
    /**
     * Render using WebGL instanced rendering with texture atlas.
     * All particle types (circle, heart, paw, image) are rendered in a single
     * instanced draw call via the texture atlas. No Canvas 2D overlay needed.
     */
    renderWebGL() {
        // Update particle data in WebGL engine
        this.webglEngine.updateParticles(this.fireworks);
        
        // Render all particles in a single draw call
        this.webglEngine.render();
    }

    updateAdaptiveRenderScale(avgFps) {
        if (this.isBenchmarkMode) return;
        if (this.fireworks.length > 0) return;

        if (this.config.adaptiveRenderScaleEnabled === false) {
            if (this.renderScale !== 1.0) {
                this.renderScale = 1.0;
                this.applyRenderScale();
            }
            return;
        }

        const now = performance.now();
        if (now - this.lastRenderScaleChange < 1500) return;

        const desiredFps = this.config.targetFps || CONFIG.targetFps;
        const minScale = this.config.minRenderScale || CONFIG.minRenderScale;
        const step = CONFIG.renderScaleStep;
        let nextScale = this.renderScale;

        if (avgFps < desiredFps * 0.75 && this.renderScale > minScale) {
            nextScale = Math.max(minScale, this.renderScale - step);
        } else if (avgFps > desiredFps - CONFIG.renderScaleRecoveryFpsMargin && this.renderScale < 1.0) {
            nextScale = Math.min(1.0, this.renderScale + step);
        }

        nextScale = Math.round(nextScale * 100) / 100;
        if (nextScale !== this.renderScale) {
            this.renderScale = nextScale;
            this.lastRenderScaleChange = now;
            this.applyRenderScale();
        }
    }

    updateAdaptiveQuality(avgFps) {
        const desiredFps = this.config.targetFps || CONFIG.targetFps;

        if (avgFps >= desiredFps * 0.9) {
            this.qualityScale = 1.0;
        } else if (avgFps >= desiredFps * 0.75) {
            this.qualityScale = 0.85;
        } else if (avgFps >= this.minTargetFps) {
            this.qualityScale = 0.75;
        } else {
            this.qualityScale = 0.65;
        }
    }

    getAdaptiveParticleSizeScale() {
        return this.qualityScale;
    }

    adjustSecondaryEffectsForLoad() {
        CONFIG.secondaryExplosionChance = CONFIG.baseSecondaryExplosionChance * this.qualityScale;
        CONFIG.trailLength = Math.max(3, Math.round(CONFIG.baseTrailLength * this.qualityScale));
    }
    
    /**
     * Render a non-circle particle using Canvas 2D
     */
    renderNonCircleParticle(p) {
        const ctx = this.ctx;
        
        if (p.type === 'image' && p.image) {
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            const size = p.size * 3;
            ctx.drawImage(p.image, -size/2, -size/2, size, size);
            ctx.restore();
        } else if (p.type === 'heart') {
            const rgb = hslToRgb(p.hue, p.saturation, p.brightness);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${p.alpha})`;
            ctx.font = `${p.size * 4}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('❤', 0, 0);
            ctx.restore();
        } else if (p.type === 'paw') {
            const rgb = hslToRgb(p.hue, p.saturation, p.brightness);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${p.alpha})`;
            ctx.font = `${p.size * 4}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🐾', 0, 0);
            ctx.restore();
        }
    }
    
    /**
     * Render using Canvas 2D (fallback)
     */
    renderCanvas() {
        // Clear with configurable background for trail effect
        const bgColor = this.config.backgroundColor || CONFIG.backgroundColor;
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.ctx.fillStyle = bgColor;
        this.ctx.fillRect(0, 0, this.width, this.height);
        
        // Optimization #6: Layer splitting - Update trails less frequently
        this.trailFrameCounter++;
        const shouldUpdateTrails = this.trailFrameCounter >= this.trailUpdateInterval;
        
        if (shouldUpdateTrails && this.trailCanvas && this.config.trailsEnabled) {
            this.trailFrameCounter = 0;
            // Clear and redraw trails on separate canvas
            this.trailCtx.clearRect(0, 0, this.width, this.height);
            for (const fw of this.fireworks) {
                this.renderTrailsToLayer(fw);
            }
        }
        
        // Optimization #6: Composite trail layer first (background)
        if (this.trailCanvas && this.config.trailsEnabled) {
            this.ctx.drawImage(this.trailCanvas, 0, 0);
        }

        // Render all fireworks
        for (const firework of this.fireworks) {
            // Optimization #6: Render particles only (trails are on separate layer)
            if (this.useLayerSplitting && this.config.trailsEnabled) {
                this.renderFireworkParticlesOnly(firework);
            } else {
                this.renderFirework(firework);
            }
        }
    }
    
    applyPerformanceMode() {
        // Adjust CONFIG based on performance mode
        switch (this.performanceMode) {
            case 'minimal':
                // Extreme reduction for very low FPS
                CONFIG.maxParticlesPerExplosion = 50;
                CONFIG.baseTrailLength = 5;
                CONFIG.sparkleChance = 0.05;
                CONFIG.baseSecondaryExplosionChance = 0.03;
                this.config.glowEnabled = true;
                this.config.trailsEnabled = true;
                
                // Bug #3 Fix: Fixed despawn logic - iterate in reverse and check properly
                const maxFireworksMinimal = 5;
                if (this.fireworks.length > maxFireworksMinimal) {
                    for (let i = this.fireworks.length - 1; i >= maxFireworksMinimal; i--) {
                        const fw = this.fireworks[i];
                        
                        // Start despawn for rocket (if exists)
                        if (!fw.exploded && fw.rocket && !fw.rocket.isDespawning) {
                            fw.rocket.startDespawn();
                        }
                        
                        // Start despawn for all particles
                        for (const p of fw.particles) {
                            if (!p.isDespawning) p.startDespawn();
                        }
                        for (const p of fw.secondaryExplosions) {
                            if (!p.isDespawning) p.startDespawn();
                        }
                        
                        // Check if ready for removal
                        const minDespawnTime = (CONFIG.despawnFadeDuration * 1000) / 2;
                        const now = performance.now();
                        
                        // For fireworks with rocket
                        if (fw.rocket && fw.rocket.isDespawning) {
                            if (now - fw.rocket.despawnStartTime > minDespawnTime) {
                                this.fireworks[i] = this.fireworks[this.fireworks.length - 1];
                                this.fireworks.pop();
                            }
                        }
                        // Bug #3 Fix: For instant-explode fireworks (no rocket)
                        else if (!fw.rocket && fw.exploded) {
                            // Check if all particles are despawning long enough
                            const allParticlesDespawning = fw.particles.every(p => 
                                p.isDespawning && (now - p.despawnStartTime > minDespawnTime)
                            );
                            if (allParticlesDespawning || fw.particles.length === 0) {
                                this.fireworks[i] = this.fireworks[this.fireworks.length - 1];
                                this.fireworks.pop();
                            }
                        }
                    }
                }
                break;
                
            case 'reduced':
                // Moderate reduction for low FPS
                CONFIG.maxParticlesPerExplosion = 100;
                CONFIG.baseTrailLength = 10;
                CONFIG.sparkleChance = 0.08;
                CONFIG.baseSecondaryExplosionChance = 0.05;
                this.config.glowEnabled = true;
                this.config.trailsEnabled = true;
                
                // Bug #3 Fix: Fixed despawn logic for reduced mode
                const maxFireworksReduced = 15;
                if (this.fireworks.length > maxFireworksReduced) {
                    for (let i = this.fireworks.length - 1; i >= maxFireworksReduced; i--) {
                        const fw = this.fireworks[i];
                        
                        if (!fw.exploded && fw.rocket && !fw.rocket.isDespawning) {
                            fw.rocket.startDespawn();
                        }
                        
                        for (const p of fw.particles) {
                            if (!p.isDespawning) p.startDespawn();
                        }
                        for (const p of fw.secondaryExplosions) {
                            if (!p.isDespawning) p.startDespawn();
                        }
                        
                        const minDespawnTime = (CONFIG.despawnFadeDuration * 1000) / 2;
                        const now = performance.now();
                        
                        if (fw.rocket && fw.rocket.isDespawning) {
                            if (now - fw.rocket.despawnStartTime > minDespawnTime) {
                                this.fireworks[i] = this.fireworks[this.fireworks.length - 1];
                                this.fireworks.pop();
                            }
                        } else if (!fw.rocket && fw.exploded) {
                            const allParticlesDespawning = fw.particles.every(p => 
                                p.isDespawning && (now - p.despawnStartTime > minDespawnTime)
                            );
                            if (allParticlesDespawning || fw.particles.length === 0) {
                                this.fireworks[i] = this.fireworks[this.fireworks.length - 1];
                                this.fireworks.pop();
                            }
                        }
                    }
                }
                break;
                
            case 'normal':
                // Full quality
                CONFIG.maxParticlesPerExplosion = 200;
                CONFIG.baseTrailLength = 20;
                CONFIG.sparkleChance = 0.15;
                CONFIG.baseSecondaryExplosionChance = 0.1;
                this.config.glowEnabled = true;
                this.config.trailsEnabled = true;
                break;
        }
        this.adjustSecondaryEffectsForLoad();
    }
    
    showFreezeWarning() {
        // Create a visual warning overlay
        const warning = document.createElement('div');
        warning.id = 'freeze-warning';
        warning.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 0, 0, 0.9);
            color: white;
            padding: 30px 50px;
            border-radius: 15px;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            z-index: 10000;
            border: 3px solid white;
            box-shadow: 0 0 30px rgba(255, 0, 0, 0.8);
        `;
        warning.innerHTML = `
            <div>⚠️ OVERLAY FROZEN ⚠️</div>
            <div style="font-size: 18px; margin-top: 10px;">Performing soft reset...</div>
        `;
        document.body.appendChild(warning);
        // Remove warning after 3 seconds
        setTimeout(() => warning.remove(), 3000);
    }

    /**
     * Soft reset — clear all fireworks and restore render state without reloading the page.
     * Replaces window.location.reload() to avoid black frames and socket reconnects in OBS.
     * After this method returns the render loop resumes normally on the next animation frame.
     * @returns {void}
     */
    softReset() {
        console.warn('[Fireworks] Soft reset — clearing all fireworks');
        
        // Release all particles back to pool
        for (const fw of this.fireworks) {
            if (fw.particles && fw.particles.length > 0) {
                this.particlePool.releaseAll(fw.particles);
                fw.particles = [];
            }
            if (fw.secondaryExplosions && fw.secondaryExplosions.length > 0) {
                this.particlePool.releaseAll(fw.secondaryExplosions);
                fw.secondaryExplosions = [];
            }
        }
        this.fireworks.length = 0;
        
        // Clear canvases
        this.ctx.clearRect(0, 0, this.width, this.height);
        if (this.trailCtx) {
            this.trailCtx.clearRect(0, 0, this.width, this.height);
        }
        
        // Reset performance state
        this.performanceMode = 'normal';
        this.applyPerformanceMode();
        this.skippedFrames = 0;
        this.cachedParticleCount = 0;
        this.frozenFrameCount = 0;
        this.freezeWarningShown = false;
        this.fpsHistory = [];
        this.adaptiveFpsHistory = [];
        this.frameSkip = 0;
        
        // Reset timers
        this.lastTime = performance.now();
        this.lastRenderTime = performance.now();
        this.fpsUpdateTime = performance.now();
        
        console.log('[Fireworks] ✅ Soft reset complete, render loop continues');
    }

    renderFirework(firework) {
        const ctx = this.ctx;
        
        // Collect particles by type for batch rendering
        const circles = [];
        const images = [];
        const hearts = [];
        const paws = [];
        
        // Add rocket if not exploded
        if (!firework.exploded && firework.rocket) {
            const p = firework.rocket;
            if (this.isParticleVisible(p)) {
                if (p.type === 'image' && p.image) {
                    images.push(p);
                } else {
                    circles.push(p);
                }
            }
        }
        
        // Collect explosion particles
        for (const p of firework.particles) {
            if (!this.isParticleVisible(p)) continue;
            
            if (p.type === 'image' && p.image) {
                images.push(p);
            } else if (p.type === 'heart') {
                hearts.push(p);
            } else if (p.type === 'paw') {
                paws.push(p);
            } else {
                circles.push(p);
            }
        }
        
        // Collect secondary explosions
        for (const p of firework.secondaryExplosions) {
            if (!this.isParticleVisible(p)) continue;
            circles.push(p); // Secondary explosions are always circles
        }
        
        // Batch render circles (most common type)
        if (circles.length > 0) {
            this.batchRenderCircles(circles);
        }
        
        // Batch render images
        if (images.length > 0) {
            this.batchRenderImages(images);
        }
        
        // Batch render hearts
        if (hearts.length > 0) {
            this.batchRenderHearts(hearts);
        }
        
        // Batch render paws
        if (paws.length > 0) {
            this.batchRenderPaws(paws);
        }
    }
    
    // Optimization #6: Render trails to separate layer
    renderTrailsToLayer(firework) {
        const ctx = this.trailCtx;
        
        const allParticles = [];
        if (!firework.exploded && firework.rocket) {
            allParticles.push(firework.rocket);
        }
        allParticles.push(...firework.particles);
        allParticles.push(...firework.secondaryExplosions);
        
        for (const p of allParticles) {
            if (p.trail.length > 1 && p.alpha > CONFIG.ALPHA_CULL_THRESHOLD) {
                const trailPath = new Path2D();
                trailPath.moveTo(p.trail[0].x, p.trail[0].y);
                
                for (let i = 1; i < p.trail.length; i++) {
                    trailPath.lineTo(p.trail[i].x, p.trail[i].y);
                }
                
                const rgb = hslToRgb(p.hue, p.saturation, p.brightness);
                ctx.strokeStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${p.alpha * 0.3})`;
                ctx.lineWidth = p.size * 0.5;
                ctx.lineCap = 'round';
                ctx.stroke(trailPath);
            }
        }
    }
    
    // Optimization #6: Render only particles (no trails) - trails are on separate layer
    renderFireworkParticlesOnly(firework) {
        // Render only particles (no trails) - trails are on separate layer
        const circles = [];
        const images = [];
        const hearts = [];
        const paws = [];
        
        if (!firework.exploded && firework.rocket) {
            const p = firework.rocket;
            if (this.isParticleVisible(p)) {
                if (p.type === 'image' && p.image) {
                    images.push(p);
                } else {
                    circles.push(p);
                }
            }
        }
        
        for (const p of firework.particles) {
            if (!this.isParticleVisible(p)) continue;
            
            if (p.type === 'image' && p.image) {
                images.push(p);
            } else if (p.type === 'heart') {
                hearts.push(p);
            } else if (p.type === 'paw') {
                paws.push(p);
            } else {
                circles.push(p);
            }
        }
        
        for (const p of firework.secondaryExplosions) {
            if (!this.isParticleVisible(p)) continue;
            circles.push(p);
        }
        
        // Batch render (without trails - they're on the trail layer)
        if (circles.length > 0) {
            this.batchRenderCirclesNoTrails(circles);
        }
        if (images.length > 0) {
            this.batchRenderImages(images);
        }
        if (hearts.length > 0) {
            this.batchRenderHearts(hearts);
        }
        if (paws.length > 0) {
            this.batchRenderPaws(paws);
        }
    }
    
    // Optimization #6: Batch render circles without trails
    batchRenderCirclesNoTrails(particles) {
        const ctx = this.ctx;
        
        // Render glows using 'lighter' composite — one save/restore for the whole batch
        if (this.config.glowEnabled) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            for (const p of particles) {
                if (p.alpha < CONFIG.ALPHA_CULL_THRESHOLD) continue;
                ctx.globalAlpha = p.alpha * 0.4;
                ctx.fillStyle = p._cachedColor || (p._cachedColor = this._makeHSL(p));
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size * 2, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
        }
        
        // Render core particles — one save/restore for the whole batch
        ctx.save();
        for (const p of particles) {
            if (p.alpha < CONFIG.ALPHA_CULL_THRESHOLD) continue;
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p._cachedColor || (p._cachedColor = this._makeHSL(p));
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
    
    isParticleVisible(p) {
        // Alpha culling - skip nearly invisible particles
        if (p.alpha < CONFIG.ALPHA_CULL_THRESHOLD) return false;
        
        // Viewport Culling - skip particles outside viewport with margin
        const margin = 100;
        return !(p.x < -margin || p.x > this.width + margin || p.y < -margin || p.y > this.height + margin);
    }

    /**
     * Build a cached HSL color string for a particle.
     * Avoids repeated hslToRgb() conversions per frame — the result is stored
     * on `p._cachedColor` and reused until the particle is reset.
     * @param {Particle} p - Particle with hue, saturation, brightness properties
     * @returns {string} CSS hsl() color string, e.g. "hsl(120,100%,50%)"
     */
    _makeHSL(p) {
        return `hsl(${Math.round(p.hue)},${Math.round(p.saturation)}%,${Math.round(p.brightness)}%)`;
    }
    
    batchRenderCircles(particles) {
        const ctx = this.ctx;
        
        // Render all trails in one batch with Path2D
        if (this.config.trailsEnabled) {
            ctx.save();
            ctx.lineCap = 'round';
            for (const p of particles) {
                if (p.trail.length > 1) {
                    const trailPath = new Path2D();
                    trailPath.moveTo(p.trail[0].x, p.trail[0].y);
                    
                    for (let i = 1; i < p.trail.length; i++) {
                        trailPath.lineTo(p.trail[i].x, p.trail[i].y);
                    }
                    
                    ctx.strokeStyle = `${p._cachedColor || (p._cachedColor = this._makeHSL(p))}`;
                    ctx.globalAlpha = p.alpha * 0.3;
                    ctx.lineWidth = p.size * 0.5;
                    ctx.stroke(trailPath);
                }
            }
            ctx.restore();
        }
        
        // Render all glows in one batch using 'lighter' composite
        if (this.config.glowEnabled) {
            ctx.save();
            ctx.globalCompositeOperation = 'lighter';
            for (const p of particles) {
                if (p.alpha < CONFIG.ALPHA_CULL_THRESHOLD) continue;
                ctx.globalAlpha = p.alpha * 0.4;
                ctx.fillStyle = p._cachedColor || (p._cachedColor = this._makeHSL(p));
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size * 2, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.restore();
        }
        
        // Render all core particles in one batch
        ctx.save();
        for (const p of particles) {
            if (p.alpha < CONFIG.ALPHA_CULL_THRESHOLD) continue;
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = p._cachedColor || (p._cachedColor = this._makeHSL(p));
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.restore();
    }
    
    batchRenderImages(particles) {
        const ctx = this.ctx;
        
        for (const p of particles) {
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            const size = p.size * 3;
            ctx.drawImage(p.image, -size/2, -size/2, size, size);
            ctx.restore();
        }
    }
    
    batchRenderHearts(particles) {
        const ctx = this.ctx;
        
        for (const p of particles) {
            const rgb = hslToRgb(p.hue, p.saturation, p.brightness);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${p.alpha})`;
            ctx.font = `${p.size * 4}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('❤', 0, 0);
            ctx.restore();
        }
    }
    
    batchRenderPaws(particles) {
        const ctx = this.ctx;
        
        for (const p of particles) {
            const rgb = hslToRgb(p.hue, p.saturation, p.brightness);
            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rotation);
            ctx.globalAlpha = p.alpha;
            ctx.fillStyle = `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${p.alpha})`;
            ctx.font = `${p.size * 4}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('🐾', 0, 0);
            ctx.restore();
        }
    }

    getTotalParticles() {
        let count = 0;
        for (const fw of this.fireworks) {
            count += fw.particles.length + fw.secondaryExplosions.length;
            if (!fw.exploded) count++;
        }
        return count;
    }

    toggleDebug() {
        this.debugMode = !this.debugMode;
        const panel = document.getElementById('debug-panel');
        if (panel) {
            panel.classList.toggle('visible', this.debugMode);
        }
    }

    destroy() {
        this.running = false;
        if (this.socket) {
            this.socket.disconnect();
        }
    }
}

// ============================================================================
// INITIALIZATION
// ============================================================================

let engine = null;

document.addEventListener('DOMContentLoaded', async () => {
    const canvas = document.getElementById('fireworks-canvas');
    if (!canvas) {
        console.error('[Fireworks] Canvas element not found');
        return;
    }
    
    engine = new FireworksEngine('fireworks-canvas');
    await engine.init();

    // Preload sounds - fireworks plugin audio files with synchronized timing
    
    // Basic launch sounds (short)
    await engine.audioManager.preload('/plugins/fireworks/audio/abschussgeraeusch.mp3', 'launch-basic');
    await engine.audioManager.preload('/plugins/fireworks/audio/abschussgeraeusch2.mp3', 'launch-basic2');
    
    // Basic explosion and rocket sounds
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion.mp3', 'explosion-basic');
    await engine.audioManager.preload('/plugins/fireworks/audio/rocket.mp3', 'rocket-basic');
    
    // NEW: Additional explosion sounds with varying intensities
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion_small1.mp3', 'explosion-small');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion_medium.mp3', 'explosion-medium');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion2.mp3', 'explosion-alt1');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion3.mp3', 'explosion-alt2');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion_big.mp3', 'explosion-big');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion_huge.mp3', 'explosion-huge');
    await engine.audioManager.preload('/plugins/fireworks/audio/explosion%20Pop%2CSharp%2C.mp3', 'explosion-pop'); // URL encoded filename
    
    // NEW: Crackling sounds for atmospheric effects
    await engine.audioManager.preload('/plugins/fireworks/audio/crackling.mp3', 'crackling-long');
    await engine.audioManager.preload('/plugins/fireworks/audio/crackling2.mp3', 'crackling-medium');
    
    // Combined sounds - synchronized launch + explosion in one file
    // These play the entire sequence from launch to explosion
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_crackling_bang.mp3', 'combined-crackling-bang');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_normal-bang.mp3', 'combined-whistle-normal');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_tiny-bang.mp3', 'combined-whistle-tiny1');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_tiny-bang2.mp3', 'combined-whistle-tiny2');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_tiny-bang3.mp3', 'combined-whistle-tiny3');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_tiny-bang4.mp3', 'combined-whistle-tiny4');
    
    // Launch-only sounds (no explosion) - for when we want to play explosion separately
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_mit-pfeifen_no-bang.mp3', 'launch-whistle');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_nocrackling_no-bang.mp3', 'launch-smooth');
    await engine.audioManager.preload('/plugins/fireworks/audio/woosh_abheben_nocrackling_no-bang2.mp3', 'launch-smooth2');
    
    // Enable audio context on first user interaction
    const enableAudio = async () => {
        await engine.audioManager.ensureAudioContext();
        document.removeEventListener('click', enableAudio);
        document.removeEventListener('keydown', enableAudio);
    };
    document.addEventListener('click', enableAudio);
    document.addEventListener('keydown', enableAudio);

    // Debug mode toggle
    document.addEventListener('keydown', (e) => {
        if (e.key.toLowerCase() === 'd') {
            engine.toggleDebug();
        }
    });

    if (DEBUG) console.log('[Fireworks] Advanced engine ready');
});

// Only expose engine after initialization
if (typeof window !== 'undefined') {
    Object.defineProperty(window, 'FireworksEngine', {
        get: () => engine,
        configurable: false,
        enumerable: true
    });
}
