# Stream Monsters 1.3 – Collector Arena

Stream Monsters keeps the stable `streamalchemy` plugin ID so existing installations, routes and data remain compatible. The public product name is exclusively **Stream Monsters**. Existing crafting data stays untouched; Collector Arena uses additive `streammonsters_*` tables.

## Creator flow

1. Open `/streammonsters/ui`.
2. In **Geschenke-Mapping**, search the complete shared TikTok catalog and explicitly enable each spawn or boost gift.
3. In **Art Lab**, select a detected graphics adapter. The guided wizard shows the recommended pinned profile, official Beta or experimental status, disk and download sizes, the model license, and links to official NVIDIA, Intel and AMD driver downloads.
4. Install, cancel or resume the managed runtime. Then verify the backend with the 256×256 smoke test. The UI reports the actual profile, backend, device, driver, VRAM and whether that exact device passed—not a generic hardware claim.
5. Prepare one to eight AI skins per active element/variant before going live. Three is the default. Generation is serial and a live gift never starts an image job. Zero coverage remains visible, and every failure includes a concrete recovery action.
6. Add `/streammonsters/overlay` as an OBS browser source and run the full safe demo.

Only enabled mappings affect the game. A spawn gift creates an element egg. A boost gift shortens the oldest active egg by 15, 30, 60 or 120 seconds according to the catalog diamond band. Gift value never changes combat strength or random odds.

## Eggs, monsters and progression

- The six elements are Ember, Tide, Grove, Gale, Volt and Lunar.
- Standard incubation takes five minutes. Charged eggs are cosmetic and hatch faster, but never receive better stats.
- Finished eggs become `ready`, free their incubator slot and hatch only through `!hatch [slot]`.
- Hype gains 10 per spawn and a 20-point bonus for two different selected gifts within six seconds. At 100, the next egg becomes deterministically charged and hype returns to zero.
- Every monster gets a deterministic name, personality and exactly 28 base stat points.
- AI art is consumed from the pre-stream pool by `element:variant`. With no prepared skin, the bundled CC0 Kenney Monster Builder renders a deterministic local SVG immediately.
- A later preparation may cosmetically evolve one Kenney monster to AI art without changing its owner, identity or stats.
- Collections and levels are permanent. A 28-day league resets only season points and rank.
- XP and season points come from hatches, the first ten daily battles, wins and quests. Cosmetic ranks, titles, badges and frames never add combat power.

## Viewer commands

- `!eggs`
- `!hatch [slot]`
- `!monsters`
- `!monster [slot]`
- `!choose <slot>`
- `!battle`
- `!leavebattle`
- `!rank`
- `!quests`
- `!monstershelp`

`!battle` joins a public queue. Matchmaking starts within ±2 levels and widens after 30 seconds. Two viewers resolve a reproducible three-round duel with a stored seed, stored round results and visible element advantage. There are no stakes, cash prizes, transferable rewards, paid random outcomes, teams, battle passes or world bosses.

## Public API

- `GET /api/streammonsters/state?userId=`
- `GET /api/streammonsters/gift-catalog?q=&locale=&offset=&limit=`
- `GET /api/streammonsters/gift-mappings`
- `PUT /api/streammonsters/gift-mappings/:giftId`
- `DELETE /api/streammonsters/gift-mappings/:giftId`
- `POST /api/streammonsters/config`
- `GET /api/streammonsters/pool`
- `POST /api/streammonsters/pool/prepare`
- `GET /api/streammonsters/season`
- `GET /api/streammonsters/leaderboard?limit=`
- `POST /api/streammonsters/demo`
- `GET /api/streammonsters/local-runtime/status`
- `POST /api/streammonsters/local-runtime/install`

The responsive overlay supports 16:9 and 9:16. It restores `/api/streammonsters/state` before replaying socket activity after a reconnect. Battle and hatch events are critical, Hype/chat updates coalesce, stale noncritical events are discarded, and bounded overflow removes noncritical work first. Cards cover starter monsters, stance reveals, Hype milestones, Elemental Hour, streaks, upsets, rivalries and ranks as well as the existing egg and battle flow.

The creator page exposes mute and volume controls for five short local Web Audio cues: spawn, ready, hatch, hit and win. No third-party sound files are bundled because this repository snapshot contains no verified Kenney CC0 audio source or matching audio license. The existing Kenney Monster Builder license covers graphics only, so the release does not invent audio provenance.

## Bundled assets and license

The plugin bundles twelve transparent 1024×1024 element eggs, the Stream Monsters icon and wide logo, and Kenney Monster Builder Pack 1.0. Kenney graphics are CC0; the upstream license is included at `assets/kenney-monster-builder/License.txt`.
