/**
 * Advanced Timer Database Module
 * Handles all database operations for timer configurations, states, and logs
 * 
 * Stores data in user profile folder for persistence across updates
 */

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

// Per-interaction field mapping (event_type → column name) — used in migration and event-bridge
const ALLOWED_PER_FIELDS = {
    gift: 'per_coin',
    follow: 'per_follow',
    share: 'per_share',
    subscribe: 'per_subscribe',
    like: 'per_like',
    chat: 'per_chat'
};
const ALLOWED_PER_FIELD_VALUES = Object.values(ALLOWED_PER_FIELDS);

class TimerDatabase {
    constructor(api) {
        this.api = api;
        this.db = null;
    }

    /**
     * Initialize plugin database in user profile folder
     * Opens the database connection and sets up WAL mode.
     * Does NOT create tables or migrate data - call initialize() for that.
     */
    initDatabase() {
        try {
            // Get config path manager
            const configPathManager = this.api.getConfigPathManager();
            if (!configPathManager) {
                throw new Error('ConfigPathManager not available');
            }
            
            // Get plugin data directory from config path manager
            const pluginDataDir = configPathManager.getPluginDataDir('advanced-timer');
            
            // Ensure directory exists
            if (!fs.existsSync(pluginDataDir)) {
                fs.mkdirSync(pluginDataDir, { recursive: true });
                this.api.log(`Created plugin data directory: ${pluginDataDir}`, 'info');
            }
            
            // Database path in user profile folder
            const dbPath = path.join(pluginDataDir, 'timers.db');
            this.api.log(`Using database at: ${dbPath}`, 'info');
            
            // Check if old database exists in plugin directory (migration needed after tables are created)
            // _pendingMigrationPath is read by initialize() once the schema is ready.
            const oldDbPath = path.join(this.api.getPluginDir(), 'data', 'timers.db');
            this._pendingMigrationPath = (fs.existsSync(oldDbPath) && !fs.existsSync(dbPath)) ? oldDbPath : null;
            
            // Open database
            this.db = new Database(dbPath);
            this.db.pragma('journal_mode = WAL');
            
        } catch (error) {
            this.api.log(`Error initializing plugin database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Migrate old database in plugin directory
     */
    migrateOldDatabase(oldDbPath) {
        try {
            this.api.log('Migrating timer data from old location...', 'info');
            
            const oldDb = new Database(oldDbPath, { readonly: true });
            
            // Copy all tables
            const tables = ['advanced_timers', 'advanced_timer_events', 'advanced_timer_rules', 
                          'advanced_timer_chains', 'advanced_timer_logs', 'advanced_timer_profiles'];
            
            for (const table of tables) {
                try {
                    const rows = oldDb.prepare(`SELECT * FROM ${table}`).all();
                    if (rows.length > 0) {
                        // Tables will be created by initialize() first
                        const columns = Object.keys(rows[0]);
                        const placeholders = columns.map(() => '?').join(',');
                        const insert = this.db.prepare(`INSERT OR REPLACE INTO ${table} (${columns.join(',')}) VALUES (${placeholders})`);
                        
                        const insertMany = this.db.transaction((data) => {
                            for (const row of data) {
                                insert.run(Object.values(row));
                            }
                        });
                        
                        insertMany(rows);
                        this.api.log(`Migrated ${rows.length} rows from ${table}`, 'info');
                    }
                } catch (tableError) {
                    // Table might not exist in old database, that's okay
                    this.api.log(`Skipping migration of ${table}: ${tableError.message}`, 'debug');
                }
            }
            
            oldDb.close();
            this.api.log('Migration completed successfully', 'info');
            
        } catch (error) {
            this.api.log(`Migration error (non-fatal): ${error.message}`, 'warn');
        }
    }

    /**
     * Migrate from INTEGER to REAL for fractional second support
     * SQLite is flexible with types, so this is mainly for documentation
     */
    migrateToFractionalSupport() {
        try {
            // Check if table exists
            const tableExists = this.db.prepare(`
                SELECT name FROM sqlite_master WHERE type='table' AND name='advanced_timers'
            `).get();

            if (tableExists) {
                // SQLite will automatically handle INTEGER as REAL when needed
                // No actual migration needed, just log for awareness
                this.api.log('Database supports fractional seconds (REAL type)', 'debug');
            }
        } catch (error) {
            this.api.log(`Fractional support check: ${error.message}`, 'debug');
        }
    }

    /**
     * Initialize database tables
     */
    initialize() {
        if (this.db?.open) {
            this.api.log('Advanced Timer database already initialized', 'debug');
            return;
        }

        // First open the database connection
        this.initDatabase();
        
        try {
            // Check if we need to migrate from INTEGER to REAL for fractional support
            this.migrateToFractionalSupport();

            // Timers table - stores timer configurations
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timers (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    initial_duration REAL DEFAULT 0,
                    current_value REAL DEFAULT 0,
                    target_value REAL DEFAULT 0,
                    state TEXT DEFAULT 'stopped',
                    created_at INTEGER DEFAULT (strftime('%s', 'now')),
                    updated_at INTEGER DEFAULT (strftime('%s', 'now')),
                    config TEXT DEFAULT '{}'
                )
            `).run();

            // Timer events table - stores event triggers for timers
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timer_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    action_type TEXT NOT NULL,
                    action_value REAL DEFAULT 0,
                    conditions TEXT DEFAULT '{}',
                    enabled INTEGER DEFAULT 1,
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Timer rules table - stores IF/THEN automation rules
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_rules (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timer_id TEXT NOT NULL,
                    rule_type TEXT NOT NULL,
                    conditions TEXT NOT NULL,
                    actions TEXT NOT NULL,
                    enabled INTEGER DEFAULT 1,
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Timer chains table - defines timer trigger chains
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_chains (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_timer_id TEXT NOT NULL,
                    target_timer_id TEXT NOT NULL,
                    trigger_condition TEXT NOT NULL,
                    action TEXT NOT NULL,
                    enabled INTEGER DEFAULT 1,
                    FOREIGN KEY (source_timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE,
                    FOREIGN KEY (target_timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Timer logs table - tracks who added/removed time and events
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timer_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    user_name TEXT,
                    value_change REAL DEFAULT 0,
                    description TEXT,
                    timestamp INTEGER DEFAULT (strftime('%s', 'now')),
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Timer profiles table - stores timer configurations for import/export
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_profiles (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    config TEXT NOT NULL,
                    created_at INTEGER DEFAULT (strftime('%s', 'now'))
                )
            `).run();

            this.api.log('Advanced Timer database tables initialized', 'info');

            // Add new flat per-interaction columns (idempotent)
            this.upgradeSchema();

            // Migrate old data if needed (must happen after tables are created)
            if (this._pendingMigrationPath) {
                this.migrateOldDatabase(this._pendingMigrationPath);
                this._pendingMigrationPath = null;
            }

            // Migrate simple timer_events entries into per_* columns
            this.migrateSimpleEventsToPerFields();

            // Gift overrides table — per-timer per-gift custom seconds
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_gift_overrides (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timer_id TEXT NOT NULL,
                    gift_id INTEGER NOT NULL,
                    gift_name TEXT NOT NULL,
                    seconds REAL NOT NULL DEFAULT 0,
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE,
                    UNIQUE(timer_id, gift_id)
                )
            `).run();

            // Rotator settings — per-timer config for the time-delta rotator
            // One row per timer. JSON columns keep the schema forward-compatible.
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_rotator_settings (
                    timer_id TEXT PRIMARY KEY,
                    enabled INTEGER DEFAULT 0,
                    slot_count INTEGER DEFAULT 1,
                    position TEXT DEFAULT 'top',          -- top | bottom | left | right
                    rotation_interval_ms INTEGER DEFAULT 4500,
                    show_gift_images INTEGER DEFAULT 1,
                    show_gift_names INTEGER DEFAULT 1,
                    show_time_delta INTEGER DEFAULT 1,
                    show_source_emoji INTEGER DEFAULT 1,
                    min_seconds_to_show REAL DEFAULT 0,    -- 0 = show every delta, >0 = threshold floor
                    include_sources TEXT DEFAULT 'like,coin,follow,subscribe,gift,override,manual,flow,rule',
                    slide_in_ms INTEGER DEFAULT 400,
                    slide_out_ms INTEGER DEFAULT 600,
                    fade_alpha REAL DEFAULT 0.92,
                    font_scale REAL DEFAULT 1.0,
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Threshold effects — frame/animation played when |delta| >= threshold
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_threshold_effects (
                    timer_id TEXT PRIMARY KEY,
                    enabled INTEGER DEFAULT 0,
                    threshold_seconds REAL DEFAULT 60,
                    direction TEXT DEFAULT 'both',         -- both | positive | negative
                    duration_ms INTEGER DEFAULT 1500,
                    builtin_animation TEXT DEFAULT 'flame', -- flame|lightning|sparks|pulse-glow|rainbow-shake|gold-flux
                    -- Per-slot custom frames: array of {slot,url,name} JSON, up to 6 slots
                    custom_frames TEXT DEFAULT '[]',
                    intensity REAL DEFAULT 1.0,            -- 0.5..2.0 scale modifier
                    sound TEXT DEFAULT '',                 -- optional sound trigger name
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();

            // Custom frame slots — separate table for fast CRUD on individual uploads
            // (keeps the JSON column read-on-load fast)
            this.db.prepare(`
                CREATE TABLE IF NOT EXISTS advanced_timer_threshold_frames (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timer_id TEXT NOT NULL,
                    slot INTEGER NOT NULL,                 -- 1..6
                    url TEXT NOT NULL,
                    filename TEXT,
                    label TEXT DEFAULT '',
                    uploaded_at INTEGER DEFAULT (strftime('%s','now')),
                    UNIQUE(timer_id, slot),
                    FOREIGN KEY (timer_id) REFERENCES advanced_timers(id) ON DELETE CASCADE
                )
            `).run();
        } catch (error) {
            this.api.log(`Error initializing timer database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Add new columns to advanced_timers (idempotent — SQLite throws if column exists, we catch that)
     */
    upgradeSchema() {
        const newColumns = [
            'per_coin REAL DEFAULT 0',
            'per_follow REAL DEFAULT 0',
            'per_share REAL DEFAULT 0',
            'per_subscribe REAL DEFAULT 0',
            'per_like REAL DEFAULT 0',
            'per_chat REAL DEFAULT 0',
            'multiplier REAL DEFAULT 1.0',
            'multiplier_enabled INTEGER DEFAULT 0',
            'expiry_action TEXT DEFAULT \'none\'',
            'expiry_action_config TEXT DEFAULT \'{}\'',
            'shortcut_start_pause TEXT DEFAULT \'\'',
            'shortcut_increase TEXT DEFAULT \'\'',
            'shortcut_decrease TEXT DEFAULT \'\'',
            'shortcut_step REAL DEFAULT 60'
        ];

        for (const colDef of newColumns) {
            try {
                this.db.prepare(`ALTER TABLE advanced_timers ADD COLUMN ${colDef}`).run();
            } catch (err) {
                // Only suppress "duplicate column" — rethrow unexpected errors
                if (!err.message || !err.message.includes('duplicate column name')) {
                    this.api.log(`Unexpected ALTER TABLE error: ${err.message}`, 'warn');
                }
            }
        }

        this.api.log('Advanced Timer schema upgrade complete', 'debug');
    }

    /**
     * One-time migration: convert simple advanced_timer_events rows
     * (gift→add_time / remove_time without conditions) into per_* fields on the timer.
     * Leaves entries with gift-name/minCoins conditions or set_value actions untouched.
     */
    migrateSimpleEventsToPerFields() {
        try {
            const timers = this.db.prepare('SELECT id FROM advanced_timers').all();

        // Fetch all events in a single query and group by timer_id
        const allEvents = this.db.prepare('SELECT * FROM advanced_timer_events').all();
        const eventsByTimer = new Map();
        for (const ev of allEvents) {
            if (!eventsByTimer.has(ev.timer_id)) eventsByTimer.set(ev.timer_id, []);
            eventsByTimer.get(ev.timer_id).push(ev);
        }

        for (const { id } of timers) {
            const events = eventsByTimer.get(id) || [];

            const updates = {};

            for (const ev of events) {
                if (!ev.enabled) continue;
                if (ev.action_type !== 'add_time' && ev.action_type !== 'remove_time') continue;

                const conditions = JSON.parse(ev.conditions || '{}');
                const hasAdvancedConditions =
                    conditions.giftName || conditions.minCoins || conditions.minLikes ||
                    conditions.command || conditions.keyword;
                if (hasAdvancedConditions) continue;

                const sign = ev.action_type === 'add_time' ? 1 : -1;
                const seconds = sign * (parseFloat(ev.action_value) || 0);

                const field = ALLOWED_PER_FIELDS[ev.event_type];
                if (!field) continue;

                // Only migrate if the per_* field is still at default (0)
                const current = this.db.prepare(`SELECT ${field} FROM advanced_timers WHERE id = ?`).get(id);
                if (current && current[field] === 0) {
                    updates[field] = seconds;
                }
            }

            if (Object.keys(updates).length > 0) {
                const safeKeys = Object.keys(updates).filter(k => ALLOWED_PER_FIELD_VALUES.includes(k));
                if (safeKeys.length > 0) {
                    const setClauses = safeKeys.map(k => `${k} = ?`).join(', ');
                    this.db.prepare(`UPDATE advanced_timers SET ${setClauses} WHERE id = ?`)
                        .run(...safeKeys.map(k => updates[k]), id);
                    this.api.log(`Migrated ${safeKeys.length} event(s) to per_* fields for timer ${id}`, 'info');
                }
            }
        }
        } catch (error) {
            this.api.log(`migrateSimpleEventsToPerFields (non-fatal): ${error.message}`, 'warn');
        }
    }

    /**
     * Get all timers
     */
    getAllTimers() {
        try {
            const timers = this.db.prepare('SELECT * FROM advanced_timers ORDER BY created_at DESC').all();
            return timers.map(timer => this._parseTimer(timer));
        } catch (error) {
            this.api.log(`Error getting all timers: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Get timer by ID
     */
    getTimer(id) {
        try {
            const timer = this.db.prepare('SELECT * FROM advanced_timers WHERE id = ?').get(id);
            if (!timer) return null;
            return this._parseTimer(timer);
        } catch (error) {
            this.api.log(`Error getting timer ${id}: ${error.message}`, 'error');
            return null;
        }
    }

    /**
     * Parse raw DB row into a timer object
     */
    _parseTimer(row) {
        return {
            ...row,
            config: JSON.parse(row.config || '{}'),
            expiry_action_config: JSON.parse(row.expiry_action_config || '{}'),
            per_coin: row.per_coin || 0,
            per_follow: row.per_follow || 0,
            per_share: row.per_share || 0,
            per_subscribe: row.per_subscribe || 0,
            per_like: row.per_like || 0,
            per_chat: row.per_chat || 0,
            multiplier: row.multiplier || 1.0,
            multiplier_enabled: row.multiplier_enabled ? 1 : 0,
            expiry_action: row.expiry_action || 'none',
            shortcut_start_pause: row.shortcut_start_pause || '',
            shortcut_increase: row.shortcut_increase || '',
            shortcut_decrease: row.shortcut_decrease || '',
            shortcut_step: row.shortcut_step || 60
        };
    }

    /**
     * Create or update timer
     */
    saveTimer(timer) {
        try {
            const {
                id, name, mode, initial_duration, current_value, target_value, state, config,
                per_coin, per_follow, per_share, per_subscribe, per_like, per_chat,
                multiplier, multiplier_enabled,
                expiry_action, expiry_action_config,
                shortcut_start_pause, shortcut_increase, shortcut_decrease, shortcut_step
            } = timer;
            
            this.db.prepare(`
                INSERT OR REPLACE INTO advanced_timers 
                (id, name, mode, initial_duration, current_value, target_value, state, config, updated_at,
                 per_coin, per_follow, per_share, per_subscribe, per_like, per_chat,
                 multiplier, multiplier_enabled,
                 expiry_action, expiry_action_config,
                 shortcut_start_pause, shortcut_increase, shortcut_decrease, shortcut_step)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, strftime('%s', 'now'),
                        ?, ?, ?, ?, ?, ?,
                        ?, ?,
                        ?, ?,
                        ?, ?, ?, ?)
            `).run(
                id,
                name,
                mode,
                initial_duration || 0,
                current_value || 0,
                target_value || 0,
                state || 'stopped',
                JSON.stringify(config || {}),
                per_coin || 0,
                per_follow || 0,
                per_share || 0,
                per_subscribe || 0,
                per_like || 0,
                per_chat || 0,
                multiplier !== undefined ? multiplier : 1.0,
                multiplier_enabled ? 1 : 0,
                expiry_action || 'none',
                JSON.stringify(expiry_action_config || {}),
                shortcut_start_pause || '',
                shortcut_increase || '',
                shortcut_decrease || '',
                shortcut_step !== undefined ? shortcut_step : 60
            );

            return true;
        } catch (error) {
            this.api.log(`Error saving timer: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete timer
     */
    deleteTimer(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timers WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting timer ${id}: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Update timer state
     */
    updateTimerState(id, state, currentValue) {
        try {
            this.db.prepare(`
                UPDATE advanced_timers 
                SET state = ?, current_value = ?, updated_at = strftime('%s', 'now')
                WHERE id = ?
            `).run(state, currentValue, id);
            return true;
        } catch (error) {
            this.api.log(`Error updating timer state: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get timer events
     */
    getTimerEvents(timerId) {
        try {
            const events = this.db.prepare('SELECT * FROM advanced_timer_events WHERE timer_id = ?').all(timerId);
            return events.map(event => ({
                ...event,
                conditions: JSON.parse(event.conditions || '{}')
            }));
        } catch (error) {
            this.api.log(`Error getting timer events: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Save timer event
     */
    saveTimerEvent(event) {
        try {
            const { id, timer_id, event_type, action_type, action_value, conditions, enabled } = event;
            
            if (id) {
                this.db.prepare(`
                    UPDATE advanced_timer_events
                    SET event_type = ?, action_type = ?, action_value = ?, conditions = ?, enabled = ?
                    WHERE id = ?
                `).run(event_type, action_type, action_value, JSON.stringify(conditions || {}), enabled ? 1 : 0, id);
            } else {
                this.db.prepare(`
                    INSERT INTO advanced_timer_events 
                    (timer_id, event_type, action_type, action_value, conditions, enabled)
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run(timer_id, event_type, action_type, action_value, JSON.stringify(conditions || {}), enabled ? 1 : 0);
            }
            return true;
        } catch (error) {
            this.api.log(`Error saving timer event: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete timer event
     */
    deleteTimerEvent(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_events WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting timer event: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get timer rules
     */
    getTimerRules(timerId) {
        try {
            const rules = this.db.prepare('SELECT * FROM advanced_timer_rules WHERE timer_id = ?').all(timerId);
            return rules.map(rule => ({
                ...rule,
                conditions: JSON.parse(rule.conditions || '{}'),
                actions: JSON.parse(rule.actions || '[]')
            }));
        } catch (error) {
            this.api.log(`Error getting timer rules: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Get all rules
     */
    getAllRules() {
        try {
            const rules = this.db.prepare('SELECT * FROM advanced_timer_rules').all();
            return rules.map(rule => ({
                ...rule,
                conditions: JSON.parse(rule.conditions || '{}'),
                actions: JSON.parse(rule.actions || '[]')
            }));
        } catch (error) {
            this.api.log(`Error getting all rules: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Save timer rule
     */
    saveTimerRule(rule) {
        try {
            const { id, timer_id, rule_type, conditions, actions, enabled } = rule;
            
            if (id) {
                this.db.prepare(`
                    UPDATE advanced_timer_rules
                    SET rule_type = ?, conditions = ?, actions = ?, enabled = ?
                    WHERE id = ?
                `).run(rule_type, JSON.stringify(conditions), JSON.stringify(actions), enabled ? 1 : 0, id);
            } else {
                this.db.prepare(`
                    INSERT INTO advanced_timer_rules 
                    (timer_id, rule_type, conditions, actions, enabled)
                    VALUES (?, ?, ?, ?, ?)
                `).run(timer_id, rule_type, JSON.stringify(conditions), JSON.stringify(actions), enabled ? 1 : 0);
            }
            return true;
        } catch (error) {
            this.api.log(`Error saving timer rule: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete timer rule
     */
    deleteTimerRule(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_rules WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting timer rule: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get timer chains
     */
    getTimerChains(timerId) {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_chains WHERE source_timer_id = ?').all(timerId);
        } catch (error) {
            this.api.log(`Error getting timer chains: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Get all chains
     */
    getAllChains() {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_chains').all();
        } catch (error) {
            this.api.log(`Error getting all chains: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Save timer chain
     */
    saveTimerChain(chain) {
        try {
            const { id, source_timer_id, target_timer_id, trigger_condition, action, enabled } = chain;
            
            if (id) {
                this.db.prepare(`
                    UPDATE advanced_timer_chains
                    SET source_timer_id = ?, target_timer_id = ?, trigger_condition = ?, action = ?, enabled = ?
                    WHERE id = ?
                `).run(source_timer_id, target_timer_id, trigger_condition, action, enabled !== undefined ? (enabled ? 1 : 0) : 1, id);
            } else {
                this.db.prepare(`
                    INSERT INTO advanced_timer_chains 
                    (source_timer_id, target_timer_id, trigger_condition, action, enabled)
                    VALUES (?, ?, ?, ?, ?)
                `).run(source_timer_id, target_timer_id, trigger_condition, action, enabled !== undefined ? (enabled ? 1 : 0) : 1);
            }
            return true;
        } catch (error) {
            this.api.log(`Error saving timer chain: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete timer chain
     */
    deleteTimerChain(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_chains WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting timer chain: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Add timer log entry
     */
    addTimerLog(timerId, eventType, userName, valueChange, description) {
        try {
            this.db.prepare(`
                INSERT INTO advanced_timer_logs 
                (timer_id, event_type, user_name, value_change, description)
                VALUES (?, ?, ?, ?, ?)
            `).run(timerId, eventType, userName || null, valueChange || 0, description || null);
            return true;
        } catch (error) {
            this.api.log(`Error adding timer log: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get timer logs
     */
    getTimerLogs(timerId, limit = 100) {
        try {
            return this.db.prepare(`
                SELECT * FROM advanced_timer_logs 
                WHERE timer_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            `).all(timerId, limit);
        } catch (error) {
            this.api.log(`Error getting timer logs: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Export timer logs to file
     */
    exportTimerLogs(timerId) {
        try {
            const logs = this.db.prepare(`
                SELECT * FROM advanced_timer_logs 
                WHERE timer_id = ? 
                ORDER BY timestamp DESC
            `).all(timerId);
            
            return logs;
        } catch (error) {
            this.api.log(`Error exporting timer logs: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Clear old logs
     */
    clearOldLogs(timerId, daysToKeep = 30) {
        try {
            const cutoffTimestamp = Math.floor(Date.now() / 1000) - (daysToKeep * 24 * 60 * 60);
            this.db.prepare(`
                DELETE FROM advanced_timer_logs 
                WHERE timer_id = ? AND timestamp < ?
            `).run(timerId, cutoffTimestamp);
            return true;
        } catch (error) {
            this.api.log(`Error clearing old logs: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Save timer profile
     */
    saveProfile(profile) {
        try {
            const { id, name, description, config } = profile;
            this.db.prepare(`
                INSERT OR REPLACE INTO advanced_timer_profiles 
                (id, name, description, config)
                VALUES (?, ?, ?, ?)
            `).run(id, name, description || '', JSON.stringify(config));
            return true;
        } catch (error) {
            this.api.log(`Error saving timer profile: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Get all profiles
     */
    getAllProfiles() {
        try {
            const profiles = this.db.prepare('SELECT * FROM advanced_timer_profiles ORDER BY created_at DESC').all();
            return profiles.map(profile => ({
                ...profile,
                config: JSON.parse(profile.config || '{}')
            }));
        } catch (error) {
            this.api.log(`Error getting profiles: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Get profile by ID
     */
    getProfile(id) {
        try {
            const profile = this.db.prepare('SELECT * FROM advanced_timer_profiles WHERE id = ?').get(id);
            if (!profile) return null;
            return {
                ...profile,
                config: JSON.parse(profile.config || '{}')
            };
        } catch (error) {
            this.api.log(`Error getting profile: ${error.message}`, 'error');
            return null;
        }
    }

    /**
     * Delete profile
     */
    deleteProfile(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_profiles WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting profile: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Cleanup - close database connection
     */
    destroy() {
        try {
            if (this.db) {
                this.db.close();
                this.db = null;
                this.api.log('Advanced Timer database closed', 'info');
            }
        } catch (error) {
            this.api.log(`Error closing database: ${error.message}`, 'error');
        }
    }

    // ========== GIFT OVERRIDES ==========

    /**
     * Get all gift overrides for a timer
     */
    getGiftOverrides(timerId) {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_gift_overrides WHERE timer_id = ? ORDER BY gift_name ASC').all(timerId);
        } catch (error) {
            this.api.log(`Error getting gift overrides: ${error.message}`, 'error');
            return [];
        }
    }

    /**
     * Get a single gift override by timer_id + gift_id
     */
    getGiftOverride(timerId, giftId) {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_gift_overrides WHERE timer_id = ? AND gift_id = ?').get(timerId, giftId);
        } catch (error) {
            this.api.log(`Error getting gift override: ${error.message}`, 'error');
            return null;
        }
    }

    /**
     * Save (insert or update) a gift override
     */
    saveGiftOverride(timerId, giftId, giftName, seconds) {
        try {
            this.db.prepare(`
                INSERT INTO advanced_timer_gift_overrides (timer_id, gift_id, gift_name, seconds)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(timer_id, gift_id) DO UPDATE SET
                    gift_name = excluded.gift_name,
                    seconds = excluded.seconds
            `).run(timerId, giftId, giftName, seconds);
            return true;
        } catch (error) {
            this.api.log(`Error saving gift override: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete a gift override
     */
    deleteGiftOverride(id) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_gift_overrides WHERE id = ?').run(id);
            return true;
        } catch (error) {
            this.api.log(`Error deleting gift override: ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Delete all gift overrides for a timer
     */
    clearGiftOverrides(timerId) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_gift_overrides WHERE timer_id = ?').run(timerId);
            return true;
        } catch (error) {
            this.api.log(`Error clearing gift overrides: ${error.message}`, 'error');
            return false;
        }
    }

    // ========== ROTATOR SETTINGS ==========

    _ROTATOR_DEFAULT_SOURCES = ['like','coin','follow','subscribe','gift','override','manual','flow','rule','superfan'];

    _normalizeRotator(raw) {
        if (!raw) return null;
        return {
            timer_id: raw.timer_id,
            enabled: raw.enabled ? 1 : 0,
            slot_count: Math.max(1, Math.min(8, parseInt(raw.slot_count) || 1)),
            position: ['top','bottom','left','right'].includes(raw.position) ? raw.position : 'top',
            rotation_interval_ms: Math.max(500, parseInt(raw.rotation_interval_ms) || 4500),
            show_gift_images: raw.show_gift_images ? 1 : 0,
            show_gift_names: raw.show_gift_names ? 1 : 0,
            show_time_delta: raw.show_time_delta ? 1 : 0,
            show_source_emoji: raw.show_source_emoji ? 1 : 0,
            min_seconds_to_show: Math.max(0, parseFloat(raw.min_seconds_to_show) || 0),
            include_sources: typeof raw.include_sources === 'string'
                ? raw.include_sources
                : (Array.isArray(raw.include_sources)
                    ? raw.include_sources.join(',')
                    : this._ROTATOR_DEFAULT_SOURCES.join(',')),
            slide_in_ms: Math.max(50, parseInt(raw.slide_in_ms) || 400),
            slide_out_ms: Math.max(50, parseInt(raw.slide_out_ms) || 600),
            fade_alpha: Math.max(0.3, Math.min(1.0, parseFloat(raw.fade_alpha) || 0.92)),
            font_scale: Math.max(0.5, Math.min(2.0, parseFloat(raw.font_scale) || 1.0))
        };
    }

    getRotator(timerId) {
        try {
            const row = this.db.prepare('SELECT * FROM advanced_timer_rotator_settings WHERE timer_id = ?').get(timerId);
            if (row) return this._normalizeRotator(row);
            // Return defaults
            return this._normalizeRotator({
                timer_id: timerId,
                include_sources: this._ROTATOR_DEFAULT_SOURCES.join(',')
            });
        } catch (error) {
            this.api.log(`Error reading rotator settings: ${error.message}`, 'error');
            return null;
        }
    }

    saveRotator(timerId, settings) {
        try {
            const existing = this.db.prepare('SELECT * FROM advanced_timer_rotator_settings WHERE timer_id = ?').get(timerId);
            const base = existing
                ? this._normalizeRotator(existing)
                : this._normalizeRotator({
                    timer_id: timerId,
                    include_sources: this._ROTATOR_DEFAULT_SOURCES.join(',')
                });
            const norm = this._normalizeRotator({ ...base, ...settings, timer_id: timerId });
            this.db.prepare(`
                INSERT INTO advanced_timer_rotator_settings
                (timer_id, enabled, slot_count, position, rotation_interval_ms,
                 show_gift_images, show_gift_names, show_time_delta, show_source_emoji,
                 min_seconds_to_show, include_sources, slide_in_ms, slide_out_ms, fade_alpha, font_scale)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(timer_id) DO UPDATE SET
                    enabled = excluded.enabled,
                    slot_count = excluded.slot_count,
                    position = excluded.position,
                    rotation_interval_ms = excluded.rotation_interval_ms,
                    show_gift_images = excluded.show_gift_images,
                    show_gift_names = excluded.show_gift_names,
                    show_time_delta = excluded.show_time_delta,
                    show_source_emoji = excluded.show_source_emoji,
                    min_seconds_to_show = excluded.min_seconds_to_show,
                    include_sources = excluded.include_sources,
                    slide_in_ms = excluded.slide_in_ms,
                    slide_out_ms = excluded.slide_out_ms,
                    fade_alpha = excluded.fade_alpha,
                    font_scale = excluded.font_scale
            `).run(
                timerId,
                norm.enabled, norm.slot_count, norm.position, norm.rotation_interval_ms,
                norm.show_gift_images, norm.show_gift_names, norm.show_time_delta, norm.show_source_emoji,
                norm.min_seconds_to_show, norm.include_sources,
                norm.slide_in_ms, norm.slide_out_ms, norm.fade_alpha, norm.font_scale
            );
            return this.getRotator(timerId);
        } catch (error) {
            this.api.log(`Error saving rotator settings: ${error.message}`, 'error');
            return null;
        }
    }

    // ========== THRESHOLD EFFECTS ==========

    _BUILTIN_ANIMATIONS = ['flame','lightning','sparks','pulse-glow','rainbow-shake','gold-flux'];

    _normalizeThreshold(raw) {
        if (!raw) return null;
        const builtin = this._BUILTIN_ANIMATIONS.includes(raw.builtin_animation)
            ? raw.builtin_animation : 'flame';
        const direction = ['both','positive','negative'].includes(raw.direction)
            ? raw.direction : 'both';
        let frames = [];
        if (typeof raw.custom_frames === 'string') {
            try { frames = JSON.parse(raw.custom_frames); } catch (_) { frames = []; }
        } else if (Array.isArray(raw.custom_frames)) {
            frames = raw.custom_frames;
        }
        return {
            timer_id: raw.timer_id,
            enabled: raw.enabled ? 1 : 0,
            threshold_seconds: Math.max(0.1, parseFloat(raw.threshold_seconds) || 60),
            direction,
            duration_ms: Math.max(100, Math.min(10000, parseInt(raw.duration_ms) || 1500)),
            builtin_animation: builtin,
            custom_frames: JSON.stringify(frames.slice(0, 6)),
            intensity: Math.max(0.5, Math.min(2.0, parseFloat(raw.intensity) || 1.0)),
            sound: typeof raw.sound === 'string' ? raw.sound.slice(0, 120) : ''
        };
    }

    getThreshold(timerId) {
        try {
            const row = this.db.prepare('SELECT * FROM advanced_timer_threshold_effects WHERE timer_id = ?').get(timerId);
            let settings;
            if (row) {
                settings = this._normalizeThreshold(row);
            } else {
                settings = this._normalizeThreshold({ timer_id: timerId });
            }
            // Attach uploaded frames from the per-slot table for freshness
            try {
                const frameRows = this.db.prepare(
                    'SELECT slot, url, filename, label FROM advanced_timer_threshold_frames WHERE timer_id = ? ORDER BY slot ASC'
                ).all(timerId);
                settings.uploaded_frames = frameRows;
            } catch (_) { settings.uploaded_frames = []; }
            // Parse custom_frames for client convenience
            try { settings.custom_frames_parsed = JSON.parse(settings.custom_frames || '[]'); }
            catch (_) { settings.custom_frames_parsed = []; }
            return settings;
        } catch (error) {
            this.api.log(`Error reading threshold effect settings: ${error.message}`, 'error');
            return null;
        }
    }

    saveThreshold(timerId, settings) {
        try {
            const norm = this._normalizeThreshold({ ...settings, timer_id: timerId });
            this.db.prepare(`
                INSERT INTO advanced_timer_threshold_effects
                (timer_id, enabled, threshold_seconds, direction, duration_ms,
                 builtin_animation, custom_frames, intensity, sound)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(timer_id) DO UPDATE SET
                    enabled = excluded.enabled,
                    threshold_seconds = excluded.threshold_seconds,
                    direction = excluded.direction,
                    duration_ms = excluded.duration_ms,
                    builtin_animation = excluded.builtin_animation,
                    custom_frames = excluded.custom_frames,
                    intensity = excluded.intensity,
                    sound = excluded.sound
            `).run(
                timerId, norm.enabled, norm.threshold_seconds, norm.direction,
                norm.duration_ms, norm.builtin_animation, norm.custom_frames,
                norm.intensity, norm.sound
            );
            return this.getThreshold(timerId);
        } catch (error) {
            this.api.log(`Error saving threshold effect settings: ${error.message}`, 'error');
            return null;
        }
    }

    saveThresholdFrame(timerId, slot, url, filename, label) {
        try {
            this.db.prepare(`
                INSERT INTO advanced_timer_threshold_frames (timer_id, slot, url, filename, label)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(timer_id, slot) DO UPDATE SET
                    url = excluded.url,
                    filename = excluded.filename,
                    label = excluded.label,
                    uploaded_at = strftime('%s','now')
            `).run(timerId, slot, url, filename || null, label || '');
            return true;
        } catch (error) {
            this.api.log(`Error saving threshold frame: ${error.message}`, 'error');
            return false;
        }
    }

    deleteThresholdFrame(timerId, slot) {
        try {
            this.db.prepare('DELETE FROM advanced_timer_threshold_frames WHERE timer_id = ? AND slot = ?').run(timerId, slot);
            return true;
        } catch (error) {
            this.api.log(`Error deleting threshold frame: ${error.message}`, 'error');
            return false;
        }
    }

    getThresholdFrame(timerId, slot) {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_threshold_frames WHERE timer_id = ? AND slot = ?').get(timerId, slot);
        } catch (error) {
            this.api.log(`Error getting threshold frame: ${error.message}`, 'error');
            return null;
        }
    }

    getThresholdFrames(timerId) {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_threshold_frames WHERE timer_id = ? ORDER BY slot ASC').all(timerId);
        } catch (error) {
            this.api.log(`Error getting threshold frames: ${error.message}`, 'error');
            return [];
        }
    }

    /** Bulk load all rotator + threshold settings — used at init() for the in-memory cache */
    loadAllRotatorSettings() {
        try {
            return this.db.prepare('SELECT * FROM advanced_timer_rotator_settings').all().map(r => this._normalizeRotator(r));
        } catch (error) {
            this.api.log(`Error loading rotator settings: ${error.message}`, 'error');
            return [];
        }
    }

    loadAllThresholdSettings() {
        try {
            const list = this.db.prepare('SELECT * FROM advanced_timer_threshold_effects').all().map(r => this._normalizeThreshold(r));
            // Attach frames
            const allFrames = this.db.prepare('SELECT * FROM advanced_timer_threshold_frames').all();
            const framesByTimer = new Map();
            for (const f of allFrames) {
                if (!framesByTimer.has(f.timer_id)) framesByTimer.set(f.timer_id, []);
                framesByTimer.get(f.timer_id).push(f);
            }
            return list.map(s => ({ ...s, uploaded_frames: framesByTimer.get(s.timer_id) || [] }));
        } catch (error) {
            this.api.log(`Error loading threshold settings: ${error.message}`, 'error');
            return [];
        }
    }
}

module.exports = TimerDatabase;
