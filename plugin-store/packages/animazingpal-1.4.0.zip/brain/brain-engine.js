/**
 * Brain Engine for AnimazingPal
 * 
 * The central intelligence system that connects:
 * - Memory Database (Nervous System) - stores all experiences
 * - Vector Memory (Synapses) - links related memories semantically
 * - GPT Brain (Cerebral Cortex) - processes and generates responses
 * - Animaze (Body/Voice) - expresses through avatar
 * 
 * This creates an AI streamer that:
 * - Remembers viewers and their interactions
 * - Maintains personality consistency
 * - Generates contextual, intelligent responses
 * - Archives and recalls long-term memories
 */

const MemoryDatabase = require('./memory-database');
const VectorMemory = require('./vector-memory');
const GPTBrainService = require('./gpt-brain-service');
const { normalizeLiveHostConfig } = require('./live-host-config');
const ViewerMemoryAdapter = require('./viewer-memory-adapter');

function isLoopbackHost(hostname) {
  return ['localhost', '127.0.0.1', '::1'].includes(String(hostname || '').toLowerCase());
}

function providerRequiresApiKey(provider, providerConfig = {}) {
  if (provider === 'openai' || provider === 'gemini' || provider === 'openrouter') return true;
  return false;
}

function normalizeLanguageCode(value, fallback = 'de') {
  const normalized = String(value || '').trim().toLowerCase().replace(/_/g, '-');
  if (!normalized) return fallback;
  if (normalized.startsWith('en')) return 'en';
  if (normalized.startsWith('de')) return 'de';
  return fallback;
}

class BrainEngine {
  constructor(api, options = {}) {
    this.api = api;
    this.logger = {
      info: (msg) => api.log(msg, 'info'),
      debug: (msg) => api.log(msg, 'debug'),
      warn: (msg) => api.log(msg, 'warn'),
      error: (msg) => api.log(msg, 'error')
    };
    
    // Get database from plugin API
    const db = api.getDatabase();
    
    // Initialize components
    this.memoryDb = new MemoryDatabase(db, this.logger);
    this.vectorMemory = new VectorMemory(this.logger);
    this.viewerMemory = new ViewerMemoryAdapter(api);
    this.gptBrain = null; // Initialized when API key is set
    
    // Current streamer ID (for per-streamer memory)
    this.streamerId = null;
    
    // Configuration
    this.config = {
      enabled: false,
      openaiApiKey: null,
      model: 'gpt-4o-mini',
      activePersonality: null,
      
      // Memory settings
      memoryImportanceThreshold: 0.3,
      maxContextMemories: 10,
      archiveAfterDays: 7,
      pruneAfterDays: 30,
      
      // Response settings - more human-like defaults
      autoRespond: {
        chat: true,
        gifts: true,
        follows: true,
        shares: true,
        likes: false,      // Only react to significant like counts
        subscribe: true
      },
      
      // Human-like decision making
      speakThreshold: 0.5,       // Importance threshold to decide if to speak
      emotionalMemory: true,    // Remember emotional context
      contextAwareness: true,   // Consider stream context
      
      // Rate limiting
      maxResponsesPerMinute: 18,
      chatResponseProbability: 0.45, // Only respond to 45% of chats when enabled
      
      ...options
    };
    
    // Runtime state
    this.currentSession = null;
    this.responseCount = 0;
    this.responseCountResetTime = Date.now();
    this.lastHostSpeechError = null;
    
    // Personality cache
    this.currentPersonality = null;
    
    // Event processing queue for human-like timing
    this.eventQueue = [];
    this.processingEvent = false;
    
    // Stream context - what's happening right now
    this.streamContext = {
      isLive: false,
      viewerCount: 0,
      recentEvents: [],
      mood: 'neutral',
      lastSpoke: 0,
      speakCooldown: 3000  // Minimum 3s between spoken responses
    };
  }

  /**
   * Set the streamer ID for per-streamer memory
   */
  setStreamerId(streamerId) {
    this.streamerId = streamerId;
    this.memoryDb.setStreamerId(streamerId);
    
    // Reload memories for this streamer
    this.vectorMemory.clear();
    const memories = this.memoryDb.getRecentMemories(500);
    this.vectorMemory.loadFromMemories(memories);
    
    this.logger.info(`Brain Engine: Switched to streamer "${streamerId}"`);
  }

  /**
   * Get the current streamer ID
   */
  getStreamerId() {
    return this.streamerId || this.memoryDb.getStreamerId();
  }

  /**
   * Initialize the brain engine
   */
  async initialize() {
    try {
      // Initialize database tables
      this.memoryDb.initialize();
      
      // Load existing memories into vector store
      const memories = this.memoryDb.getRecentMemories(500);
      this.vectorMemory.loadFromMemories(memories);
      
      // Load active personality
      await this.loadActivePersonality();
      
      // Generate session ID
      this.currentSession = `session_${Date.now()}`;
      
      this.logger.info('Brain Engine initialized successfully');
      return true;
    } catch (error) {
      this.logger.error(`Failed to initialize Brain Engine: ${error.message}`);
      return false;
    }
  }

  /**
   * Configure the brain engine
   */
  configure(newConfig) {
    this.config = { ...this.config, ...newConfig };

    const liveHostInput = newConfig.liveHost || (
      newConfig.provider || newConfig.providers || newConfig.response || newConfig.tts
        ? newConfig
        : this.config.liveHost || {}
    );
    const liveHost = normalizeLiveHostConfig(liveHostInput, newConfig);
    this.config.liveHost = liveHost;
    this.config.enabled = newConfig.enabled === true || liveHost.enabled === true;
    if (newConfig.autoRespond && typeof newConfig.autoRespond === 'object') {
      const autoRespond = { ...newConfig.autoRespond };
      if (Object.prototype.hasOwnProperty.call(autoRespond, 'like') && !Object.prototype.hasOwnProperty.call(autoRespond, 'likes')) {
        autoRespond.likes = autoRespond.like;
      }
      this.config.autoRespond = {
        ...this.config.autoRespond,
        ...autoRespond
      };
    }
    if (Number.isFinite(Number(newConfig.maxResponsesPerMinute))) {
      this.config.maxResponsesPerMinute = Number(newConfig.maxResponsesPerMinute);
    } else {
      this.config.maxResponsesPerMinute = liveHost.response.maxResponsesPerMinute;
    }
    if (Number.isFinite(Number(newConfig.chatResponseProbability))) {
      this.config.chatResponseProbability = Number(newConfig.chatResponseProbability);
    } else {
      this.config.chatResponseProbability = liveHost.response.chatProbability;
    }
    const providerConfig = {
      ...liveHost.providers[liveHost.provider],
      provider: liveHost.provider,
      contextMessages: liveHost.response.contextMessages,
      cacheTtlMs: liveHost.response.cacheTtlMs
    };

    if (providerConfig.apiKey || liveHost.provider === 'ollama') {
      this.gptBrain = new GPTBrainService(providerConfig, this.logger);
    } else {
      this.gptBrain = null;
    }

    if (this.streamContext) {
      this.streamContext.speakCooldown = liveHost.response.speakCooldownMs;
    }
    
    // Update active personality if changed
    if (newConfig.activePersonality) {
      this.setActivePersonality(newConfig.activePersonality);
    }
  }

  _resolveSystemPrompt(options = {}) {
    const language = normalizeLanguageCode(
      options.language || this.config?.liveHost?.response?.language,
      'de'
    );
    const languageInstruction = language === 'en'
      ? 'IMPORTANT: Write all responses in English.'
      : 'WICHTIG: Antworte auf Deutsch.';
    return [
      this.currentPersonality?.system_prompt,
      this.config.liveHost?.response?.systemPrompt,
      languageInstruction,
      options.systemPromptOverride
    ].filter(Boolean).join('\n\n');
  }

  getHostSpeechReadiness() {
    const liveHostEnabled = this.config.liveHost?.enabled === true;
    const enabled = this.config.enabled === true || liveHostEnabled;
    const provider = this.config.liveHost?.provider;
    const providerConfig = provider ? this.config.liveHost?.providers?.[provider] : null;
    const apiKeyRequired = providerRequiresApiKey(provider, providerConfig);
    const apiKeyConfigured = !!providerConfig?.apiKey;
    const providerConfigured = !!this.gptBrain && (!apiKeyRequired || apiKeyConfigured);
    const personalityConfigured = !!this.currentPersonality;
    let reason = null;
    if (!enabled) reason = 'host-brain-disabled';
    else if (!this.gptBrain) reason = 'host-brain-provider-unavailable';
    else if (apiKeyRequired && !apiKeyConfigured) reason = 'host-brain-api-key-missing';
    else if (!personalityConfigured) reason = 'host-brain-personality-missing';
    return {
      ready: enabled && providerConfigured && personalityConfigured,
      enabled,
      liveHostEnabled,
      provider,
      apiKeyRequired,
      apiKeyConfigured,
      providerConfigured,
      personalityConfigured,
      reason
    };
  }

  /**
   * Load the active personality
   */
  async loadActivePersonality() {
    const personality = this.memoryDb.getActivePersonality();
    if (personality) {
      this.currentPersonality = this._parsePersonality(personality);
      this.config.activePersonality = personality.name;
      this.logger.info(`Loaded personality: ${personality.display_name}`);
    }
    return this.currentPersonality;
  }

  /**
   * Set active personality by name
   */
  async setActivePersonality(name) {
    this.memoryDb.setActivePersonality(name);
    await this.loadActivePersonality();
  }

  /**
   * Get all available personalities
   */
  getPersonalities() {
    return this.memoryDb.getPersonalities().map(p => this._parsePersonality(p));
  }

  /**
   * Create a custom personality
   */
  createPersonality(data) {
    return this.memoryDb.createPersonality(data);
  }

  getPersonality(name) {
    const personality = this.memoryDb.getPersonality(name);
    return personality ? this._parsePersonality(personality) : undefined;
  }

  updatePersonality(name, updates) {
    this.memoryDb.updatePersonality(name, updates);
    if (this.currentPersonality?.name === name) {
      const personality = this.memoryDb.getPersonality(name);
      this.currentPersonality = personality ? this._parsePersonality(personality) : null;
    }
  }

  deletePersonality(name) {
    const deleted = this.memoryDb.deletePersonality(name);
    if (deleted && this.currentPersonality?.name === name) {
      this.currentPersonality = null;
    }
    return deleted;
  }

  _parseJsonField(value, fallback) {
    if (value && typeof value === 'object') {
      return value;
    }

    try {
      return JSON.parse(value || JSON.stringify(fallback));
    } catch (_) {
      return fallback;
    }
  }

  _parsePersonality(personality) {
    return {
      ...personality,
      emotion_tendencies: this._parseJsonField(personality.emotion_tendencies, {}),
      catchphrases: this._parseJsonField(personality.catchphrases, []),
      topics_of_interest: this._parseJsonField(personality.topics_of_interest, []),
      tone_settings: this._parseJsonField(personality.tone_settings, {
        temperature: 0.7,
        presencePenalty: 0.3,
        frequencyPenalty: 0.2
      }),
      emote_config: this._parseJsonField(personality.emote_config, {
        defaultEmote: 'neutral',
        highEnergyEmote: 'excited',
        lowEnergyEmote: 'calm'
      }),
      memory_behavior: this._parseJsonField(personality.memory_behavior, {
        importanceThreshold: 0.5,
        maxContextMemories: 10
      })
    };
  }

  /**
   * Check rate limiting
   */
  _checkRateLimit() {
    const now = Date.now();
    
    // Reset counter every minute
    if (now - this.responseCountResetTime > 60000) {
      this.responseCount = 0;
      this.responseCountResetTime = now;
    }
    
    if (this.responseCount >= this.config.maxResponsesPerMinute) {
      return false;
    }
    
    this.responseCount++;
    return true;
  }

  _releaseRateLimitSlot() {
    const now = Date.now();
    if (now - this.responseCountResetTime > 60000) return false;
    if (this.responseCount <= 0) return false;
    this.responseCount--;
    return true;
  }

  /**
   * Get relevant memories for context
   */
  _getContextMemories(query, username = null) {
    const memories = [];
    
    // Get semantically similar memories
    const similar = this.vectorMemory.findSimilar(query, 5, 0.2);
    for (const { memoryId } of similar) {
      const memory = this.memoryDb.getRecentMemories(100).find(m => m.id === memoryId);
      if (memory) {
        memories.push(memory.content);
      }
    }
    
    // Get user-specific memories if username provided
    if (username) {
      const userMemories = this.memoryDb.getUserMemories(username, 5);
      for (const memory of userMemories) {
        if (!memories.includes(memory.content)) {
          memories.push(memory.content);
        }
      }
    }
    
    // Get important memories using configured threshold
    const importanceThreshold = this.config.memoryImportanceThreshold || 0.3;
    const important = this.memoryDb.getImportantMemories(importanceThreshold, 3);
    for (const memory of important) {
      if (!memories.includes(memory.content)) {
        memories.push(memory.content);
      }
    }

    if (username && this.config.liveHost?.viewerMemory?.enabled) {
      const viewerContext = this.viewerMemory.getViewerContext(
        username,
        this.config.liveHost.viewerMemory,
        this.config.liveHost.privacy
      );
      for (const memory of viewerContext.memories || []) {
        if (memory.content && !memories.includes(memory.content)) memories.push(memory.content);
      }
    }
    
    return memories.slice(0, this.config.maxContextMemories);
  }

  _getSidekickContext(options = {}) {
    const raw = options.sidekickContext || options.audienceContext || {};
    return {
      conversationSummary: raw.conversationSummary || options.conversationSummary || null,
      userContext: raw.userContext || options.userContext || null,
      roleFlags: raw.roleFlags || options.roleFlags || null,
      conversationState: raw.conversationState || options.conversationState || null,
      conversationHistory: raw.conversationHistory || options.conversationHistory || null,
      decision: raw.decision || options.decision || null,
      eventType: raw.eventType || options.eventType || null,
      source: raw.source || options.source || null
    };
  }

  _formatSidekickConversationState(conversationState = null) {
    if (!conversationState) return null;
    if (typeof conversationState === 'string') {
      const text = conversationState.trim();
      return text ? text.slice(0, 400) : null;
    }
    if (typeof conversationState !== 'object') return null;

    const parts = [];
    if (conversationState.summary) {
      const summary = String(conversationState.summary).trim();
      if (summary) parts.push(summary.slice(0, 280));
    }
    if (conversationState.active !== undefined && conversationState.active !== null) {
      parts.push(conversationState.active ? 'active' : 'idle');
    }
    if (Number.isFinite(Number(conversationState.turnCount))) {
      parts.push(`Turns=${Math.round(Number(conversationState.turnCount))}`);
    }
    if (Array.isArray(conversationState.recentTurns)) {
      const recent = conversationState.recentTurns
        .slice(-3)
        .map((turn) => {
          const speaker = String(turn?.speaker || 'turn').trim();
          const text = String(turn?.text || '').trim();
          return text ? `[${speaker}] ${text}` : null;
        })
        .filter(Boolean)
        .join(' | ');
      if (recent) parts.push(`Recent=${recent.slice(0, 220)}`);
    }

    return parts.length > 0 ? parts.join(' | ').slice(0, 400) : null;
  }

  _formatSidekickConversationSummary(conversationSummary = null) {
    if (!conversationSummary) return null;
    if (typeof conversationSummary === 'string') {
      const text = conversationSummary.trim();
      return text ? text.slice(0, 400) : null;
    }
    if (typeof conversationSummary !== 'object') return null;

    const summary = String(conversationSummary.summary || '').trim();
    if (summary) {
      return summary.slice(0, 400);
    }

    const parts = [];
    if (conversationSummary.nickname) {
      parts.push(`Name=${String(conversationSummary.nickname).trim().slice(0, 40)}`);
    }
    if (Number.isFinite(Number(conversationSummary.messageCount))) {
      parts.push(`Messages=${Math.round(Number(conversationSummary.messageCount))}`);
    }
    if (Array.isArray(conversationSummary.recentMessages)) {
      const recent = conversationSummary.recentMessages
        .slice(0, 3)
        .map((item) => String(item?.text || '').trim())
        .filter(Boolean)
        .join(' | ');
      if (recent) parts.push(`Recent=${recent.slice(0, 200)}`);
    }

    return parts.length > 0 ? parts.join(' | ').slice(0, 400) : null;
  }

  _formatSidekickUserContext(userContext = null) {
    if (!userContext) return null;
    if (typeof userContext === 'string') {
      const text = userContext.trim();
      return text ? text.slice(0, 400) : null;
    }
    if (typeof userContext !== 'object') return null;

    if (userContext.summary) {
      const summary = String(userContext.summary).trim();
      if (summary) return summary.slice(0, 400);
    }

    const parts = [];
    if (userContext.nickname) {
      parts.push(`Name=${String(userContext.nickname).trim().slice(0, 40)}`);
    }
    const countFields = [
      ['messages', 'Messages'],
      ['likes', 'Likes'],
      ['gifts', 'Gifts'],
      ['follows', 'Follows'],
      ['subs', 'Subs'],
      ['shares', 'Shares'],
      ['joins', 'Joins'],
      ['messageCount', 'Messages']
    ];
    for (const [field, label] of countFields) {
      if (userContext[field] !== undefined && userContext[field] !== null) {
        const value = Number(userContext[field]);
        if (Number.isFinite(value)) parts.push(`${label}=${Math.round(value)}`);
      }
    }
    const roleFlags = [];
    if (userContext.isFollower) roleFlags.push('Follower');
    if (userContext.isSubscriber) roleFlags.push('Subscriber');
    if (userContext.isModerator) roleFlags.push('Moderator');
    if (roleFlags.length > 0) parts.push(roleFlags.join('/'));

    return parts.length > 0 ? parts.join(', ').slice(0, 400) : null;
  }

  _formatSidekickRoleSummary(roleFlags = null) {
    if (!roleFlags) return null;
    if (typeof roleFlags === 'string') {
      const text = roleFlags.trim();
      return text ? text.slice(0, 120) : null;
    }
    if (typeof roleFlags !== 'object') return null;

    const parts = [];
    if (roleFlags.isFollower) parts.push('Follower');
    if (roleFlags.isSubscriber) parts.push('Subscriber');
    if (roleFlags.isModerator) parts.push('Moderator');
    return parts.length > 0 ? parts.join('/').slice(0, 120) : null;
  }

  _decorateUserInfoWithSidekickContext(userInfo = {}, sidekickContext = {}) {
    const next = { ...userInfo };
    const conversationSummary = this._formatSidekickConversationSummary(sidekickContext.conversationSummary);
    const conversationState = this._formatSidekickConversationState(sidekickContext.conversationState);
    const userContextSummary = this._formatSidekickUserContext(sidekickContext.userContext);
    const roleSummary = this._formatSidekickRoleSummary(sidekickContext.roleFlags || sidekickContext.userContext);

    if (conversationSummary) next.sidekickConversationSummary = conversationSummary;
    if (conversationState) next.sidekickConversationState = conversationState;
    if (userContextSummary) next.sidekickUserContextSummary = userContextSummary;
    if (roleSummary) next.sidekickRoleSummary = roleSummary;
    if (sidekickContext.decision?.reason) {
      next.sidekickDecisionReason = String(sidekickContext.decision.reason).trim().slice(0, 120);
    }
    if (sidekickContext.decision?.selection) {
      next.sidekickDecisionSelection = String(sidekickContext.decision.selection).trim().slice(0, 80);
    }
    if (sidekickContext.eventType) {
      next.sidekickEventType = String(sidekickContext.eventType).trim().slice(0, 40);
    }
    if (sidekickContext.source) {
      next.sidekickSource = String(sidekickContext.source).trim().slice(0, 40);
    }

    return next;
  }

  _formatSidekickMemoryContext(sidekickContext = {}) {
    return [
      this._formatSidekickConversationSummary(sidekickContext.conversationSummary),
      this._formatSidekickConversationState(sidekickContext.conversationState),
      this._formatSidekickUserContext(sidekickContext.userContext),
      this._formatSidekickRoleSummary(sidekickContext.roleFlags || sidekickContext.userContext)
    ].filter(Boolean).join(' | ') || null;
  }

  _prependSidekickContextMemories(memories = [], sidekickContext = {}) {
    const next = Array.isArray(memories) ? [...memories] : [];
    const sidekickMemories = [
      this._formatSidekickConversationSummary(sidekickContext.conversationSummary),
      this._formatSidekickConversationState(sidekickContext.conversationState),
      this._formatSidekickUserContext(sidekickContext.userContext),
      this._formatSidekickRoleSummary(sidekickContext.roleFlags || sidekickContext.userContext)
    ].filter(Boolean);

    for (const memory of sidekickMemories.reverse()) {
      if (!next.includes(memory)) {
        next.unshift(memory);
      }
    }

    return next.slice(0, this.config.maxContextMemories);
  }

  /**
   * Store a new memory
   */
  storeMemory(content, options = {}) {
    const memoryId = this.memoryDb.storeMemory({
      type: options.type || 'interaction',
      content,
      context: options.context,
      importance: options.importance || 0.5,
      tags: options.tags,
      user: options.user,
      event: options.event
    });
    
    // Also store in vector memory
    const embedding = this.vectorMemory.storeVector(memoryId, content);
    
    // Update embedding in database
    this.memoryDb.db.prepare(`
      UPDATE animazingpal_memories SET embedding = ? WHERE id = ?
    `).run(JSON.stringify(embedding), memoryId);

    if (options.user && this.config.liveHost?.viewerMemory?.enabled && this.config.liveHost.viewerMemory.writeMemories) {
      try {
        this.viewerMemory.recordMemory(options.user, {
          streamerId: this.config.liveHost.viewerMemory.streamerId || this.getStreamerId(),
          type: options.type || 'interaction',
          content,
          importance: options.importance || 0.5,
          metadata: { event: options.event || null, tags: options.tags || [] }
        });
      } catch (error) {
        this.logger.warn(`Viewer Profiles memory write failed: ${error.message}`);
      }
    }
    
    return memoryId;
  }

  /**
   * Process a chat message and optionally generate response
   */
  async processChat(username, message, options = {}) {
    if (!this.config.enabled || !this.gptBrain || !this.currentPersonality) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    
    // Get or create user profile
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    
    // Add to interaction history
    this.memoryDb.addInteractionToHistory(username, 'chat', message, {
      sessionId: this.currentSession
    });
    
    // Store the chat as a memory
    this.storeMemory(`${username} sagte: "${message}"`, {
      type: 'chat',
      user: username,
      event: 'chat',
      importance: 0.4,
      context: this._formatSidekickMemoryContext(sidekickContext),
      tags: ['chat']
    });
    
    // Store in conversation history
    this.memoryDb.storeConversation(this.currentSession, 'user', message, username);
    
    // Check if we should respond
    if (!this.config.autoRespond.chat && !options.forceRespond) {
      return null;
    }
    
    // Probabilistic response (don't respond to every chat)
    if (!options.forceRespond && Math.random() > this.config.chatResponseProbability) {
      return null;
    }
    
    // Check rate limit
    if (!this._checkRateLimit()) {
      this.logger.debug('Rate limit reached, skipping chat response');
      return null;
    }
    
    try {
      // Get context - include user memories and interaction history
      const contextMemories = this._prependSidekickContextMemories(
        this._getContextMemories(message, username),
        sidekickContext
      );
      const conversationHistory = this.memoryDb.getConversationHistory(this.currentSession, 10);
      const interactionHistory = this.memoryDb.getInteractionHistory(username, 5);
      const viewerContext = this.config.liveHost?.viewerMemory?.enabled
        ? this.viewerMemory.getViewerContext(username, this.config.liveHost.viewerMemory, this.config.liveHost.privacy)
        : { profile: null, insights: null, topGifts: [] };
      
      // Build enhanced user info with interaction context
      const enhancedUserInfo = {
        ...userProfile,
        ...(viewerContext.profile || {}),
        viewer_insights: viewerContext.insights || null,
        top_gifts: viewerContext.topGifts || [],
        interaction_history: interactionHistory,
        recent_interactions: interactionHistory.length,
        last_topic: userProfile.last_topic || 'unknown'
      };
      const sidekickAwareUserInfo = this._decorateUserInfoWithSidekickContext(enhancedUserInfo, sidekickContext);
      
      // Generate response with enriched context
      const result = await this.gptBrain.generateChatResponse(
        username,
        message,
        this._resolveSystemPrompt(options),
        {
          memories: contextMemories,
          userInfo: sidekickAwareUserInfo,
          sidekickContext,
          conversationHistory: conversationHistory.map(c => ({
            role: c.role,
            content: c.content
          }))
        }
      );
      
      // Store response in conversation history
      this.memoryDb.storeConversation(this.currentSession, 'assistant', result.content, null, this._selectEmotion());
      
      // Add response to interaction history
      this.memoryDb.addInteractionToHistory(username, 'response', result.content, {
        sessionId: this.currentSession
      });
      
      // Store response as memory
      this.storeMemory(`Ich antwortete ${username}: "${result.content}"`, {
        type: 'response',
        event: 'chat_response',
        importance: 0.3
      });
      
      // Extract and store last topic if possible
      this._extractAndUpdateTopic(username, message, result.content);
      
      return {
        text: result.content,
        emotion: this._selectEmotion(),
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate chat response: ${error.message}`);
      return null;
    }
  }

  /**
   * Process speech from the streamer/host without treating it as viewer chat.
   */
  async processHostSpeech(hostName, message, options = {}) {
    this.lastHostSpeechError = null;
    const readiness = this.getHostSpeechReadiness();
    if (!readiness.ready) {
      this.logger.debug(`Host speech brain not ready: ${readiness.reason}`);
      return null;
    }

    if (!message || !String(message).trim()) {
      return null;
    }

    const shouldRespond = options.forceRespond === true
      || options.decision?.respond === true
      || this.config.autoRespond?.chat;
    if (!shouldRespond) {
      return null;
    }

    let reservedRateLimitSlot = false;
    if (!this._checkRateLimit()) {
      this.logger.debug('Rate limit reached, skipping host speech response');
      return null;
    }
    reservedRateLimitSlot = true;

    try {
      const conversationHistory = this.memoryDb.getConversationHistory(this.currentSession, 10);
      this.memoryDb.storeConversation(this.currentSession, 'user', message, hostName || 'Host');
      this.storeMemory(`Host ${hostName || 'Host'} sagte: "${message}"`, {
        type: 'host_speech',
        event: 'host_speech',
        importance: 0.35
      });

      const personality = [
        this._resolveSystemPrompt(options),
        'Rolle: Du bist der Sidekick/Co-Host und antwortest dem Streamer, nicht einem Zuschauer.'
      ].filter(Boolean).join('\n\n');

      const fallbackLiveContext = this.streamContext || {};
      const providedLiveContext = options.liveContext && typeof options.liveContext === 'object'
        ? options.liveContext
        : {};
      const liveContext = {
        ...fallbackLiveContext,
        ...providedLiveContext
      };
      if (!Array.isArray(providedLiveContext.recentEvents) || providedLiveContext.recentEvents.length === 0) {
        liveContext.recentEvents = Array.isArray(fallbackLiveContext.recentEvents)
          ? fallbackLiveContext.recentEvents
          : [];
      }
      if (providedLiveContext.viewerCount === undefined || providedLiveContext.viewerCount === null) {
        liveContext.viewerCount = fallbackLiveContext.viewerCount;
      }

      const result = typeof this.gptBrain.generateHostSpeechResponse === 'function'
        ? await this.gptBrain.generateHostSpeechResponse(
          hostName || 'Host',
          message,
          personality,
          {
            liveContext,
            conversationHistory: conversationHistory.map(c => ({
              role: c.role,
              content: c.content
            }))
          }
        )
        : await this.gptBrain.generateChatResponse(
          hostName || 'Host',
          message,
          personality,
          {
            conversationHistory: conversationHistory.map(c => ({
              role: c.role,
              content: c.content
            }))
          }
        );

      const emotion = this._selectEmotion();
      if (!result?.content) {
        throw new Error('Provider returned no response content');
      }
      let committed = false;
      const commit = () => {
        if (committed) return false;
        committed = true;
        this.memoryDb.storeConversation(this.currentSession, 'assistant', result.content, null, emotion);
        this.storeMemory(`Ich antwortete Host ${hostName || 'Host'}: "${result.content}"`, {
          type: 'host_response',
          event: 'host_speech_response',
          importance: 0.3
        });
        return true;
      };

      if (!options.deferCommit) {
        commit();
      }

      const response = {
        text: result.content,
        emotion,
        cached: result.cached
      };
      if (options.deferCommit) response.commit = commit;
      return response;
    } catch (error) {
      if (reservedRateLimitSlot) this._releaseRateLimitSlot();
      this.lastHostSpeechError = {
        message: error?.message || 'Unknown host speech brain error',
        at: new Date().toISOString()
      };
      this.logger.error(`Failed to generate host speech response: ${error.message}`);
      return null;
    }
  }

  /**
   * Process a gift event and generate thank you
   */
  async processGift(username, giftName, giftValue, options = {}) {
    if (!this.config.enabled || !this.gptBrain || !this.currentPersonality) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    
    // Get user profile and record gift
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    this.memoryDb.recordGift(username, giftValue);
    
    // Add to interaction history
    this.memoryDb.addInteractionToHistory(username, 'gift', giftName, {
      diamonds: giftValue,
      sessionId: this.currentSession
    });
    
    // Store as important memory
    const importance = Math.min(0.5 + (giftValue / 500), 1.0); // Higher value = more important
    this.storeMemory(`${username} schenkte mir "${giftName}" (${giftValue} Diamonds)!`, {
      type: 'gift',
      user: username,
      event: 'gift',
      importance,
      context: this._formatSidekickMemoryContext(sidekickContext),
      tags: ['gift', giftName]
    });
    
    // Check if we should respond
    if (!this.config.autoRespond.gifts && !options.forceRespond) {
      return null;
    }
    
    // Check rate limit
    if (!this._checkRateLimit()) {
      return null;
    }
    
    try {
      // Get interaction history for personalized response
      const interactionHistory = this.memoryDb.getInteractionHistory(username, 5);
      const enhancedUserInfo = this._decorateUserInfoWithSidekickContext({
        ...userProfile,
        interaction_history: interactionHistory,
        recent_gifts: interactionHistory.filter(i => i.type === 'gift').length
      }, sidekickContext);
      
      // Generate response
      const result = await this.gptBrain.generateGiftResponse(
        username,
        giftName,
        giftValue,
        this._resolveSystemPrompt(options),
        enhancedUserInfo
      );
      
      // Store response
      this.memoryDb.storeConversation(this.currentSession, 'assistant', result.content, null, 'grateful');
      
      // Add response to interaction history
      this.memoryDb.addInteractionToHistory(username, 'response', result.content, {
        type: 'gift_thanks',
        sessionId: this.currentSession
      });
      
      return {
        text: result.content,
        emotion: 'happy',
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate gift response: ${error.message}`);
      return null;
    }
  }

  /**
   * Process a follow event
   */
  async processFollow(username, options = {}) {
    if (!this.config.enabled) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    const isReturning = Boolean(options.isReturning) && Number(userProfile.interaction_count || 0) > 1;
    const displayName = String(options.nickname || username || '').trim() || username;
    const language = normalizeLanguageCode(options.language, 'de');
    const followFallback = {
      text: language === 'en'
        ? `Thanks for following, ${displayName}!`
        : `Danke f\u00fcr den Follow, ${displayName}!`,
      emotion: 'happy'
    };
    
    // Add to interaction history
    this.memoryDb.addInteractionToHistory(username, 'follow', '', {
      isReturning,
      sessionId: this.currentSession
    });
    
    // Store as memory
    this.storeMemory(`${username} folgt mir jetzt${isReturning ? ' wieder' : ''}!`, {
      type: 'follow',
      user: username,
      event: 'follow',
      importance: isReturning ? 0.6 : 0.4,
      context: this._formatSidekickMemoryContext(sidekickContext),
      tags: ['follow']
    });
    
    // Check if we should respond
    if (!this.config.autoRespond.follows && !options.forceRespond) {
      return null;
    }
    
    // Check rate limit
    if (!this._checkRateLimit()) {
      return null;
    }
    
    try {

      if (!this.gptBrain || !this.currentPersonality) {
        return followFallback;
      }

      const result = await this.gptBrain.generateFollowResponse(
        username,
        this._resolveSystemPrompt(options),
        isReturning,
        {
          userInfo: this._decorateUserInfoWithSidekickContext(userProfile, sidekickContext),
          sidekickContext
        }
      );
      if (!result || !result.content) {
        return followFallback;
      }
      
      // Add response to interaction history
      this.memoryDb.addInteractionToHistory(username, 'response', result.content, {
        type: 'follow_welcome',
        sessionId: this.currentSession
      });
      
      return {
        text: result.content,
        emotion: 'happy',
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate follow response: ${error.message}`);
      return followFallback;
    }
  }

  /**
   * Process a share event
   */
  async processShare(username, options = {}) {
    if (!this.config.enabled || !this.gptBrain || !this.currentPersonality) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    
    // Store as memory
    this.storeMemory(`${username} hat den Stream geteilt!`, {
      type: 'share',
      user: username,
      event: 'share',
      importance: 0.5,
      context: this._formatSidekickMemoryContext(sidekickContext),
      tags: ['share']
    });
    
    if (!this.config.autoRespond.shares && !options.forceRespond) {
      return null;
    }
    
    if (!this._checkRateLimit()) {
      return null;
    }
    
    try {
      const result = await this.gptBrain.generateQuickReaction(
        `${username} hat deinen Stream geteilt!`,
        this._resolveSystemPrompt(options),
        'grateful',
        {
          username,
          userInfo: this._decorateUserInfoWithSidekickContext(userProfile, sidekickContext),
          sidekickContext
        }
      );
      
      return {
        text: result.content,
        emotion: 'happy',
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate share response: ${error.message}`);
      return null;
    }
  }

  /**
   * Select emotion based on personality tendencies
   */
  _selectEmotion() {
    if (!this.currentPersonality || !this.currentPersonality.emotion_tendencies) {
      return 'neutral';
    }
    
    const tendencies = this.currentPersonality.emotion_tendencies;
    const emotions = Object.keys(tendencies);
    if (emotions.length === 0) return 'neutral';
    
    // Weighted random selection
    const totalWeight = Object.values(tendencies).reduce((sum, w) => sum + w, 0);
    let random = Math.random() * totalWeight;
    
    for (const [emotion, weight] of Object.entries(tendencies)) {
      random -= weight;
      if (random <= 0) return emotion;
    }
    
    return emotions[0];
  }

  /**
   * Archive old memories
   */
  async archiveOldMemories() {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.config.archiveAfterDays);
    
    // Get old memories
    const oldMemories = this.memoryDb.db.prepare(`
      SELECT * FROM animazingpal_memories 
      WHERE created_at < ? AND importance >= ?
      ORDER BY created_at ASC
      LIMIT 100
    `).all(cutoffDate.toISOString(), this.config.memoryImportanceThreshold);
    
    if (oldMemories.length === 0) return;
    
    try {
      // Generate summary using GPT
      const summary = await this.gptBrain.summarizeMemories(
        oldMemories,
        this.currentPersonality?.system_prompt || ''
      );
      
      // Extract key information
      const keyUsers = [...new Set(oldMemories.filter(m => m.source_user).map(m => m.source_user))];
      const keywords = this.vectorMemory.extractKeywords(
        oldMemories.map(m => m.content).join(' '),
        10
      );
      
      // Create archive
      this.memoryDb.createArchive(
        summary.content,
        oldMemories.map(m => m.id),
        keywords,
        keyUsers,
        {
          start: oldMemories[0].created_at,
          end: oldMemories[oldMemories.length - 1].created_at
        }
      );
      
      this.logger.info(`Archived ${oldMemories.length} memories`);
    } catch (error) {
      this.logger.error(`Failed to archive memories: ${error.message}`);
    }
  }

  /**
   * Get brain statistics
   */
  getStatistics() {
    const memoryStats = this.memoryDb.getStatistics();
    const vectorStats = this.vectorMemory.getStatistics();
    const gptStats = this.gptBrain?.getStatistics() || {};
    
    return {
      ...memoryStats,
      ...vectorStats,
      ...gptStats,
      currentSession: this.currentSession,
      currentPersonality: this.currentPersonality?.display_name,
      enabled: this.config.enabled,
      apiKeyConfigured: !!this.config.openaiApiKey
    };
  }

  /**
   * Test GPT connection
   */
  async testConnection() {
    if (!this.gptBrain) {
      return { success: false, message: 'GPT Brain not initialized. Set API key first.' };
    }
    
    return this.gptBrain.testConnection();
  }

  /**
   * Get user profile with memories
   */
  getUserProfile(username) {
    const profile = this.memoryDb.getOrCreateUserProfile(username);
    const memories = this.memoryDb.getUserMemories(username, 20);
    
    return {
      ...profile,
      memories: memories.map(m => ({
        content: m.content,
        type: m.memory_type,
        created_at: m.created_at
      }))
    };
  }

  /**
   * Search memories
   */
  searchMemories(query) {
    // Try both text and vector search
    const textResults = this.memoryDb.searchMemories(query, 10);
    const vectorResults = this.vectorMemory.findSimilar(query, 10, 0.15);
    
    // Combine and deduplicate
    const resultMap = new Map();
    
    for (const memory of textResults) {
      resultMap.set(memory.id, { ...memory, searchType: 'text' });
    }
    
    for (const { memoryId, similarity } of vectorResults) {
      if (!resultMap.has(memoryId)) {
        const memory = this.memoryDb.getRecentMemories(500).find(m => m.id === memoryId);
        if (memory) {
          resultMap.set(memoryId, { ...memory, similarity, searchType: 'vector' });
        }
      } else {
        resultMap.get(memoryId).similarity = similarity;
      }
    }
    
    return Array.from(resultMap.values()).sort((a, b) => {
      // Sort by similarity if available, otherwise by recency
      if (a.similarity && b.similarity) return b.similarity - a.similarity;
      return new Date(b.created_at) - new Date(a.created_at);
    });
  }

  /**
   * Extract and update the last discussed topic
   */
  _extractAndUpdateTopic(username, userMessage, botResponse) {
    try {
      // Simple keyword extraction from the conversation
      const combined = `${userMessage} ${botResponse}`.toLowerCase();
      
      // Topic keywords configuration - could be moved to a config file for multi-language support
      // TODO: Consider making this configurable per personality or language
      const topicKeywords = {
        gaming: ['spiel', 'game', 'gaming', 'zocken', 'spielen'],
        anime: ['anime', 'manga', 'waifu', 'otaku'],
        music: ['musik', 'song', 'lied', 'singen'],
        stream: ['stream', 'live', 'broadcast'],
        food: ['essen', 'food', 'hunger', 'kochen'],
        weather: ['wetter', 'weather', 'regen', 'sonne'],
        movies: ['film', 'movie', 'serie', 'show'],
        art: ['kunst', 'art', 'zeichnen', 'malen']
      };
      
      for (const [topic, keywords] of Object.entries(topicKeywords)) {
        for (const keyword of keywords) {
          if (combined.includes(keyword)) {
            this.memoryDb.updateLastTopic(username, topic);
            return topic;
          }
        }
      }
      
      // If no specific topic found, use generic
      if (userMessage.includes('?')) {
        this.memoryDb.updateLastTopic(username, 'questions');
      }
    } catch (error) {
      this.logger.debug(`Could not extract topic: ${error.message}`);
    }
    
    return null;
  }

  /**
   * Clean up and shutdown
   */
  async shutdown() {
    // Clear caches
    this.gptBrain?.clearCache();
    this.vectorMemory.clear();
    
    // Clear old conversations
    this.memoryDb.clearOldConversations(7);
    
    // Prune low-importance memories
    const pruned = this.memoryDb.pruneOldMemories(
      this.config.pruneAfterDays,
      this.config.memoryImportanceThreshold
    );
    
    this.logger.info(`Brain Engine shutdown. Pruned ${pruned} old memories.`);
  }

  // ==================== Human-like Decision Making ====================

  /**
   * Decide if the brain should speak based on event importance
   * This makes the AI behave more like a human - not responding to everything
   */
  shouldSpeak(eventType, eventData, importance) {
    // Check cooldown
    const now = Date.now();
    if (now - this.streamContext.lastSpoke < this.streamContext.speakCooldown) {
      this.logger.debug('Brain: Skipping response due to cooldown');
      return false;
    }
    
    // Check importance threshold
    if (importance < this.config.speakThreshold) {
      this.logger.debug(`Brain: Event importance ${importance} below threshold ${this.config.speakThreshold}`);
      return false;
    }
    
    // Check rate limit
    if (!this._checkRateLimit()) {
      return false;
    }
    
    // Human-like random variation (don't always respond even if allowed)
    const responseChance = Math.min(0.9, importance + 0.2);
    if (Math.random() > responseChance) {
      this.logger.debug('Brain: Randomly skipping to be more human-like');
      return false;
    }
    
    return true;
  }

  /**
   * Calculate event importance for decision making
   */
  calculateEventImportance(eventType, eventData) {
    let importance = 0.3; // Base importance
    
    switch (eventType) {
      case 'gift':
        // Gift importance based on value
        const giftValue = eventData.diamondCount || 1;
        importance = Math.min(0.3 + (giftValue / 200), 1.0);
        break;
        
      case 'subscribe':
        importance = 0.9; // Subscriptions are always important
        break;
        
      case 'follow':
        // Check if returning viewer
        const profile = this.memoryDb.getOrCreateUserProfile(eventData.uniqueId || 'unknown');
        importance = profile.interaction_count > 3 ? 0.7 : 0.5;
        break;
        
      case 'share':
        importance = 0.6; // Shares are moderately important
        break;
        
      case 'chat':
        // Chat importance based on content
        const message = eventData.comment || '';
        // Direct mentions or questions are more important
        if (message.includes('?') || message.includes('@')) {
          importance = 0.7;
        }
        // Longer messages might be more thoughtful
        else if (message.length > 50) {
          importance = 0.5;
        }
        // Check if from known supporter
        const chatProfile = this.memoryDb.getOrCreateUserProfile(eventData.uniqueId || 'unknown');
        if (chatProfile.total_diamonds > 100) {
          importance += 0.2;
        }
        break;
        
      case 'like':
        // Only significant like bursts
        const likeCount = eventData.likeCount || 1;
        importance = likeCount >= 100 ? 0.4 : 0.1;
        break;
        
      default:
        importance = 0.3;
    }
    
    return Math.min(importance, 1.0);
  }

  /**
   * Process any stream event through the brain
   * The brain decides if and how to respond
   */
  async processEvent(eventType, eventData, options = {}) {
    if (!this.config.enabled) {
      return null;
    }
    
    // Calculate importance
    const importance = this.calculateEventImportance(eventType, eventData);
    
    // Store memory regardless of response
    const username = eventData.uniqueId || eventData.username || 'anonymous';
    this.storeEventMemory(eventType, eventData, importance);
    
    // Update stream context
    this.updateStreamContext(eventType, eventData);
    
    // Decide if we should respond
    if (!options.forceRespond && !this.shouldSpeak(eventType, eventData, importance)) {
      return null;
    }
    
    // Generate appropriate response
    let response = null;
    try {
      switch (eventType) {
        case 'chat':
          response = await this.processChat(username, eventData.comment, options);
          break;
        case 'gift':
          response = await this.processGift(username, eventData.giftName, eventData.diamondCount || 1, options);
          break;
        case 'follow':
          response = await this.processFollow(username, options);
          break;
        case 'share':
          response = await this.processShare(username, options);
          break;
        case 'subscribe':
          response = await this.processSubscribe(username, options);
          break;
        case 'like':
          response = await this.processLike(username, eventData.likeCount || 1, options);
          break;
      }
      
      if (response) {
        this.streamContext.lastSpoke = Date.now();
      }
    } catch (error) {
      this.logger.error(`Brain: Error processing ${eventType}: ${error.message}`);
    }
    
    return response;
  }

  /**
   * Store an event as a memory
   */
  storeEventMemory(eventType, eventData, importance) {
    const username = eventData.uniqueId || 'anonymous';
    let content = '';
    
    switch (eventType) {
      case 'chat':
        content = `${username} sagte: "${eventData.comment}"`;
        break;
      case 'gift':
        content = `${username} schenkte "${eventData.giftName}" (${eventData.diamondCount || 1} Diamonds)`;
        break;
      case 'follow':
        content = `${username} folgt mir jetzt`;
        break;
      case 'share':
        content = `${username} hat den Stream geteilt`;
        break;
      case 'subscribe':
        content = `${username} hat abonniert!`;
        break;
      case 'like':
        content = `${username} hat ${eventData.likeCount || 1} Likes gegeben`;
        break;
      default:
        content = `Event: ${eventType} von ${username}`;
    }
    
    this.storeMemory(content, {
      type: eventType,
      user: username,
      event: eventType,
      importance
    });
  }

  /**
   * Update stream context
   */
  updateStreamContext(eventType, eventData) {
    // Add to recent events
    this.streamContext.recentEvents.push({
      type: eventType,
      data: eventData,
      time: Date.now()
    });
    
    // Keep only last 50 events
    if (this.streamContext.recentEvents.length > 50) {
      this.streamContext.recentEvents = this.streamContext.recentEvents.slice(-50);
    }
    
    // Update mood based on events
    if (eventType === 'gift' || eventType === 'subscribe') {
      this.streamContext.mood = 'excited';
    } else if (this.streamContext.recentEvents.filter(e => e.type === 'follow').length > 5) {
      this.streamContext.mood = 'happy';
    }
  }

  /**
   * Process a subscribe event
   */
  async processSubscribe(username, options = {}) {
    if (!this.config.enabled || !this.gptBrain || !this.currentPersonality) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    
    this.storeMemory(`${username} hat abonniert! Wichtiger Moment!`, {
      type: 'subscribe',
      user: username,
      event: 'subscribe',
      importance: 0.9,
      context: this._formatSidekickMemoryContext(sidekickContext),
      tags: ['subscribe']
    });
    
    if (!this.config.autoRespond.subscribe && !options.forceRespond) {
      return null;
    }
    
    try {
      const result = await this.gptBrain.generateQuickReaction(
        `${username} hat gerade abonniert! Das ist ein besonderer Moment.`,
        this._resolveSystemPrompt(options),
        'excited',
        {
          username,
          userInfo: this._decorateUserInfoWithSidekickContext(userProfile, sidekickContext),
          sidekickContext
        }
      );
      
      return {
        text: result.content,
        emotion: 'excited',
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate subscribe response: ${error.message}`);
      return null;
    }
  }

  /**
   * Process a like event (only for significant amounts)
   */
  async processLike(username, likeCount, options = {}) {
    if (!this.config.enabled || !this.gptBrain || !this.currentPersonality) {
      return null;
    }

    const sidekickContext = this._getSidekickContext(options);
    const userProfile = this.memoryDb.getOrCreateUserProfile(username, options.nickname);
    
    // Only respond to significant like bursts
    if (likeCount < 50 && !options.forceRespond) {
      return null;
    }
    
    if (!this.config.autoRespond.likes && !options.forceRespond) {
      return null;
    }
    
    try {
      const result = await this.gptBrain.generateQuickReaction(
        `Wow, ${likeCount} Likes von ${username}!`,
        this._resolveSystemPrompt(options),
        'happy',
        {
          username,
          userInfo: this._decorateUserInfoWithSidekickContext(userProfile, sidekickContext),
          sidekickContext
        }
      );
      
      return {
        text: result.content,
        emotion: 'happy',
        cached: result.cached
      };
    } catch (error) {
      this.logger.error(`Failed to generate like response: ${error.message}`);
      return null;
    }
  }

  /**
   * Get available streamer profiles
   */
  getStreamerProfiles() {
    return this.memoryDb.getStreamerProfiles();
  }
}

module.exports = BrainEngine;
