module.exports = {
  content: [
    './public/**/*.html',
    './plugins/**/ui/**/*.html',
    './public/js/**/*.js',
    './plugins/**/ui/**/*.js'
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
