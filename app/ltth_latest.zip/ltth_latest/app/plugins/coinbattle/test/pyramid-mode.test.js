const PyramidMode = require('../engine/pyramid-mode');

const createMockLogger = () => ({
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
  debug: jest.fn()
});

const createMockIO = () => ({
  emit: jest.fn()
});

describe('PyramidMode avatar normalization', () => {
  test('adds profile_picture_url for overlay consumers', () => {
    const io = createMockIO();
    const pyramid = new PyramidMode({}, io, createMockLogger());
    pyramid.active = true;
    pyramid.roundDuration = pyramid.config.roundDuration;
    pyramid.remainingTime = pyramid.config.roundDuration;
    pyramid.roundStartTime = Date.now();
    pyramid.config.minCoinsToJoin = 0;

    const user = {
      userId: 'user-1',
      uniqueId: 'user_one',
      nickname: 'User One',
      profilePictureUrl: 'https://cdn.example.com/avatar.png'
    };

    pyramid.addPoints(user, 100, 'gift', 100);

    const player = pyramid.players.get('user-1');
    expect(player.profilePictureUrl).toBe(user.profilePictureUrl);
    expect(player.profile_picture_url).toBe(user.profilePictureUrl);

    const leaderboardEmit = io.emit.mock.calls.find((call) => call[0] === 'pyramid:leaderboard-update');
    expect(leaderboardEmit).toBeTruthy();
    expect(leaderboardEmit[1].leaderboard[0].profile_picture_url).toBe(user.profilePictureUrl);
  });
});
