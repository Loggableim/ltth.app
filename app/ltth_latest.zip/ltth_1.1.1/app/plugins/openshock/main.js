/**
 * OpenShock Integration Plugin - Main Class
 *
 * Vollständige OpenShock API-Integration für TikTok Live Events
 *
 * Features:
 * - OpenShock API Integration (Shock, Vibrate, Sound)
 * - Event-Mapping-System (TikTok Events → OpenShock Actions)
 * - Pattern Engine (8 Preset-Patterns + Custom Patterns)
 * - Safety Layer (Multi-Level Limits & Emergency Stop)
 * - Queue System (Priority, Retry, Load-Balancing)
 * - Real-time Dashboard & Overlay
 * - Import/Export von Mappings & Patterns
 *
 * @version 1.0.0
 * @author pupcidslittletiktokhelper Team
 */

const path = require('path');
const fs = require('fs').promises;

// Helper-Klassen
const OpenShockClient = require('./helpers/openShockClient');
const MappingEngine = require('./helpers/mappingEngine');
const PatternEngine = require('./helpers/patternEngine');
const SafetyManager = require('./helpers/safetyManager');
const QueueManager = require('./helpers/queueManager');

class OpenShockPlugin {
    constructor(api) {
        this.api = api;

        // Configuration (wird in init() geladen)
        this.config = {
            apiKey: '',
            baseUrl: 'https://api.openshock.app',
            globalLimits: {
                maxIntensity: 80,
                maxDuration: 5000,
                maxCommandsPerMinute: 30
            },
            defaultCooldowns: {
                global: 5000,
                perDevice: 3000,
                perUser: 10000
            },
            userLimits: {
                minFollowerAge: 7,
                maxCommandsPerUser: 10
            },
            likeThreshold: {
                minLikes: 10,           // Minimum number of likes before triggering
                timeWindow: 5000        // Time window in milliseconds (5 seconds)
            },
            queueSettings: {
                maxQueueSize: 1000,
                processingDelay: 300
            },
            emergencyStop: {
                enabled: false
            },
            overlay: {
                enabled: true,
                showDevice: true,
                showIntensity: true,
                showPattern: true,
                animationDuration: 2000
            }
        };

        // Helper-Instanzen (werden in init() initialisiert)
        this.openShockClient = null;
        this.mappingEngine = null;
        this.patternEngine = null;
        this.safetyManager = null;
        this.queueManager = null;

        // State
        this.devices = [];
        this.isRunning = false;
        this.isPaused = false;

        // Statistics
        this.stats = {
            startTime: null,
            totalCommands: 0,
            successfulCommands: 0,
            failedCommands: 0,
            queuedCommands: 0,
            blockedCommands: 0,
            emergencyStops: 0,
            tiktokEventsProcessed: 0,
            patternsExecuted: 0,
            lastCommandTime: null,
            errors: []
        };

        // Pattern-Execution Tracking
        this.activePatternExecutions = new Map();

        // Like Threshold Tracking
        this.likeAccumulator = {
            count: 0,
            startTime: null,
            timer: null
        };

        // Log-Buffer für Frontend
        this.eventLog = [];
        this.maxEventLog = 500;
    }

    /**
     * Plugin initialisieren
     */
    async init() {
        try {
            this.api.log('OpenShock Plugin initializing...', 'info');

            // 1. Datenbank initialisieren
            this._initializeDatabase();

            // 2. Config laden
            await this.loadData();

            // 3. Helper initialisieren
            this._initializeHelpers();

            // 4. Routes registrieren
            this._registerRoutes();

            // 5. Socket.IO Events registrieren
            this._registerSocketEvents();

            // 6. TikTok Events registrieren
            this._registerTikTokEvents();

            // 6.5. IFTTT Flow Actions registrieren
            this._registerIFTTTActions();

            // 7. Devices laden (wenn API Key vorhanden)
            if (this.config.apiKey && this.config.apiKey.trim() !== '') {
                try {
                    await this.loadDevices();
                } catch (error) {
                    this.api.log(`Failed to load devices on init: ${error.message}`, 'warn');
                }
            }

            // 8. Queue monitoring (process queue on-demand via enqueue)
            // Queue will auto-process when items are added
            this.api.log('Queue manager ready - will auto-process on command enqueue', 'info');

            // 9. Stats-Timer starten
            this._startStatsTimer();

            this.isRunning = true;
            this.stats.startTime = Date.now();

            this.api.log('OpenShock Plugin initialized successfully', 'info');

            // Initial status broadcast
            this._broadcastStatus();

            return true;

        } catch (error) {
            this.api.log(`Failed to initialize OpenShock Plugin: ${error.message}`, 'error');
            console.error(error);
            throw error;
        }
    }

    /**
     * Datenbank-Tabellen erstellen
     */
    _initializeDatabase() {
        const db = this.api.getDatabase();

        // Config-Tabelle
        db.exec(`
            CREATE TABLE IF NOT EXISTS openshock_config (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        `);

        // Migration: Drop old tables if they have INTEGER id columns
        try {
            const mappingsTableInfo = db.prepare("PRAGMA table_info(openshock_mappings)").all();
            const idColumn = mappingsTableInfo.find(col => col.name === 'id');
            if (idColumn && idColumn.type === 'INTEGER') {
                this.api.log('Migrating openshock_mappings table to use TEXT id...', 'info');
                db.exec('DROP TABLE IF EXISTS openshock_mappings');
            }
        } catch (error) {
            // Table doesn't exist yet, that's fine
        }

        try {
            const patternsTableInfo = db.prepare("PRAGMA table_info(openshock_patterns)").all();
            const idColumn = patternsTableInfo.find(col => col.name === 'id');
            if (idColumn && idColumn.type === 'INTEGER') {
                this.api.log('Migrating openshock_patterns table to use TEXT id...', 'info');
                db.exec('DROP TABLE IF EXISTS openshock_patterns');
            }
        } catch (error) {
            // Table doesn't exist yet, that's fine
        }

        // Mappings-Tabelle
        db.exec(`
            CREATE TABLE IF NOT EXISTS openshock_mappings (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                enabled INTEGER DEFAULT 1,
                event_type TEXT NOT NULL,
                conditions TEXT,
                action TEXT NOT NULL,
                priority INTEGER DEFAULT 5,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Patterns-Tabelle
        db.exec(`
            CREATE TABLE IF NOT EXISTS openshock_patterns (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                steps TEXT NOT NULL,
                preset INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Event-Log-Tabelle
        db.exec(`
            CREATE TABLE IF NOT EXISTS openshock_event_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type TEXT NOT NULL,
                event_source TEXT NOT NULL,
                user_id TEXT,
                username TEXT,
                action_taken TEXT,
                success INTEGER,
                error_message TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Command-History-Tabelle
        db.exec(`
            CREATE TABLE IF NOT EXISTS openshock_command_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                device_id TEXT NOT NULL,
                device_name TEXT,
                command_type TEXT NOT NULL,
                intensity INTEGER,
                duration INTEGER,
                user_id TEXT,
                username TEXT,
                source TEXT,
                success INTEGER,
                error_message TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `);

        this.api.log('OpenShock database tables initialized', 'info');
    }

    /**
     * Create a logger adapter that wraps api.log to provide the standard logger interface
     * This ensures compatibility with helper classes that expect .info(), .warn(), .error() methods
     */
    _createLoggerAdapter() {
        const apiLog = this.api.log.bind(this.api);
        return {
            info: (msg, data) => apiLog(typeof msg === 'object' ? JSON.stringify(msg) : msg, 'info'),
            warn: (msg, data) => apiLog(typeof msg === 'object' ? JSON.stringify(msg) : msg, 'warn'),
            error: (msg, data) => apiLog(typeof msg === 'object' ? JSON.stringify(msg) : msg, 'error'),
            debug: (msg, data) => apiLog(typeof msg === 'object' ? JSON.stringify(msg) : msg, 'debug')
        };
    }

    /**
     * Helper-Klassen initialisieren
     */
    _initializeHelpers() {
        const logger = this._createLoggerAdapter();

        // OpenShock API Client
        this.openShockClient = new OpenShockClient(
            this.config.apiKey,
            this.config.baseUrl,
            logger
        );

        // Safety Manager
        this.safetyManager = new SafetyManager(
            {
                globalLimits: this.config.globalLimits,
                defaultCooldowns: this.config.defaultCooldowns,
                userLimits: this.config.userLimits,
                emergencyStop: this.config.emergencyStop
            },
            logger
        );

        // Mapping Engine
        this.mappingEngine = new MappingEngine(
            logger
        );

        // Pattern Engine
        this.patternEngine = new PatternEngine(
            logger
        );

        // Queue Manager
        this.queueManager = new QueueManager(
            this.openShockClient,
            this.safetyManager,
            logger
        );
        
        // Set up pattern execution cancellation callback
        // This allows QueueManager to check if a pattern execution has been cancelled
        this.queueManager.setShouldCancelExecution((executionId) => {
            const execution = this.activePatternExecutions.get(executionId);
            return execution && execution.cancelled;
        });

        // Queue Event-Handler (QueueManager wird später EventEmitter erweitern)
        // this.queueManager.on('item-processed', (item, success) => {
        //     this._broadcastQueueUpdate();
        //     if (success) {
        //         this.stats.successfulCommands++;
        //     } else {
        //         this.stats.failedCommands++;
        //     }
        // });

        // this.queueManager.on('queue-changed', () => {
        //     this._broadcastQueueUpdate();
        // });

        this.api.log('OpenShock helpers initialized', 'info');

        // Load mappings and patterns from database
        this._loadMappingsFromDatabase();
        this._loadPatternsFromDatabase();
    }

    /**
     * Routes registrieren (UI + API)
     */
    _registerRoutes() {
        const pluginDir = __dirname;

        // ============ UI ROUTES ============

        // Main UI
        this.api.registerRoute('get', '/openshock/ui', (req, res) => {
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'ui.html'));
        });

        // Overlay
        this.api.registerRoute('get', '/openshock/overlay', (req, res) => {
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'overlay', 'openshock_overlay.html'));
        });

        // CSS
        this.api.registerRoute('get', '/openshock/openshock.css', (req, res) => {
            res.setHeader('Content-Type', 'text/css; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'openshock.css'));
        });

        // UI JS (new standard naming)
        this.api.registerRoute('get', '/openshock/ui.js', (req, res) => {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'ui.js'));
        });

        // JS (legacy route for backward compatibility)
        this.api.registerRoute('get', '/openshock/openshock.js', (req, res) => {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'openshock.js'));
        });

        // Overlay CSS
        this.api.registerRoute('get', '/openshock/openshock_overlay.css', (req, res) => {
            res.setHeader('Content-Type', 'text/css; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'overlay', 'openshock_overlay.css'));
        });

        // Overlay JS
        this.api.registerRoute('get', '/openshock/openshock_overlay.js', (req, res) => {
            res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
            res.sendFile(path.join(pluginDir, 'overlay', 'openshock_overlay.js'));
        });

        // ============ API ROUTES - CONFIG ============

        // Get Config (WITHOUT API-KEY for security!)
        this.api.registerRoute('get', '/api/openshock/config', (req, res) => {
            const safeConfig = {
                ...this.config,
                apiKey: this.config.apiKey ? '***' + this.config.apiKey.slice(-4) : '' // Mask API key
            };
            res.json({
                success: true,
                config: safeConfig
            });
        });

        // Update Config
        this.api.registerRoute('post', '/api/openshock/config', async (req, res) => {
            try {
                const newConfig = req.body;

                // Merge config
                this.config = { ...this.config, ...newConfig };

                // Save to database
                await this.saveData();

                // Update OpenShockClient with new credentials
                if (this.openShockClient) {
                    this.openShockClient.updateConfig({
                        apiKey: this.config.apiKey,
                        baseUrl: this.config.baseUrl || 'https://api.openshock.app'
                    });
                    
                    this.api.log('OpenShock client updated with new configuration', 'info');
                } else if (this.config.apiKey) {
                    // If client doesn't exist yet, create it
                    const logger = this._createLoggerAdapter();
                    this.openShockClient = new OpenShockClient(
                        this.config.apiKey,
                        this.config.baseUrl || 'https://api.openshock.app',
                        logger
                    );
                    
                    // Update queue manager's client reference
                    if (this.queueManager) {
                        this.queueManager.openShockClient = this.openShockClient;
                    }
                    
                    this.api.log('OpenShock client created with new configuration', 'info');
                }

                if (this.safetyManager) {
                    this.safetyManager.updateConfig({
                        globalLimits: this.config.globalLimits,
                        defaultCooldowns: this.config.defaultCooldowns,
                        userLimits: this.config.userLimits,
                        emergencyStop: this.config.emergencyStop
                    });
                }

                // Automatically load devices when API key is configured
                let deviceLoadSuccess = false;
                let deviceCount = 0;
                if (this.openShockClient && this.config.apiKey) {
                    try {
                        await this.loadDevices();
                        deviceLoadSuccess = true;
                        deviceCount = this.devices.length;
                        this.api.log(`Automatically loaded ${deviceCount} device(s) after config update`, 'info');
                    } catch (loadError) {
                        this.api.log(`Could not auto-load devices after config update: ${loadError.message}`, 'warning');
                        // Don't fail the config save if device loading fails
                    }
                }

                this._broadcastStatus();

                res.json({
                    success: true,
                    message: 'Configuration updated successfully',
                    config: this.config,
                    deviceLoadSuccess,
                    deviceCount
                });

            } catch (error) {
                this.api.log(`Failed to update config: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Save Like Threshold Config
        this.api.registerRoute('post', '/api/openshock/config/like-threshold', (req, res) => {
            try {
                const { minLikes, timeWindow } = req.body;

                // Validation
                if (typeof minLikes !== 'number' || minLikes < 1 || minLikes > 10000) {
                    return res.status(400).json({
                        success: false,
                        error: 'minLikes must be a number between 1 and 10000'
                    });
                }

                if (typeof timeWindow !== 'number' || timeWindow < 500 || timeWindow > 300000) {
                    return res.status(400).json({
                        success: false,
                        error: 'timeWindow must be a number between 500 and 300000 milliseconds'
                    });
                }

                // Update config
                this.config.likeThreshold = {
                    minLikes: minLikes,
                    timeWindow: timeWindow
                };

                // Save to database
                await this.saveData();

                this.api.log(`Like threshold updated: ${minLikes} likes in ${timeWindow}ms`, 'info');
                this._broadcastDebugLog('success', `Like threshold updated: ${minLikes} likes in ${timeWindow / 1000}s`);

                res.json({
                    success: true,
                    message: 'Like threshold settings updated successfully',
                    likeThreshold: this.config.likeThreshold
                });

            } catch (error) {
                this.api.log(`Failed to update like threshold: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - DEVICES ============

        // Get Devices
        this.api.registerRoute('get', '/api/openshock/devices', (req, res) => {
            res.json({
                success: true,
                devices: this.devices
            });
        });

        // Refresh Devices
        this.api.registerRoute('post', '/api/openshock/devices/refresh', async (req, res) => {
            try {
                await this.loadDevices();

                res.json({
                    success: true,
                    message: 'Devices refreshed successfully',
                    devices: this.devices
                });

            } catch (error) {
                this.api.log(`Failed to refresh devices: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Get Single Device
        this.api.registerRoute('get', '/api/openshock/devices/:id', (req, res) => {
            const device = this.devices.find(d => d.id === req.params.id);

            if (!device) {
                return res.status(404).json({
                    success: false,
                    error: 'Device not found'
                });
            }

            res.json({
                success: true,
                device: device
            });
        });

        // Test Device
        this.api.registerRoute('post', '/api/openshock/test/:deviceId', async (req, res) => {
            try {
                const { deviceId } = req.params;
                const { type = 'vibrate', intensity = 30, duration = 1000 } = req.body;

                const device = this.devices.find(d => d.id === deviceId);
                if (!device) {
                    return res.status(404).json({
                        success: false,
                        error: 'Device not found'
                    });
                }

                // Check if shocker is paused
                if (device.isPaused) {
                    return res.status(403).json({
                        success: false,
                        error: 'Shocker is paused and cannot receive commands. Please unpause it in the OpenShock app first.'
                    });
                }

                // Safety-Check
                const safetyCheck = this.safetyManager.validateCommand({
                    deviceId,
                    type,
                    intensity,
                    duration,
                    userId: 'test-user',
                    source: 'manual-test'
                });

                if (!safetyCheck.allowed) {
                    return res.status(403).json({
                        success: false,
                        error: safetyCheck.reason
                    });
                }

                // Command senden
                await this.openShockClient.sendControl(deviceId, {
                    type,
                    intensity: safetyCheck.adjustedIntensity || intensity,
                    duration: safetyCheck.adjustedDuration || duration
                });

                // Log
                this._logCommand({
                    deviceId,
                    deviceName: device.name,
                    type,
                    intensity: safetyCheck.adjustedIntensity || intensity,
                    duration: safetyCheck.adjustedDuration || duration,
                    userId: 'test-user',
                    username: 'Manual Test',
                    source: 'manual-test',
                    success: true
                });

                this.stats.totalCommands++;
                this.stats.successfulCommands++;
                this.stats.lastCommandTime = Date.now();

                this._broadcastCommandSent({
                    device: device.name,
                    type,
                    intensity: safetyCheck.adjustedIntensity || intensity,
                    duration: safetyCheck.adjustedDuration || duration
                });

                res.json({
                    success: true,
                    message: 'Test command sent successfully'
                });

            } catch (error) {
                this.api.log(`Failed to send test command: ${error.message}`, 'error');
                
                // Log additional debug info
                if (error.response) {
                    this.api.log(`OpenShock API Error Details: ${JSON.stringify(error.response)}`, 'error');
                }
                
                // Provide helpful error message based on status code
                let userMessage = error.message;
                if (error.statusCode === 500) {
                    userMessage = 'OpenShock API server error. This could mean:\n' +
                                 '1. The API server is temporarily down\n' +
                                 '2. Your API key doesn\'t have permission to control this shocker\n' +
                                 '3. The shocker is offline or unavailable\n\n' +
                                 'Please check your OpenShock account and try again.';
                } else if (error.statusCode === 401 || error.statusCode === 403) {
                    userMessage = 'Authentication or permission error. Please check your API key has permission to control this shocker.';
                }
                
                res.status(500).json({
                    success: false,
                    error: userMessage
                });
            }
        });

        // ============ API ROUTES - MAPPINGS ============

        // Get All Mappings
        this.api.registerRoute('get', '/api/openshock/mappings', (req, res) => {
            try {
                const mappings = this.mappingEngine.getAllMappings();
                res.json({
                    success: true,
                    mappings
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Create Mapping
        this.api.registerRoute('post', '/api/openshock/mappings', async (req, res) => {
            try {
                const mapping = req.body;
                
                this.api.log(`[Mapping Save] Received mapping: ${mapping.name}`, 'info');
                this.api.log(`[Mapping Save] Event type: ${mapping.eventType}`, 'info');
                this.api.log(`[Mapping Save] Action type: ${mapping.action?.type}`, 'info');
                this.api.log(`[Mapping Save] Mapping data: ${JSON.stringify(mapping)}`, 'debug');
                
                const addedMapping = this.mappingEngine.addMapping(mapping);

                this.api.log(`[Mapping Save] Mapping added to engine with ID: ${addedMapping.id}`, 'info');

                // Save to database
                this._saveMappingToDatabase(addedMapping);

                this.api.log(`[Mapping Save] Mapping saved to database successfully`, 'info');

                res.json({
                    success: true,
                    message: 'Mapping created successfully',
                    id: addedMapping.id,
                    mapping: addedMapping
                });

            } catch (error) {
                this.api.log(`[Mapping Save] Error: ${error.message}`, 'error');
                this.api.log(`[Mapping Save] Stack: ${error.stack}`, 'debug');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Update Mapping
        this.api.registerRoute('put', '/api/openshock/mappings/:id', async (req, res) => {
            try {
                const id = req.params.id;
                const mapping = req.body;

                const updatedMapping = this.mappingEngine.updateMapping(id, mapping);

                // Save to database
                this._saveMappingToDatabase(updatedMapping);

                res.json({
                    success: true,
                    message: 'Mapping updated successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Delete Mapping
        this.api.registerRoute('delete', '/api/openshock/mappings/:id', async (req, res) => {
            try {
                const id = req.params.id;

                this.mappingEngine.deleteMapping(id);

                // Delete from database
                this._deleteMappingFromDatabase(id);

                res.json({
                    success: true,
                    message: 'Mapping deleted successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Import Mappings
        this.api.registerRoute('post', '/api/openshock/mappings/import', async (req, res) => {
            try {
                const { mappings } = req.body;

                if (!Array.isArray(mappings)) {
                    return res.status(400).json({
                        success: false,
                        error: 'Invalid mappings format'
                    });
                }

                let imported = 0;
                for (const mapping of mappings) {
                    const addedMapping = this.mappingEngine.addMapping(mapping);
                    // Save each mapping to database
                    this._saveMappingToDatabase(addedMapping);
                    imported++;
                }

                res.json({
                    success: true,
                    message: `${imported} mappings imported successfully`,
                    imported
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Export Mappings
        this.api.registerRoute('get', '/api/openshock/mappings/export', (req, res) => {
            try {
                const mappings = this.mappingEngine.getAllMappings();

                res.setHeader('Content-Type', 'application/json');
                res.setHeader('Content-Disposition', `attachment; filename="openshock-mappings-${Date.now()}.json"`);
                res.json(mappings);

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - PATTERNS ============

        // Get All Patterns
        this.api.registerRoute('get', '/api/openshock/patterns', (req, res) => {
            try {
                const patterns = this.patternEngine.getAllPatterns();
                res.json({
                    success: true,
                    patterns
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Create Pattern
        this.api.registerRoute('post', '/api/openshock/patterns', async (req, res) => {
            try {
                const pattern = req.body;
                
                this.api.log(`[Pattern Save] Received pattern: ${pattern.name}`, 'info');
                this.api.log(`[Pattern Save] Steps count: ${pattern.steps?.length || 0}`, 'info');
                this.api.log(`[Pattern Save] Steps data: ${JSON.stringify(pattern.steps)}`, 'debug');
                
                const addedPattern = this.patternEngine.addPattern(pattern);

                this.api.log(`[Pattern Save] Pattern added to engine with ID: ${addedPattern.id}`, 'info');

                // Save to database
                this._savePatternToDatabase(addedPattern);

                this.api.log(`[Pattern Save] Pattern saved to database successfully`, 'info');

                res.json({
                    success: true,
                    message: 'Pattern created successfully',
                    id: addedPattern.id,
                    pattern: addedPattern
                });

            } catch (error) {
                this.api.log(`[Pattern Save] Error: ${error.message}`, 'error');
                this.api.log(`[Pattern Save] Stack: ${error.stack}`, 'debug');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Update Pattern
        this.api.registerRoute('put', '/api/openshock/patterns/:id', async (req, res) => {
            try {
                const id = req.params.id;
                const pattern = req.body;

                const updatedPattern = this.patternEngine.updatePattern(id, pattern);

                // Save to database
                this._savePatternToDatabase(updatedPattern);

                res.json({
                    success: true,
                    message: 'Pattern updated successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Delete Pattern
        this.api.registerRoute('delete', '/api/openshock/patterns/:id', async (req, res) => {
            try {
                const id = req.params.id;

                this.patternEngine.deletePattern(id);

                // Delete from database
                this._deletePatternFromDatabase(id);

                res.json({
                    success: true,
                    message: 'Pattern deleted successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Execute Pattern
        this.api.registerRoute('post', '/api/openshock/patterns/execute', async (req, res) => {
            try {
                const { patternId, deviceId, variables = {} } = req.body;

                const pattern = this.patternEngine.getPattern(patternId);
                if (!pattern) {
                    return res.status(404).json({
                        success: false,
                        error: 'Pattern not found'
                    });
                }

                const device = this.devices.find(d => d.id === deviceId);
                if (!device) {
                    return res.status(404).json({
                        success: false,
                        error: 'Device not found'
                    });
                }

                // Pattern ausführen
                const executionId = await this._executePattern(pattern, device, {
                    userId: 'manual-execution',
                    username: 'Manual',
                    source: 'manual',
                    variables
                });

                res.json({
                    success: true,
                    message: 'Pattern execution started',
                    executionId
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Stop Pattern Execution
        this.api.registerRoute('post', '/api/openshock/patterns/stop/:executionId', async (req, res) => {
            try {
                const { executionId } = req.params;

                if (this.activePatternExecutions.has(executionId)) {
                    const execution = this.activePatternExecutions.get(executionId);
                    execution.cancelled = true;
                    this.activePatternExecutions.delete(executionId);

                    res.json({
                        success: true,
                        message: 'Pattern execution stopped'
                    });
                } else {
                    res.status(404).json({
                        success: false,
                        error: 'Execution not found or already completed'
                    });
                }

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Import Pattern
        this.api.registerRoute('post', '/api/openshock/patterns/import', async (req, res) => {
            try {
                const pattern = req.body;

                const addedPattern = this.patternEngine.addPattern(pattern);

                // Save to database
                this._savePatternToDatabase(addedPattern);

                res.json({
                    success: true,
                    message: 'Pattern imported successfully',
                    id: addedPattern.id
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Export Pattern
        this.api.registerRoute('get', '/api/openshock/patterns/export/:id', (req, res) => {
            try {
                // Pattern IDs are TEXT (UUIDs), not integers - use directly without parseInt
                const id = req.params.id;
                const pattern = this.patternEngine.getPattern(id);

                if (!pattern) {
                    return res.status(404).json({
                        success: false,
                        error: 'Pattern not found'
                    });
                }

                res.setHeader('Content-Type', 'application/json');
                res.setHeader('Content-Disposition', `attachment; filename="pattern-${pattern.name}-${Date.now()}.json"`);
                res.json(pattern);

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - GIFT CATALOG ============
        
        // Get Gift Catalog
        this.api.registerRoute('get', '/api/openshock/gift-catalog', (req, res) => {
            try {
                const db = this.api.getDatabase();
                const catalog = db.getGiftCatalog();
                
                res.json({
                    success: true,
                    gifts: catalog
                });
            } catch (error) {
                this.api.log(`Failed to get gift catalog: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - SAFETY ============

        // Get Safety Settings
        this.api.registerRoute('get', '/api/openshock/safety', (req, res) => {
            try {
                const settings = this.safetyManager.getSettings();
                res.json({
                    success: true,
                    settings
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Update Safety Settings
        this.api.registerRoute('post', '/api/openshock/safety', async (req, res) => {
            try {
                const settings = req.body;

                this.safetyManager.updateConfig(settings);

                // Update config
                this.config.globalLimits = settings.globalLimits || this.config.globalLimits;
                this.config.defaultCooldowns = settings.defaultCooldowns || this.config.defaultCooldowns;
                this.config.userLimits = settings.userLimits || this.config.userLimits;
                this.config.emergencyStop = settings.emergencyStop || this.config.emergencyStop;

                await this.saveData();

                res.json({
                    success: true,
                    message: 'Safety settings updated successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Emergency Stop
        this.api.registerRoute('post', '/api/openshock/emergency-stop', async (req, res) => {
            try {
                // Emergency Stop aktivieren
                this.safetyManager.triggerEmergencyStop('Manual emergency stop triggered via API');
                this.config.emergencyStop.enabled = true;

                await this.saveData();

                // Queue leeren
                await this.queueManager.clearQueue();

                // Alle Pattern-Executions stoppen
                this.activePatternExecutions.clear();

                // Stats
                this.stats.emergencyStops++;

                // Broadcast
                this._broadcastEmergencyStop();

                this.api.log('EMERGENCY STOP ACTIVATED', 'warn');

                res.json({
                    success: true,
                    message: 'Emergency stop activated'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Clear Emergency Stop
        this.api.registerRoute('post', '/api/openshock/emergency-clear', async (req, res) => {
            try {
                // Emergency Stop deaktivieren
                this.safetyManager.clearEmergencyStop();
                this.config.emergencyStop.enabled = false;

                await this.saveData();

                this.api.log('Emergency stop cleared', 'info');

                this._broadcastStatus();

                res.json({
                    success: true,
                    message: 'Emergency stop cleared'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - QUEUE ============

        // Get Queue Status
        this.api.registerRoute('get', '/api/openshock/queue/status', (req, res) => {
            try {
                const status = this.queueManager.getQueueStatus();
                res.json({
                    success: true,
                    status
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Clear Queue
        this.api.registerRoute('post', '/api/openshock/queue/clear', async (req, res) => {
            try {
                await this.queueManager.clearQueue();

                res.json({
                    success: true,
                    message: 'Queue cleared successfully'
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Remove Queue Item
        this.api.registerRoute('delete', '/api/openshock/queue/:id', (req, res) => {
            try {
                const id = req.params.id;
                const removed = this.queueManager.removeItem(id);

                if (removed) {
                    res.json({
                        success: true,
                        message: 'Queue item removed'
                    });
                } else {
                    res.status(404).json({
                        success: false,
                        error: 'Queue item not found'
                    });
                }

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - STATS ============

        // Get Statistics
        this.api.registerRoute('get', '/api/openshock/stats', (req, res) => {
            try {
                const uptime = this.stats.startTime ? Date.now() - this.stats.startTime : 0;
                const queueStatus = this.queueManager.getQueueStatus();

                res.json({
                    success: true,
                    stats: {
                        ...this.stats,
                        uptime,
                        queueSize: queueStatus.queueSize,
                        queuePending: queueStatus.pending,
                        queueProcessing: queueStatus.processing,
                        activePatternExecutions: this.activePatternExecutions.size,
                        devicesCount: this.devices.length,
                        mappingsCount: this.mappingEngine.getAllMappings().length,
                        patternsCount: this.patternEngine.getAllPatterns().length
                    }
                });

            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Test Connection
        this.api.registerRoute('post', '/api/openshock/test-connection', async (req, res) => {
            try {
                if (!this.openShockClient) {
                    return res.status(500).json({
                        success: false,
                        error: 'OpenShock client not initialized'
                    });
                }

                const result = await this.openShockClient.testConnection();
                
                if (result.success) {
                    res.json({
                        success: true,
                        message: 'Connection successful',
                        latency: result.latency,
                        deviceCount: result.deviceCount,
                        timestamp: result.timestamp
                    });
                } else {
                    res.status(500).json({
                        success: false,
                        error: result.error || 'Connection test failed'
                    });
                }

            } catch (error) {
                this.api.log(`Connection test failed: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // ============ API ROUTES - DEBUGGING & TESTING ============

        // Simulate Gift Event (for testing the complete pipeline)
        // Note: This is a debug/testing endpoint - consider adding authentication in production
        this.api.registerRoute('post', '/api/openshock/test/simulate-gift', async (req, res) => {
            try {
                // Input validation
                const body = req.body || {};
                
                // Validate and sanitize inputs
                const giftName = typeof body.giftName === 'string' ? body.giftName.substring(0, 100) : 'Rose';
                const giftId = typeof body.giftId === 'number' ? Math.abs(Math.floor(body.giftId)) : 5655;
                const coins = typeof body.coins === 'number' ? Math.max(0, Math.min(body.coins, 1000000)) : 1;
                const diamondCount = typeof body.diamondCount === 'number' ? Math.max(0, Math.min(body.diamondCount, 100000)) : 1;
                const repeatCount = typeof body.repeatCount === 'number' ? Math.max(1, Math.min(body.repeatCount, 10000)) : 1;
                const username = typeof body.username === 'string' ? body.username.substring(0, 50) : 'TestUser';
                const userId = typeof body.userId === 'string' ? body.userId.substring(0, 50) : 'test-user-123';
                const isStreakEnd = typeof body.isStreakEnd === 'boolean' ? body.isStreakEnd : true;

                this.api.log('🧪 [Test Simulator] Simulating gift event...', 'info');
                this.api.log(`   Gift: ${giftName} (ID: ${giftId})`, 'info');
                this.api.log(`   Coins: ${coins}`, 'info');
                this.api.log(`   User: ${username}`, 'info');

                // Create a realistic gift event matching TikTok's structure
                const simulatedGiftEvent = {
                    uniqueId: username,
                    username: username,
                    nickname: username,
                    userId: userId,
                    giftName: giftName,
                    giftId: giftId,
                    giftPictureUrl: `https://p16-webcast.tiktokcdn.com/img/${giftId}~tplv.webp`,
                    repeatCount: repeatCount,
                    diamondCount: diamondCount,
                    coins: coins,
                    totalCoins: coins,
                    isStreakEnd: isStreakEnd,
                    giftType: 0, // Non-streakable
                    teamMemberLevel: 0,
                    isModerator: false,
                    isSubscriber: false,
                    timestamp: new Date().toISOString()
                };

                // Process the gift event through the normal pipeline
                await this.handleTikTokEvent('gift', simulatedGiftEvent);

                res.json({
                    success: true,
                    message: 'Gift event simulated successfully',
                    eventData: simulatedGiftEvent,
                    mappingsCount: this.mappingEngine.getMappingsByEvent('gift').length
                });

            } catch (error) {
                this.api.log(`Failed to simulate gift event: ${error.message}`, 'error');
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        // Get current mapping evaluation details (for debugging)
        // Note: This endpoint exposes mapping configuration (without sensitive data)
        // Consider adding authentication in production environments
        this.api.registerRoute('get', '/api/openshock/debug/mappings', (req, res) => {
            try {
                const allMappings = this.mappingEngine.getAllMappings();
                const giftMappings = this.mappingEngine.getMappingsByEvent('gift');
                
                const debug = {
                    totalMappings: allMappings.length,
                    giftMappings: {
                        total: giftMappings.length,
                        enabled: giftMappings.filter(m => m.enabled).length,
                        disabled: giftMappings.filter(m => !m.enabled).length,
                        details: giftMappings.map(m => ({
                            id: m.id,
                            name: m.name,
                            enabled: m.enabled,
                            eventType: m.eventType,
                            conditions: {
                                giftName: m.conditions?.giftName || 'any',
                                minCoins: m.conditions?.minCoins || 0,
                                maxCoins: m.conditions?.maxCoins || 'unlimited',
                                whitelistCount: m.conditions?.whitelist?.length || 0,  // Don't expose actual usernames
                                blacklistCount: m.conditions?.blacklist?.length || 0,  // Don't expose actual usernames
                                teamLevelMin: m.conditions?.teamLevelMin || 0
                            },
                            action: {
                                type: m.action.type,
                                deviceId: m.action.deviceId ? '***' + m.action.deviceId.slice(-4) : 'none',  // Partially mask device ID
                                commandType: m.action.commandType,
                                intensity: m.action.intensity,
                                duration: m.action.duration,
                                patternId: m.action.patternId ? '***' + m.action.patternId.slice(-4) : undefined  // Partially mask pattern ID
                            },
                            cooldowns: {
                                global: m.cooldown?.global || 0,
                                perDevice: m.cooldown?.perDevice || 0,
                                perUser: m.cooldown?.perUser || 0
                            }
                        }))
                    }
                };

                res.json({
                    success: true,
                    debug,
                    note: 'Sensitive data (device IDs, usernames) is masked or excluded for security'
                });
            } catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message
                });
            }
        });

        this.api.log('OpenShock routes registered', 'info');
    }

    /**
     * Socket.IO Events registrieren
     */
    _registerSocketEvents() {
        // Keine eingehenden Socket-Events nötig für TikTok events
        // TikTok events werden via registerTikTokEvent registriert (EventEmitter-based)
        // Wir senden nur broadcasts für OpenShock-spezifische Events

        this.api.log('OpenShock Socket.IO events registered', 'info');
    }

    /**
     * TikTok Event-Handler registrieren
     */
    _registerTikTokEvents() {
        // Register event handlers using the Plugin API
        // These listen to the same events that populate the dashboard's Live Event Log
        // Events come from tiktok.js handleEvent() via EventEmitter
        
        this.api.log('Registering TikTok event handlers...', 'info');
        
        // Chat
        this.api.registerTikTokEvent('chat', async (data) => {
            this.api.log('[TikTok Event] Chat event received', 'debug');
            await this.handleTikTokEvent('chat', data);
        });

        // Gift
        this.api.registerTikTokEvent('gift', async (data) => {
            this.api.log('[TikTok Event] Gift event received!', 'info');
            await this.handleTikTokEvent('gift', data);
        });

        // Follow
        this.api.registerTikTokEvent('follow', async (data) => {
            this.api.log('[TikTok Event] Follow event received', 'debug');
            await this.handleTikTokEvent('follow', data);
        });

        // Share
        this.api.registerTikTokEvent('share', async (data) => {
            this.api.log('[TikTok Event] Share event received', 'debug');
            await this.handleTikTokEvent('share', data);
        });

        // Subscribe
        this.api.registerTikTokEvent('subscribe', async (data) => {
            this.api.log('[TikTok Event] Subscribe event received', 'debug');
            await this.handleTikTokEvent('subscribe', data);
        });

        // Like
        this.api.registerTikTokEvent('like', async (data) => {
            this.api.log('[TikTok Event] Like event received', 'debug');
            await this.handleTikTokEvent('like', data);
        });

        // Goal Progress
        this.api.registerTikTokEvent('goal_progress', async (data) => {
            this.api.log('[TikTok Event] Goal progress event received', 'debug');
            await this.handleTikTokEvent('goal_progress', data);
        });

        // Goal Complete
        this.api.registerTikTokEvent('goal_complete', async (data) => {
            this.api.log('[TikTok Event] Goal complete event received', 'debug');
            await this.handleTikTokEvent('goal_complete', data);
        });

        this.api.log('✅ OpenShock TikTok event handlers registered (using same events as Live Event Log)', 'info');
    }

    /**
     * IFTTT Flow Actions registrieren
     */
    /**
     * IFTTT Flow Actions registrieren (Legacy - kept for backwards compatibility)
     * Note: The main IFTTT integration is now in action-registry.js
     */
    _registerIFTTTActions() {
        // Legacy flow action support - these delegate to executeAction for consistency
        this.api.registerFlowAction('openshock.send_shock', async (params) => {
            return await this.executeAction({
                type: 'command',
                deviceId: params.deviceId,
                commandType: 'shock',
                intensity: params.intensity || 50,
                duration: params.duration || 1000
            }, {
                userId: 'flow-system-legacy',
                username: 'Legacy Flow',
                source: 'legacy-flow-action',
                sourceData: params
            });
        });

        this.api.registerFlowAction('openshock.send_vibrate', async (params) => {
            return await this.executeAction({
                type: 'command',
                deviceId: params.deviceId,
                commandType: 'vibrate',
                intensity: params.intensity || 50,
                duration: params.duration || 1000
            }, {
                userId: 'flow-system-legacy',
                username: 'Legacy Flow',
                source: 'legacy-flow-action',
                sourceData: params
            });
        });

        this.api.registerFlowAction('openshock.execute_pattern', async (params) => {
            return await this.executeAction({
                type: 'pattern',
                deviceId: params.deviceId,
                patternId: params.patternId
            }, {
                userId: 'flow-system-legacy',
                username: 'Legacy Flow',
                source: 'legacy-flow-action',
                sourceData: params
            });
        });

        this.api.log('OpenShock legacy flow actions registered (delegate to executeAction)', 'info');
    }

    /**
     * Extract user ID from event data with fallback chain
     * Utility function to avoid code duplication
     * @param {Object} eventData - Event data object
     * @returns {string} User ID
     * @private
     */
    _extractUserId(eventData) {
        return eventData.userId || eventData.uniqueId || eventData.user?.userId || 'unknown';
    }

    /**
     * Extract username from event data with fallback chain
     * Utility function to avoid code duplication
     * @param {Object} eventData - Event data object
     * @returns {string} Username
     * @private
     */
    _extractUsername(eventData) {
        return eventData.username || eventData.nickname || eventData.user?.userName || 'Unknown';
    }

    /**
     * TikTok Event Handler
     */
    async handleTikTokEvent(eventType, eventData) {
        try {
            // Stats
            this.stats.tiktokEventsProcessed++;

            // Enhanced logging for gift events with comprehensive debug information
            if (eventType === 'gift') {
                const giftName = eventData.giftName || eventData.gift?.name || 'unknown';
                const giftId = eventData.giftId || eventData.gift?.id || 'unknown';
                const coins = eventData.coins || eventData.giftCoins || 0;
                const diamondCount = eventData.diamondCount || 0;
                const repeatCount = eventData.repeatCount || 1;
                const username = this._extractUsername(eventData);
                
                // Log to Winston (server console/file)
                this.api.log(`🎁 [OpenShock Gift Event] Received from TikTok`, 'info');
                this.api.log(`   Gift Name: ${giftName}`, 'info');
                this.api.log(`   Gift ID: ${giftId}`, 'info');
                this.api.log(`   User: ${username}`, 'info');
                this.api.log(`   Coins: ${coins} (${diamondCount} × ${repeatCount})`, 'info');
                this.api.log(`   Streak Status: ${eventData.isStreakEnd ? 'ENDED' : 'ONGOING/NOT_STREAKABLE'}`, 'info');
                this.api.log(`   Full Event Data: ${JSON.stringify(eventData)}`, 'debug');
                
                // Broadcast to UI debug log
                this._broadcastDebugLog('info', `🎁 Gift: ${giftName} from ${username} (${coins} coins)`);
            } else {
                this.api.log(`📨 [OpenShock Event] Received ${eventType} event from TikTok`, 'info');
                this.api.log(`   Event Data: ${JSON.stringify(eventData)}`, 'debug');
                
                // Broadcast to UI debug log
                this._broadcastDebugLog('info', `📨 ${eventType} event from ${this._extractUsername(eventData)}`);
            }

            // Event-Log
            this._addEventLog({
                type: eventType,
                source: 'tiktok',
                data: eventData,
                timestamp: Date.now()
            });

            // Special handling for like events with threshold
            if (eventType === 'like') {
                const likeCount = eventData.likeCount || eventData.count || eventData.like_count || 1;
                const accumulated = this._accumulateLikes(likeCount);
                
                const threshold = this.config.likeThreshold || { minLikes: 10, timeWindow: 5000 };
                this.api.log(`💗 [Like Event] Received ${likeCount} like(s), accumulated: ${accumulated.count}/${threshold.minLikes}`, 'info');
                this._broadcastDebugLog('info', `💗 Like: +${likeCount} (total: ${accumulated.count}/${threshold.minLikes})`);
                
                // Only proceed if threshold is met
                if (!accumulated.thresholdMet) {
                    this.api.log(`[Like Event] Threshold not met, waiting for more likes (${accumulated.remaining} more needed)`, 'debug');
                    return; // Don't process mappings yet
                }
                
                // Threshold met - create synthetic event with accumulated count
                this.api.log(`✅ [Like Event] Threshold met! Processing ${accumulated.count} accumulated likes`, 'info');
                this._broadcastDebugLog('success', `✅ Like threshold met! ${accumulated.count} likes`);
                
                // Override eventData with accumulated count
                eventData = {
                    ...eventData,
                    likeCount: accumulated.count,
                    count: accumulated.count,
                    accumulatedLikes: true,
                    originalLikeCount: likeCount
                };
            }

            // Mapping-Engine fragen, welche Actions getriggert werden sollen
            this.api.log(`[Mapping Evaluation] Checking mappings for ${eventType} event`, 'debug');
            const matches = this.mappingEngine.evaluateEvent(eventType, eventData);

            if (matches.length === 0) {
                if (eventType === 'gift') {
                    const giftName = eventData.giftName || eventData.gift?.name || 'unknown';
                    const allMappings = this.mappingEngine.getMappingsByEvent('gift');
                    this.api.log(`⚠️  [Gift Event] No mappings matched for gift: ${giftName}`, 'warn');
                    this.api.log(`   Total gift mappings configured: ${allMappings.length}`, 'warn');
                    this.api.log(`   Enabled gift mappings: ${allMappings.filter(m => m.enabled).length}`, 'warn');
                    
                    // Broadcast to UI
                    this._broadcastDebugLog('warn', `⚠️  No mappings matched for gift: ${giftName} (${allMappings.filter(m => m.enabled).length} enabled mappings)`);
                    
                    // Log why each mapping didn't match (for debugging)
                    for (const mapping of allMappings.filter(m => m.enabled)) {
                        const conditions = mapping.conditions || {};
                        this.api.log(`   Mapping "${mapping.name}" conditions:`, 'debug');
                        if (conditions.giftName) {
                            this.api.log(`     - Requires gift name: ${conditions.giftName}`, 'debug');
                        }
                        if (conditions.minCoins) {
                            this.api.log(`     - Min coins: ${conditions.minCoins}`, 'debug');
                        }
                        if (conditions.maxCoins) {
                            this.api.log(`     - Max coins: ${conditions.maxCoins}`, 'debug');
                        }
                    }
                } else {
                    this.api.log(`[Event Handler] No mappings matched for ${eventType} event`, 'debug');
                }
                return;
            }

            this.api.log(`✅ [Event Handler] ${matches.length} mapping(s) matched for ${eventType} event`, 'info');
            
            // Broadcast to UI
            this._broadcastDebugLog('success', `✅ ${matches.length} mapping(s) matched for ${eventType} event`);
            
            // Log matched mappings for transparency
            for (const match of matches) {
                this.api.log(`   - Mapping: "${match.mapping.name}" (priority: ${match.mapping.action.priority || 5})`, 'info');
                this._broadcastDebugLog('info', `   → "${match.mapping.name}"`);
            }

            // Extract actions from matches
            const actions = matches.map(m => m.action);

            // Jede Action ausführen
            for (const action of actions) {
                this.api.log(`[Action Execution] Executing action type: ${action.type}`, 'info');
                this._broadcastDebugLog('info', `⚡ Executing ${action.type} action`);
                
                await this.executeAction(action, {
                    userId: this._extractUserId(eventData),
                    username: this._extractUsername(eventData),
                    source: eventType,
                    sourceData: eventData
                });
            }

        } catch (error) {
            this.api.log(`❌ Error handling TikTok event ${eventType}: ${error.message}`, 'error');
            this.api.log(`   Stack: ${error.stack}`, 'debug');
            this._addError(`TikTok Event Error (${eventType})`, error.message);
            
            // Broadcast error to UI
            this._broadcastDebugLog('error', `❌ Error handling ${eventType}: ${error.message}`);
        }
    }

    /**
     * Action ausführen
     */
    async executeAction(action, context) {
        try {
            const { userId, username, source, sourceData } = context;

            // Emergency Stop Check
            if (this.config.emergencyStop.enabled) {
                this.api.log('Action blocked: Emergency Stop is active', 'warn');
                this.stats.blockedCommands++;
                return {
                    success: false,
                    error: 'Emergency Stop is active',
                    blocked: true
                };
            }

            // Pause Check
            if (this.isPaused) {
                this.api.log('Action blocked: Plugin is paused', 'warn');
                this.stats.blockedCommands++;
                return {
                    success: false,
                    error: 'Plugin is paused',
                    blocked: true
                };
            }

            // Action-Type bestimmen
            if (action.type === 'command') {
                // Direkter Command
                await this._executeCommand(action, context);
                return {
                    success: true,
                    message: 'Command queued successfully',
                    type: action.commandType
                };

            } else if (action.type === 'pattern') {
                // Pattern ausführen
                const executionId = await this._executePatternFromAction(action, context);
                return {
                    success: true,
                    message: 'Pattern execution started',
                    executionId
                };

            } else {
                this.api.log(`Unknown action type: ${action.type}`, 'warn');
                return {
                    success: false,
                    error: `Unknown action type: ${action.type}`
                };
            }

        } catch (error) {
            this.api.log(`Error executing action: ${error.message}`, 'error');
            this._addError('Action Execution Error', error.message);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Command ausführen (über Queue)
     */
    async _executeCommand(action, context) {
        const { userId, username, source, sourceData } = context;
        const { deviceId, commandType, intensity, duration } = action;

        // Device finden
        const device = this.devices.find(d => d.id === deviceId);
        if (!device) {
            this.api.log(`Device ${deviceId} not found`, 'warn');
            return;
        }

        // In Queue einfügen
        this.queueManager.addItem({
            id: `cmd-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`,
            type: 'command',
            deviceId,
            deviceName: device.name,
            commandType,
            intensity,
            duration,
            userId,
            username,
            source,
            sourceData,
            timestamp: Date.now(),
            priority: action.priority || 5
        });

        this.stats.queuedCommands++;
    }

    /**
     * Pattern ausführen (über Queue)
     */
    async _executePatternFromAction(action, context) {
        const { userId, username, source, sourceData } = context;
        const { deviceId, patternId, variables = {} } = action;

        // Pattern laden
        const pattern = this.patternEngine.getPattern(patternId);
        if (!pattern) {
            this.api.log(`Pattern ${patternId} not found`, 'warn');
            return null;
        }

        // Device finden
        const device = this.devices.find(d => d.id === deviceId);
        if (!device) {
            this.api.log(`Device ${deviceId} not found`, 'warn');
            return null;
        }

        // Pattern ausführen and return executionId
        return await this._executePattern(pattern, device, {
            userId,
            username,
            source,
            sourceData,
            variables
        });
    }

    /**
     * Pattern ausführen (alle Steps in Queue)
     */
    async _executePattern(pattern, device, context) {
        const executionId = `pattern-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;

        this.api.log(`[Pattern Execution] Starting pattern "${pattern.name}" (ID: ${pattern.id}) on device "${device.name}" (ID: ${device.id})`, 'info');
        this.api.log(`[Pattern Execution] Pattern has ${pattern.steps?.length || 0} steps`, 'info');

        // Execution tracken
        this.activePatternExecutions.set(executionId, {
            patternId: pattern.id,
            patternName: pattern.name,
            deviceId: device.id,
            deviceName: device.name,
            startTime: Date.now(),
            cancelled: false
        });

        // Pattern-Steps direkt aus pattern.steps verwenden
        const steps = pattern.steps || [];

        if (steps.length === 0) {
            this.api.log(`[Pattern Execution] Warning: Pattern "${pattern.name}" has no steps!`, 'warn');
            return executionId;
        }

        // Calculate cumulative delay for each command step
        // Pause steps add to the cumulative delay, command steps use the cumulative delay
        let cumulativeDelay = 0;
        let queuedSteps = 0;
        const baseTimestamp = Date.now();

        for (let i = 0; i < steps.length; i++) {
            const step = steps[i];

            if (step.type === 'pause') {
                // Pause steps add to the cumulative delay for subsequent commands
                cumulativeDelay += step.duration || 0;
                this.api.log(`[Pattern Execution] Step ${i}: Pause (${step.duration}ms) - cumulative delay now ${cumulativeDelay}ms`, 'debug');
                continue;
            }

            // For command steps (shock, vibrate, sound), schedule with cumulative delay
            const scheduledTime = baseTimestamp + cumulativeDelay + (step.delay || 0);
            
            this.api.log(`[Pattern Execution] Step ${i}: ${step.type} (intensity: ${step.intensity}, duration: ${step.duration}ms) scheduled at +${cumulativeDelay}ms`, 'debug');

            this.queueManager.addItem({
                id: `${executionId}-step-${i}`,
                type: 'command',
                deviceId: device.id,
                deviceName: device.name,
                commandType: step.type,
                intensity: step.intensity,
                duration: step.duration,
                userId: context.userId,
                username: context.username,
                source: `pattern:${pattern.name}`,
                sourceData: context.sourceData,
                timestamp: scheduledTime,
                priority: 5,
                executionId,
                stepIndex: i
            });
            queuedSteps++;

            // After a command step, add its duration to cumulative delay
            // This ensures the next command waits for this one to complete
            cumulativeDelay += step.duration || 0;
        }

        this.api.log(`[Pattern Execution] Queued ${queuedSteps} steps for pattern "${pattern.name}" (executionId: ${executionId}), total duration: ${cumulativeDelay}ms`, 'info');
        this.stats.patternsExecuted++;

        return executionId;
    }

    /**
     * Queue-Item verarbeiten
     */
    async _processQueueItem(item) {
        try {
            // Check ob Execution gecancelt wurde
            if (item.executionId) {
                const execution = this.activePatternExecutions.get(item.executionId);
                if (execution && execution.cancelled) {
                    this.api.log(`Pattern execution ${item.executionId} was cancelled, skipping step`, 'info');
                    return true; // Als erfolgreich markieren (damit keine Retries)
                }
            }

            // Safety-Check
            const safetyCheck = this.safetyManager.validateCommand({
                deviceId: item.deviceId,
                type: item.commandType,
                intensity: item.intensity,
                duration: item.duration,
                userId: item.userId,
                source: item.source
            });

            if (!safetyCheck.allowed) {
                this.api.log(`Command blocked by safety: ${safetyCheck.reason}`, 'warn');
                this.stats.blockedCommands++;

                // Log
                this._logCommand({
                    ...item,
                    success: false,
                    errorMessage: `Blocked: ${safetyCheck.reason}`
                });

                return false;
            }

            // Command senden
            await this.openShockClient.sendControl(item.deviceId, {
                type: item.commandType,
                intensity: safetyCheck.adjustedIntensity || item.intensity,
                duration: safetyCheck.adjustedDuration || item.duration
            });

            // Log
            this._logCommand({
                deviceId: item.deviceId,
                deviceName: item.deviceName,
                type: item.commandType,
                intensity: safetyCheck.adjustedIntensity || item.intensity,
                duration: safetyCheck.adjustedDuration || item.duration,
                userId: item.userId,
                username: item.username,
                source: item.source,
                success: true
            });

            // Stats
            this.stats.totalCommands++;
            this.stats.lastCommandTime = Date.now();

            // Broadcast
            this._broadcastCommandSent({
                device: item.deviceName,
                type: item.commandType,
                intensity: safetyCheck.adjustedIntensity || item.intensity,
                duration: safetyCheck.adjustedDuration || item.duration,
                user: item.username,
                source: item.source
            });

            // Wenn Pattern-Step, checken ob letzter Step
            if (item.executionId) {
                const execution = this.activePatternExecutions.get(item.executionId);
                if (execution) {
                    // Prüfen ob alle Steps verarbeitet wurden
                    // (Wird vereinfacht - in Produktion würde man die Steps tracken)
                    // Für jetzt: Execution nach 10 Sekunden entfernen
                    setTimeout(() => {
                        this.activePatternExecutions.delete(item.executionId);
                    }, 10000);
                }
            }

            return true;

        } catch (error) {
            this.api.log(`Failed to process queue item: ${error.message}`, 'error');

            // Log
            this._logCommand({
                deviceId: item.deviceId,
                deviceName: item.deviceName,
                type: item.commandType,
                intensity: item.intensity,
                duration: item.duration,
                userId: item.userId,
                username: item.username,
                source: item.source,
                success: false,
                errorMessage: error.message
            });

            this._addError('Queue Processing Error', error.message);

            return false;
        }
    }

    /**
     * Devices von OpenShock API laden
     */
    async loadDevices() {
        try {
            if (!this.config.apiKey || this.config.apiKey.trim() === '') {
                throw new Error('API Key not configured');
            }

            this.api.log('Loading devices from OpenShock API...', 'info');

            const devices = await this.openShockClient.getDevices();
            this.devices = devices;

            this.api.log(`Loaded ${devices.length} devices`, 'info');

            // Broadcast
            this._broadcastDeviceUpdate();

            return devices;

        } catch (error) {
            this.api.log(`Failed to load devices: ${error.message}`, 'error');
            this._addError('Device Loading Error', error.message);
            throw error;
        }
    }

    /**
     * Daten laden (Config, Mappings, Patterns)
     */
    async loadData() {
        const db = this.api.getDatabase();

        // Config laden
        try {
            const configRow = db.prepare('SELECT value FROM openshock_config WHERE key = ?').get('config');
            if (configRow) {
                const savedConfig = JSON.parse(configRow.value);
                this.config = { ...this.config, ...savedConfig };
            }
        } catch (error) {
            this.api.log(`Failed to load config from database: ${error.message}`, 'warn');
        }

        this.api.log('OpenShock data loaded', 'info');
    }

    /**
     * Daten speichern (Config, Mappings, Patterns)
     */
    async saveData() {
        const db = this.api.getDatabase();

        // Config speichern
        try {
            const stmt = db.prepare('INSERT OR REPLACE INTO openshock_config (key, value) VALUES (?, ?)');
            stmt.run('config', JSON.stringify(this.config));
        } catch (error) {
            this.api.log(`Failed to save config to database: ${error.message}`, 'error');
        }

        this.api.log('OpenShock data saved', 'info');
    }

    /**
     * Load mappings from database
     */
    _loadMappingsFromDatabase() {
        const db = this.api.getDatabase();

        try {
            const mappings = db.prepare('SELECT * FROM openshock_mappings').all();

            for (const row of mappings) {
                try {
                    // Parse JSON columns
                    const conditions = row.conditions ? JSON.parse(row.conditions) : {};
                    const action = JSON.parse(row.action);

                    // Construct mapping object
                    const mapping = {
                        id: row.id,
                        name: row.name,
                        enabled: row.enabled === 1,
                        eventType: row.event_type,
                        conditions: conditions,
                        action: action
                    };

                    // Add to mapping engine (skip if ID already exists from presets)
                    if (!this.mappingEngine.getMapping(mapping.id)) {
                        this.mappingEngine.addMapping(mapping);
                    }
                } catch (error) {
                    this.api.log(`Failed to load mapping ${row.id}: ${error.message}`, 'warn');
                }
            }

            this.api.log(`Loaded ${mappings.length} mappings from database`, 'info');
        } catch (error) {
            this.api.log(`Failed to load mappings from database: ${error.message}`, 'error');
        }
    }

    /**
     * Load patterns from database
     */
    _loadPatternsFromDatabase() {
        const db = this.api.getDatabase();

        try {
            const patterns = db.prepare('SELECT * FROM openshock_patterns WHERE preset = 0').all();

            for (const row of patterns) {
                try {
                    // Parse JSON steps column
                    const steps = JSON.parse(row.steps);

                    // Construct pattern object
                    const pattern = {
                        id: row.id,
                        name: row.name,
                        description: row.description || '',
                        steps: steps,
                        preset: row.preset === 1
                    };

                    // Add to pattern engine (skip if ID already exists from presets)
                    if (!this.patternEngine.getPattern(pattern.id)) {
                        this.patternEngine.addPattern(pattern);
                    }
                } catch (error) {
                    this.api.log(`Failed to load pattern ${row.id}: ${error.message}`, 'warn');
                }
            }

            this.api.log(`Loaded ${patterns.length} custom patterns from database`, 'info');
        } catch (error) {
            this.api.log(`Failed to load patterns from database: ${error.message}`, 'error');
        }
    }

    /**
     * Save mapping to database
     */
    _saveMappingToDatabase(mapping) {
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare(`
                INSERT OR REPLACE INTO openshock_mappings
                (id, name, enabled, event_type, conditions, action, priority, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            `);

            stmt.run(
                mapping.id,
                mapping.name,
                mapping.enabled ? 1 : 0,
                mapping.eventType,
                JSON.stringify(mapping.conditions || {}),
                JSON.stringify(mapping.action),
                mapping.action?.priority || mapping.priority || 5
            );

            this.api.log(`Saved mapping ${mapping.id} to database`, 'info');
        } catch (error) {
            this.api.log(`Failed to save mapping to database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Save pattern to database
     */
    _savePatternToDatabase(pattern) {
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare(`
                INSERT OR REPLACE INTO openshock_patterns
                (id, name, description, steps, preset, updated_at)
                VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            `);

            stmt.run(
                pattern.id,
                pattern.name,
                pattern.description || '',
                JSON.stringify(pattern.steps),
                pattern.preset ? 1 : 0
            );

            this.api.log(`Saved pattern ${pattern.id} to database`, 'info');
        } catch (error) {
            this.api.log(`Failed to save pattern to database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Delete mapping from database
     */
    _deleteMappingFromDatabase(id) {
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare('DELETE FROM openshock_mappings WHERE id = ?');
            stmt.run(id);

            this.api.log(`Deleted mapping ${id} from database`, 'info');
        } catch (error) {
            this.api.log(`Failed to delete mapping from database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Delete pattern from database
     */
    _deletePatternFromDatabase(id) {
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare('DELETE FROM openshock_patterns WHERE id = ?');
            stmt.run(id);

            this.api.log(`Deleted pattern ${id} from database`, 'info');
        } catch (error) {
            this.api.log(`Failed to delete pattern from database: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Command loggen
     */
    _logCommand(command) {
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare(`
                INSERT INTO openshock_command_history
                (device_id, device_name, command_type, intensity, duration, user_id, username, source, success, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            `);

            stmt.run(
                command.deviceId,
                command.deviceName,
                command.type,
                command.intensity,
                command.duration,
                command.userId,
                command.username,
                command.source,
                command.success ? 1 : 0,
                command.errorMessage || null
            );
        } catch (error) {
            this.api.log(`Failed to log command: ${error.message}`, 'error');
        }
    }

    /**
     * Event loggen
     */
    _addEventLog(event) {
        this.eventLog.push(event);

        if (this.eventLog.length > this.maxEventLog) {
            this.eventLog.shift();
        }

        // In Datenbank
        const db = this.api.getDatabase();

        try {
            const stmt = db.prepare(`
                INSERT INTO openshock_event_log
                (event_type, event_source, user_id, username, action_taken, success)
                VALUES (?, ?, ?, ?, ?, ?)
            `);

            stmt.run(
                event.type,
                event.source,
                event.data?.userId || event.data?.uniqueId || null,
                event.data?.username || event.data?.nickname || null,
                null,
                1
            );
        } catch (error) {
            this.api.log(`Failed to log event: ${error.message}`, 'error');
        }
    }

    /**
     * Error loggen
     */
    _addError(category, message) {
        const error = {
            category,
            message,
            timestamp: Date.now()
        };

        this.stats.errors.push(error);

        // Max 100 errors behalten
        if (this.stats.errors.length > 100) {
            this.stats.errors.shift();
        }
    }

    /**
     * Stats-Timer starten
     */
    _startStatsTimer() {
        // Alle 5 Sekunden Stats broadcasten
        this.statsInterval = setInterval(() => {
            this._broadcastStatsUpdate();
        }, 5000);
    }

    /**
     * Status broadcasten
     */
    _broadcastStatus() {
        this.api.emit('openshock:status', {
            isRunning: this.isRunning,
            isPaused: this.isPaused,
            emergencyStop: this.config.emergencyStop.enabled,
            devicesCount: this.devices.length,
            hasApiKey: !!(this.config.apiKey && this.config.apiKey.trim() !== '')
        });
    }

    /**
     * Device-Update broadcasten
     */
    _broadcastDeviceUpdate() {
        this.api.emit('openshock:device-update', {
            devices: this.devices
        });
    }

    /**
     * Command-Sent broadcasten
     */
    _broadcastCommandSent(data) {
        this.api.emit('openshock:command-sent', data);
    }

    /**
     * Queue-Update broadcasten
     */
    _broadcastQueueUpdate() {
        const status = this.queueManager.getQueueStatus();
        this.api.emit('openshock:queue-update', status);
    }

    /**
     * Emergency-Stop broadcasten
     */
    _broadcastEmergencyStop() {
        this.api.emit('openshock:emergency-stop', {
            timestamp: Date.now()
        });
    }

    /**
     * Stats-Update broadcasten
     */
    _broadcastStatsUpdate() {
        const uptime = this.stats.startTime ? Date.now() - this.stats.startTime : 0;
        const queueStatus = this.queueManager ? this.queueManager.getQueueStatus() : {};

        this.api.emit('openshock:stats-update', {
            ...this.stats,
            uptime,
            queueSize: queueStatus.queueSize || 0,
            activePatternExecutions: this.activePatternExecutions.size
        });
    }

    /**
     * Debug Log broadcasten (für UI Debug Log)
     * @param {string} level - Log level (info, warn, error, success, debug)
     * @param {string} message - Log message
     */
    _broadcastDebugLog(level, message) {
        this.api.emit('openshock:debug-log', {
            level: level,
            message: message,
            timestamp: new Date().toISOString()
        });
    }

    /**
     * Accumulate likes and check if threshold is met
     * @param {number} likeCount - Number of likes in this event
     * @returns {Object} Accumulator status {count, thresholdMet, remaining}
     * @private
     */
    _accumulateLikes(likeCount) {
        const now = Date.now();
        const threshold = this.config.likeThreshold || { minLikes: 10, timeWindow: 5000 };
        
        // Initialize or reset if time window expired
        if (!this.likeAccumulator.startTime || (now - this.likeAccumulator.startTime) > threshold.timeWindow) {
            this.likeAccumulator.count = 0;
            this.likeAccumulator.startTime = now;
            
            // Clear existing timer
            if (this.likeAccumulator.timer) {
                clearTimeout(this.likeAccumulator.timer);
            }
            
            // Set new timer to auto-reset
            this.likeAccumulator.timer = setTimeout(() => {
                this.api.log(`[Like Accumulator] Time window expired, resetting (had ${this.likeAccumulator.count} likes)`, 'debug');
                this._broadcastDebugLog('debug', `💗 Like window expired (${this.likeAccumulator.count} likes not reached threshold)`);
                this.likeAccumulator.count = 0;
                this.likeAccumulator.startTime = null;
            }, threshold.timeWindow);
        }
        
        // Add new likes
        this.likeAccumulator.count += likeCount;
        
        // Check if threshold is met
        const thresholdMet = this.likeAccumulator.count >= threshold.minLikes;
        const remaining = Math.max(0, threshold.minLikes - this.likeAccumulator.count);
        
        if (thresholdMet) {
            // Reset accumulator after threshold is met
            const finalCount = this.likeAccumulator.count;
            this.likeAccumulator.count = 0;
            this.likeAccumulator.startTime = null;
            
            if (this.likeAccumulator.timer) {
                clearTimeout(this.likeAccumulator.timer);
                this.likeAccumulator.timer = null;
            }
            
            return {
                count: finalCount,
                thresholdMet: true,
                remaining: 0
            };
        }
        
        return {
            count: this.likeAccumulator.count,
            thresholdMet: false,
            remaining: remaining
        };
    }

    /**
     * Plugin beenden
     */
    async destroy() {
        try {
            this.api.log('OpenShock Plugin shutting down...', 'info');

            // Clear like accumulator timer
            if (this.likeAccumulator.timer) {
                clearTimeout(this.likeAccumulator.timer);
                this.likeAccumulator.timer = null;
            }

            // Stats interval stoppen
            if (this.statsInterval) {
                clearInterval(this.statsInterval);
                this.statsInterval = null;
            }

            // Queue stoppen
            if (this.queueManager) {
                this.queueManager.stopProcessing();
            }

            // Safety Manager cleanup
            if (this.safetyManager && typeof this.safetyManager.destroy === 'function') {
                this.safetyManager.destroy();
            }

            // Pattern Engine cleanup
            if (this.patternEngine) {
                this.patternEngine.stopAllExecutions();
                this.patternEngine.cleanupExecutions(0); // Cleanup all
            }

            // Pattern-Executions stoppen
            this.activePatternExecutions.clear();

            // Daten speichern
            await this.saveData();

            this.isRunning = false;

            this.api.log('OpenShock Plugin shut down successfully', 'info');

        } catch (error) {
            this.api.log(`Error during shutdown: ${error.message}`, 'error');
        }
    }
}

module.exports = OpenShockPlugin;
